"""HOW TO ADAPT: paragraph-specific instance of econ-pdf-builder (Pandoc + WeasyPrint).
Run with Python 3.14.3, WeasyPrint 68.1, Pandoc 3.9.0.1; Windows Pango in C:/msys64/mingw64/bin.
Source Markdown and PNGs are read from this folder. HTML/PDF are regenerated, never hand-patched.
"""
import os, base64, re, subprocess, json
from pathlib import Path
from datetime import datetime, timezone
BASE=Path(__file__).resolve().parent
ASSET_DIR=BASE/'_assets'
os.environ['PATH']='C:/msys64/mingw64/bin;'+os.environ['PATH']
import weasyprint
CSS='''<style>
@page { size:A4; margin:1.8cm 2cm 2cm;
 @bottom-left {content:"2.1.2 Opbrengsten, winst en break-even";font-family:Arial;font-size:8pt;color:#555;}
 @bottom-right {content:counter(page) " / " counter(pages);font-family:Arial;font-size:8pt;color:#555;}
}
body {font-family:Arial,'DejaVu Sans',sans-serif;font-size:11pt;line-height:1.4;color:#2D3748;max-width:100%;margin:0;padding:0;}
h1 {font-size:18pt;color:#1A5276;border-bottom:1.5px solid #1A5276;padding-bottom:6pt;margin:0 0 14pt;break-after:avoid;}
h2 {font-size:14pt;color:#1A5276;margin:12pt 0 7pt;break-after:avoid;}
h3 {font-size:12pt;color:#1A5276;margin:15pt 0 7pt;break-after:avoid;}
h1+p,h2+p,h3+p {break-before:avoid;}
p {margin:0 0 6pt;orphans:3;widows:3;}
blockquote {background:#F0F4F8;border-left:3px solid #1A5276;padding:7pt 10pt;margin:10pt 0;break-inside:avoid;font-size:10.5pt;}
blockquote p {margin:0 0 4pt;} blockquote p:last-child {margin-bottom:0;}
code {font-family:Consolas,'DejaVu Sans Mono',monospace;font-size:10pt;background:#EDF2F7;padding:0 2pt;white-space:normal;overflow-wrap:anywhere;}
table {border-collapse:collapse;width:100%;margin:10pt 0;font-size:10pt;line-height:1.25;break-inside:avoid;}
th,td {border:1px solid #999;padding:4pt;text-align:left;} th {background:#EDF0F3;} tr:nth-child(even) td {background:#FAFBFC;}
figure {margin:9pt 0 12pt;break-inside:avoid;break-before:avoid;} img {display:block;width:100%;max-width:100%;margin:0 auto;}
figcaption {font-size:9.5pt;line-height:1.25;margin-top:5pt;color:#4A5568;}
.exercise {margin-bottom:9pt;break-inside:avoid;} .exercise p {margin:0 0 4pt;}
.visual-block {break-inside:avoid;}
.exercise>p:first-child {break-after:avoid;} .page-break {break-before:page;}
ul,ol {padding-left:17pt;margin:5pt 0 9pt;} li {margin-bottom:3pt;}
strong {font-weight:700;} em {color:#4A5568;}
</style>'''

def embed_images(md):
    def replace(m):
        path=ASSET_DIR/Path(m.group(2)).name.replace('.svg','.png')
        if not path.is_file():raise FileNotFoundError(path)
        return f'![{m.group(1)}](data:image/png;base64,{base64.b64encode(path.read_bytes()).decode()})'
    return re.sub(r'!\[([^\]]*)\]\(([^)]+)\)',replace,md)

def strip_pandoc_stylesheets(html):
    style_re=re.compile(r'<style\b[^>]*>.*?</style>',re.I|re.S)
    head_re=re.compile(r'(<head\b[^>]*>)(.*?)(</head>)',re.I|re.S)
    html,count=head_re.subn(lambda m:m.group(1)+style_re.sub('',m.group(2))+m.group(3),html,count=1)
    if count!=1:raise ValueError('Missing head')
    return html

def wrap_exercises(html):
    token_re=re.compile(r'(<p><strong>Opgave\s+\d+\b|<div class="page-break"></div>|<h[123]\b|</body>)',re.I)
    pieces=[];last=0;opened=False
    for match in token_re.finditer(html):
        token=match.group(0);pieces.append(html[last:match.start()])
        if token.lower().startswith('<p><strong>opgave'):
            if opened:pieces.append('</div>')
            pieces.extend(('<div class="exercise">',token));opened=True
        else:
            if opened:pieces.append('</div>');opened=False
            pieces.append(token)
        last=match.end()
    pieces.append(html[last:])
    if opened:pieces.append('</div>')
    return ''.join(pieces)

def build(md):
    result=subprocess.run(['pandoc','--from=markdown','--to=html5','--standalone','--metadata=lang:nl'],input=embed_images(md.read_text(encoding='utf-8')).encode(),capture_output=True,check=True)
    html=wrap_exercises(strip_pandoc_stylesheets(result.stdout.decode()))
    html=html.replace('<html ','<html ').replace('</head>',CSS+'</head>')
    # No metadata title: preserve one H1 from Markdown.
    html=html.replace('<title>Untitled</title>',f'<title>{md.stem}</title>')
    md.with_suffix('.html').write_text(html,encoding='utf-8')
    document=weasyprint.HTML(string=html,base_url=str(BASE)).render()
    document.write_pdf(md.with_suffix('.pdf'))
    return {'file':md.with_suffix('.pdf').name,'pages':len(document.pages),'bytes':md.with_suffix('.pdf').stat().st_size}

if __name__=='__main__':
    start=datetime.now(timezone.utc).isoformat()
    reports=[build(next(BASE.glob(f'* – {kind}.md'))) for kind in ['paragraaf','opgaven','antwoorden']]
    report={'start_utc':start,'end_utc':datetime.now(timezone.utc).isoformat(),'weasyprint':weasyprint.__version__,'outputs':reports}
    (BASE/'evidence/build-result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
