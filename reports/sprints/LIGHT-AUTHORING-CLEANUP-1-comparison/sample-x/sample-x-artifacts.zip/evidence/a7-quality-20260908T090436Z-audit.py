"""Independent A7 factual inventory; no student/source/reviewer mutations.

Bounded plan: preserve the original full-quality A7 contract, verify actual
components/assets and frozen review bindings, record Part 0's mandatory blocker,
and write only uniquely named evidence. A7 cannot pass with a stale reference.
No imports from other comparison arms or source generators; standard library only.
"""
from pathlib import Path
from datetime import datetime, timezone
import base64
import hashlib
import json
import re
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

O = Path(__file__).resolve().parents[1]
P = O.parents[1] / '4veco-platform'
L = O.parents[1] / '4veco-lessen'
TAG = 'a7-quality-20260908T090436Z'
E = O / 'evidence'

def utc(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):
    p = p.resolve()
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
def read_json(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def git_state(p):
    def run(*args):
        r = subprocess.run(['git', '-C', str(p), *args], capture_output=True, text=True, check=True)
        return r.stdout.strip()
    return {'path': str(p), 'head': run('rev-parse','HEAD'), 'branch': run('branch','--show-current'),
            'status_porcelain': run('status','--porcelain'), 'tracked_diff': run('diff','HEAD','--stat')}

mds = sorted(O.glob('* – *.md'))
htmls = sorted(O.glob('* – *.html'))
pdfs = sorted(O.glob('* – *.pdf'))
assets = sorted((O/'_assets').glob('*'))
manifest = read_json(E/'rendered-manifest.json')
frozen = mds + htmls + pdfs + assets + [O/'2.1.2-textbook-plan.md', O/'build_pdf.py',
    O/'2.1.2-review.md', O/'teacher-learning-quality-review.md', O/'student-experience-review.md',
    O/'2.1.2-textbook-handoff.md', E/'target-record.json', E/'rendered-manifest.json', E/'build-result.json',
    E/'reviewer-recheck-20260908T090021Z-snapshot-start.json', E/'reviewer-recheck-20260908T090021Z-session.json',
    E/'reviewer-recheck-20260908T090021Z-audit.json', E/'teacher-review-snapshot-final-083326.json',
    E/'teacher-review-session-083326.json', E/'student-review-evidence-20260908.json']
for artifact in manifest['artifacts']:
    frozen += [Path(p) for p in artifact['pages']]

ledger_specs = [
    (P/'AGENTS.md','whole, cumulative bounded reads covering lines 1-883; initial bulk output truncated and recovered'),
    (L/'AGENTS.md','excerpt: lines 1-150 (entrypoint, source/output boundary, strategic and operating rules)'),
    (P/'BUILD-PARAGRAPH.md','excerpt: lines 1-456, common/foundation and complete Part A through A-verify; heading index elsewhere only; initial bulk output truncated'),
    (P/'docs/workflows/paragraph-lane-vocabulary.md','whole'),
    (P/'docs/workflows/textbook-paragraph-lane.md','whole'),
    (P/'skills/econ-quality-control.md','whole, 600 lines; separately reread without truncation'),
    (P/'references/external/inspectie-standaarden.md','whole, 188 lines; original read-only mandatory reference'),
    (P/'docs/workflows/paragraph-quality-ref-schema-v2.md','whole, 83 lines'),
    (L/'specifications/product-vision.md','whole'),
    (L/'specifications/product-end-state.md','excerpts: lines 1-29, 118-155, 348-506 plus heading/keyword search; not whole'),
    (L/'specifications/companion-core-specifications.md','excerpt: lines 1-34 plus heading/keyword search; not whole'),
    (O/'2.1.2-textbook-plan.md','excerpt: lines 87-132 (alignment, timing, visuals, quality floor, review boundaries), heading/keyword search elsewhere; no full foundation authority re-review'),
    (O/'2.1.2-textbook-handoff.md','whole; frozen final handoff only'),
    (O/'2.1.2-review.md','whole current final A6 report'),
    (O/'teacher-learning-quality-review.md','whole current report, cumulative body plus final 18 lines'),
    (O/'student-experience-review.md','whole current report, cumulative body plus first 38 lines'),
    (E/'target-record.json','whole; existing registry attribution only, no fresh syllabus mapping claim'),
    (E/'build-result.json','whole'),
    (E/'rendered-manifest.json','whole; all page files hashed, not visually inspected in A7'),
    (E/'reviewer-recheck-20260908T090021Z-session.json','whole'),
    (E/'runtime-and-source-state.json','whole; recorded environment only, no tool runtime installation'),
    (E/'reproduce.md','whole; no generator executed'),
]
for md in mds:
    scope = 'whole source prose read' if not md.name.endswith('opgaven.md') else 'programmatic whole-file headings/image/extraction/target checks; prose identical to paragraaf exercise body'
    ledger_specs.append((md, scope))
for name in ['reviewer-recheck-20260908T090021Z-snapshot-start.json', 'teacher-review-snapshot-final-083326.json', 'student-review-evidence-20260908.json']:
    ledger_specs.append((E/name, 'programmatic whole JSON; path/hash fields checked against actual bytes; no inherited instruction ledger claimed as own reading'))
for html in htmls: ledger_specs.append((html,'programmatic whole HTML image tags/base64 payloads; no browser rendering'))
for asset in assets: ledger_specs.append((asset,'whole-file SHA256; SVG XML parse or PNG signature/IHDR dimensions; no visual/geometric content review'))
for pdf in pdfs: ledger_specs.append((pdf,'whole-file SHA256, header/size and raw /Type /Page marker count; no independent PDF visual re-review'))

snapshot_path = E/f'{TAG}-snapshot.json'
result_path = E/f'{TAG}-audit.json'
if '--final-check' in sys.argv:
    snap = read_json(snapshot_path)
    drift = []
    for old in snap['files'] + snap['read_ledger']:
        p = Path(old['path'])
        if not p.exists() or sha(p) != old['sha256']:
            drift.append({'path': str(p), 'expected': old['sha256'], 'actual': sha(p) if p.exists() else 'missing'})
    final = {'checked_utc': utc(), 'snapshot_sha256': sha(snapshot_path), 'hash_drift': drift,
             'source_worktrees': [git_state(P), git_state(L)],
             'quality_ref_yaml_exists': (O/'2.1.2-quality-ref.yaml').exists(),
             'administrative_exclusions': ['final comparison report', 'routing/stages/prompts', 'final inventory', 'lock-release logs']}
    (E/f'{TAG}-final-check.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(final,ensure_ascii=False,indent=2))
    raise SystemExit(1 if drift else 0)

if snapshot_path.exists() or result_path.exists():
    raise SystemExit('Evidence already exists: refusing to replace the original A7 snapshot/audit.')
snapshot = {'captured_utc': utc(), 'active_start_utc': '2026-09-08T09:04:36Z',
            'files': [record(p) for p in sorted(set(frozen))],
            'read_ledger': [dict(record(p), scope=scope) for p,scope in ledger_specs],
            'source_worktrees': [git_state(P), git_state(L)]}
snapshot_path.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

images = []
md_images = {}
for md in mds:
    text = md.read_text(encoding='utf-8-sig')
    refs = re.findall(r'!\[([^\]]*)\]\(([^)]+)\)', text)
    md_images[md.stem] = refs
    for alt, rel in refs:
        p=(md.parent/rel).resolve()
        images.append({'source': md.name, 'reference':rel, 'alt':alt, 'exists':p.is_file(),
                       'inside_assets':p.is_relative_to((O/'_assets').resolve()), 'sha256':sha(p) if p.is_file() else None})
referenced = {x['reference'].replace('\\','/') for x in images}
pairs = []
for svg in sorted((O/'_assets').glob('*.svg')):
    png=svg.with_suffix('.png')
    xml=ET.fromstring(svg.read_text(encoding='utf-8-sig'))
    raw=png.read_bytes() if png.exists() else b''
    signature = raw[:8] == b'\x89PNG\r\n\x1a\n'
    pairs.append({'stem':svg.stem,'svg_exists':True,'png_exists':png.exists(),
                  'svg_xml_valid':True,'svg_viewbox':xml.attrib.get('viewBox'),
                  'png_signature_valid':signature,'png_dimensions':list(struct.unpack('>II',raw[16:24])) if signature else None,
                  'concept_used':any(f'_assets/{svg.stem}{ext}' in referenced for ext in ('.png','.svg'))})

class Images(HTMLParser):
    def __init__(self): super().__init__(); self.images=[]
    def handle_starttag(self,tag,attrs):
        if tag=='img': self.images.append(dict(attrs))

html_checks=[]
for html in htmls:
    parser=Images(); parser.feed(html.read_text(encoding='utf-8-sig'))
    expected=md_images[html.stem]
    checks=[]
    for i,img in enumerate(parser.images):
        data=img.get('src','')
        raw=base64.b64decode(data.partition(',')[2],validate=True) if data.startswith('data:image/png;base64,') else b''
        alt, rel=expected[i] if i<len(expected) else ('','')
        checks.append({'index':i,'png_embedded':bool(raw),'bytes_match': bool(rel) and raw==(O/rel).read_bytes(),
                       'alt_matches':img.get('alt')==alt})
    html_checks.append({'file':html.name,'expected_images':len(expected),'actual_images':len(parser.images),
                        'count_match':len(expected)==len(parser.images),'checks':checks})

peer_bindings=[]
for name,key in [('reviewer-recheck-20260908T090021Z-snapshot-start.json','files'),
                 ('teacher-review-snapshot-final-083326.json','files'),
                 ('student-review-evidence-20260908.json','artifact_hashes')]:
    peer=read_json(E/name); differences=[]; checked=0
    for old in peer[key]:
        p=Path(old['path']).resolve()
        if not p.is_relative_to(O): raise ValueError('Peer snapshot escapes authorized output root')
        actual=sha(p) if p.exists() else None
        checked+=1
        if actual != old['sha256'].lower(): differences.append({'path':str(p),'expected':old['sha256'],'actual':actual})
    peer_bindings.append({'snapshot':name,'snapshot_sha256':sha(E/name),'files_checked':checked,'mismatches':differences})

texts={p.name.rsplit(' – ',1)[1].split('.')[0]:p.read_text(encoding='utf-8-sig') for p in mds}
canonical=['Uitgewerkt voorbeeld','Startopgaven','Begeleide inoefening','Zelfstandige oefening','Doeloefening','Denkertje / Bonusopgave','Herhaling / Herhaling en interleaving']
headings={k:re.findall(r'^## (.+)$',v,re.M) for k,v in texts.items()}
start='## Uitgewerkt voorbeeld'
target=read_json(E/'target-record.json')
target_strings=[target['target_exercise']['context']]+[q['prompt'] for q in target['target_exercise']['subquestions']]
pdf_checks=[]
for pdf in pdfs:
    data=pdf.read_bytes(); pdf_checks.append(dict(record(pdf),pdf_header=data.startswith(b'%PDF-'),
        greater_than_10KB=len(data)>10240, raw_page_marker_count=len(re.findall(rb'/Type\s*/Page\b',data))))
result={
    'audit_generated_utc':utc(),'reviewer':'/root/comparison_sample_x/quality_record',
    'purpose':'BLOCKED A7 factual inventory; no compliant quality_ref and no inspectie compliance verdict',
    'model':'unavailable','reasoning_setting':'unavailable','service_tier':'unavailable','tokens':'unavailable',
    'snapshot_sha256':sha(snapshot_path),
    'component_counts':{'student_markdown':len(mds),'textbook_html':len(htmls),'paragraph_pdf':len(pdfs),
                        'svg':sum(p.suffix=='.svg' for p in assets),'png':sum(p.suffix=='.png' for p in assets),
                        'full_rendered_pages':sum(len(a['pages']) for a in manifest['artifacts'])},
    'image_uses':images,'missing_referenced_assets':[x for x in images if not x['exists']],
    'pairs':pairs,'naming_noncompliant':[p.name for p in assets if not re.fullmatch(r'2\.1\.2_(fig|we|ex)_\d+\.(svg|png)',p.name)],
    'literal_unreferenced_assets':[p.name for p in assets if '_assets/'+p.name not in referenced],
    'conceptual_orphans':[p['stem'] for p in pairs if not p['concept_used']],
    'html_image_parity':html_checks,'pdf_checks':pdf_checks,'heading_inventory':headings,
    'seven_headings_exact': all(headings[k]==canonical for k in ['paragraaf','opgaven']),
    'exercise_extraction_exact':texts['paragraaf'][texts['paragraaf'].index(start):]==texts['opgaven'][texts['opgaven'].index(start):],
    'target_strings_verbatim':{k:all(t in texts[k] for t in target_strings) for k in ['paragraaf','opgaven']},
    'target_registry_exam_codes_as_recorded_not_revalidated_against_syllabus':target['exam_codes'],
    'peer_snapshot_binding':peer_bindings,
    'current_review_files':[record(O/n) for n in ['2.1.2-review.md','teacher-learning-quality-review.md','student-experience-review.md']],
    'build_result':read_json(E/'build-result.json'),
    'quality_ref_yaml_exists':(O/'2.1.2-quality-ref.yaml').exists(),
    'companion_absence_in_scope_not_a_partA_failure':{'index_html':(O/'index.html').exists(),'paragraph_plan':(O/'_paragraph-plan.md').exists(),
        'pptx':len(list(O.glob('*.pptx'))),'docx':len(list(O.glob('*.docx'))),'companion_review':(O/'2.1.2-companion-visual-review.md').exists()},
    'source_freshness':{'reference_last_verified':'2026-04-12','observed_date':'2026-09-08','age_days':149,
        'required_rule':'Part 0.3 3-9 month quick check, then Part 0.5.5 update changed standards and last_verified',
        'changes_found':True,'reference_update_in_scope':False,'status':'BLOCKED'},
}
result_path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['component_counts','missing_referenced_assets','naming_noncompliant','literal_unreferenced_assets','conceptual_orphans','seven_headings_exact','exercise_extraction_exact','target_strings_verbatim','peer_snapshot_binding','current_review_files','quality_ref_yaml_exists']},ensure_ascii=False,indent=2))
