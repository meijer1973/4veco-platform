# Asset source and print inventory

Each conceptual visual has an editable SVG source and a paired PNG used in the student Markdown. There are nine concepts/placements and18physical files. All nine PNGs are used; no unused conceptual visual exists. SVG source counterparts are deliberately retained and referenced here as source links. No redundant source image is inserted into student pages to satisfy a literal image-reference check. This documents A6 nonblocking flagP0-1 without overwriting the independent review.

| SVG source | PNG print asset | Teaching placement | Exact line equations |
|---|---|---|---|
| [2.1.2_fig_1.svg](../_assets/2.1.2_fig_1.svg) | [2.1.2_fig_1.png](../_assets/2.1.2_fig_1.png) | Theory p2: total revenue first | TO=3Q; TK=180+1.2Q |
| [2.1.2_fig_2.svg](../_assets/2.1.2_fig_2.svg) | [2.1.2_fig_2.png](../_assets/2.1.2_fig_2.png) | Theory p3: add total costs at same scale | TO=3Q; TK=180+1.2Q |
| [2.1.2_fig_3.svg](../_assets/2.1.2_fig_3.svg) | [2.1.2_fig_3.png](../_assets/2.1.2_fig_3.png) | Theory p4: break-even and profit distance | TO=3Q; TK=180+1.2Q |
| [2.1.2_we_1.svg](../_assets/2.1.2_we_1.svg) | [2.1.2_we_1.png](../_assets/2.1.2_we_1.png) | Worked example: paragraph p6 / exercises p2 | TO=3Q; TK=180+1.2Q |
| [2.1.2_ex_1.svg](../_assets/2.1.2_ex_1.svg) | [2.1.2_ex_1.png](../_assets/2.1.2_ex_1.png) | Full graph support: paragraph p7 / exercises p3 | TO=2.5Q; TK=60+1Q |
| [2.1.2_ex_2.svg](../_assets/2.1.2_ex_2.svg) | [2.1.2_ex_2.png](../_assets/2.1.2_ex_2.png) | Learner completes TK-only base: paragraph p8 / exercises p4 | TO=4Q; TK=75+1Q |
| [2.1.2_ex_3.svg](../_assets/2.1.2_ex_3.svg) | [2.1.2_ex_3.png](../_assets/2.1.2_ex_3.png) | Answer4d: answers p2 | TO=4Q; TK=75+1Q |
| [2.1.2_ex_4.svg](../_assets/2.1.2_ex_4.svg) | [2.1.2_ex_4.png](../_assets/2.1.2_ex_4.png) | Answer6d: answers p3 | TO=7Q; TK=250+2Q |
| [2.1.2_ex_5.svg](../_assets/2.1.2_ex_5.svg) | [2.1.2_ex_5.png](../_assets/2.1.2_ex_5.png) | Exact approved target7d: answers p5 | TO=1.5Q; TK=500+0.8Q |

Graph geometry: original unmodified `build-scripts/lib/verify_svg_geometry.py`; verification log `geometry.txt`, actual emitted-SVG independent audit in reviewer evidence. All points, line endpoints, break-even guides and vertical profit segments were checked. Fixed-cost71 guided5 is textual and has no graph asset to repair; its answer uses€29 profit and35,5/36 boundary.

Colours and line styles distinguish TO (purple solid) and TK (orange dashed); text and axes name the totals and their units. All figures are full width in the final PDF. The longest target y-axis label uses12sourcepx to avoid collision and was reviewed in the actual full page; source SVG availability is preserved for future authorized publisher adaptation.
