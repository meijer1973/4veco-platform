"""Update A6 reviewer report only; retain original dated history and evidence."""
from pathlib import Path
import json,re,hashlib
from datetime import datetime,timezone
O=Path(__file__).resolve().parent.parent
stamp='20260908T090021Z'
prior=O/'evidence/reviewer-history-20260908T080621Z-report.md'
s=prior.read_text(encoding='utf-8-sig')
snapshot=O/f'evidence/reviewer-recheck-{stamp}-snapshot-start.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
now=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
old=json.loads(snapshot.read_text(encoding='utf-8-sig'))
drift=[x['path'] for x in old['files'] if sha(Path(x['path']).read_bytes()).upper()!=x['sha256'].upper()]
if drift:raise RuntimeError('Student snapshot changed during recheck: '+str(drift))
new='''## 1. Scope and current evidence

Independent A6 reviewer: `/root/comparison_sample_x/paragraph_review`, the same reviewer as the original content review. I did not author or edit student content, assets or the plan. This is a focused final recheck of the original isolated Part A experiment, not production, release, student-use, integration or companion approval. Other specialist verdicts do not determine this independent verdict. The separately known quality-reference freshness blocker remains outside the A6 content verdict.

Actual active intervals:

- Original review: **2026-09-08 07:51:22–08:06:21 UTC**.
- Focused recheck: **2026-09-08 09:00:21 UTC–END_TIME**. The intervening inactive interval is not counted as review work.

Actual runtime model identifier, reasoning setting, service tier and token counts: **unavailable**, as before. No children were spawned. Only the A6 report and uniquely named reviewer evidence were written.

The original report, session, final snapshot and audit are preserved respectively as `evidence/reviewer-history-20260908T080621Z-{report.md,session.json,snapshot.json,audit.json}`. The original evidence files are also retained. The earlier full review read only the original platform at `96416b6b5bd57094576e9aba0a42d682584ec479`, lessons at `f09fd6e88edc5049b026b16b0158e7e188091d2d`, and this sample's output. No other arm or candidate instructions were accessed in either interval.

Current reviewed author build: **08:41:17.334712–08:41:18.583199 UTC**, with Poppler rendering beginning **08:41:18.790385 UTC**, 120 dpi. Current snapshot: `evidence/reviewer-recheck-20260908T090021Z-snapshot-start.json`, SHA-256 **`SNAP_HASH`**. All individual artifact/page hashes are recorded there; **zero hash drift** occurred during this recheck.

The original review inspected all 22 full pages and rechecked six pages after its first corrections. This focused recheck inspected the six changed complete pages of the current output: **paragraaf 6, 7, 9 and opgaven 2, 3, 5**. All other 16 current page PNGs are byte-identical to the previously inspected pages. All three answer MD/HTML/PDF artifacts, all 18 SVG/PNG files and the target record retain their prior hashes. The six changed pages have no clipping, overlapping text, broken glyphs or detached essential graph instructions. The five-point summary and seven-heading sequence remain intact.

| Current PDF | SHA-256 |
|---|---|
| paragraaf.pdf | `fbc785027b0e55b0f160622e99539cc80724a099b65fb570bf6206d60dee3ab9` |
| opgaven.pdf | `402dc1fbc162db7af2e46e6b4b587e90eea84cf998b20412c7c4d6d2baaa0a19` |
| antwoorden.pdf, unchanged | `c53d37e809566dac7a7fbf9dbcf2688fb847c655022a744797f65d9747a55aa4` |

The independent audit was rerun under a unique filename against the current outputs. It verifies Markdown/HTML text and image parity, all HTML text blocks in PDF extraction, exact exercise extraction, the canonical target and actual SVG geometry. The rendered-page inspection supplements these checks. No separate responsive-browser or interactive-surface approval is implied.

'''.replace('END_TIME',now).replace('SNAP_HASH',sha(snapshot.read_bytes()))
s=s[:s.index('## 1.')]+new+s[s.index('## 2. Verdict'):]
s=s.replace('**0 open FAIL items; 3 nonblocking FLAG items**','**0 open FAIL items; 2 nonblocking FLAG items**')
s=s.replace('Scoped A6 content review after author corrections.','Scoped A6 content review, reaffirmed after the focused final recheck.')
s=s.replace('The initial upward-rounding practice gap was corrected.','The initial upward-rounding practice gap remains corrected; summary-condition FLAG P1-2 is now closed. Added comparison-and-retry feedback is appropriate and introduces no new required target operation.')
s=s.replace('| 1.6.2 | FLAG P1-2: summary abbreviates the break-even assumptions too heavily. |','| 1.6.2 | PASS after final correction: fixed price, constant variable cost per product and unchanged capacity are explicitly stated in the five-point summary. |')
start=s.index('**P1-2 — FLAG,')
end=s.index('\n\n## 5.',start)
s=s[:start]+'''**Resolved P1-2 — formerly FLAG, check 1.6.2, current paragraaf p.6/opgaven p.2:** the third summary point now explicitly names fixed price, constant variable costs per product and unchanged capacity. It still distinguishes a noninteger threshold from the first whole no-loss quantity. The full rendered box remains legible, limited to five points and positioned between worked example and Startopgaven. No action remains on this finding.

**Final feedback recheck — PASS, checks 1.5.4/1.5.6/1.7.2/1.7.5:** after Start 1–2, the student compares with the answer model and corrects a step only if needed. After independent 6, the student checks the calculation, axes, intersection and vertical profit segment, then retries an erroneous step before the target. “Zo nodig” avoids presuming that every learner made an error. The actions occur after attempted answers, retain the canonical route, and make no diagnostic, mastery or automatic-routing claim. They connect the existing answer model to an observable student action.

**Optional refinements, not additional defects:** explicit annotations beside the algebraic subtraction/division steps could help a learner whose equation manipulation is less secure. Minor ticks on the supplied badge graph could make interpolation less demanding. The existing prose already explains the algebraic operations and the base graph is geometrically correct and usable; neither refinement is required to sustain this A6 PASS. These are this reviewer's own judgements, not adoption of a specialist verdict.
'''+s[end:]
s=s.replace('The full guided detour adds 13 minutes, reaching 64 before feedback.','The full guided detour adds 13 minutes, reaching **64 before feedback and 68 with feedback**.')
s=s.replace('This is a reasonable planning estimate for students whose substitution, algebra and plotting are sufficiently fluent, not measured classroom evidence.','The plan assigns its four feedback minutes as 1 after Start, 2 after independent practice and 1 after the target; 51 + (1 + 2 + 1) = 55. This is a reasonable planning estimate for students whose substitution, algebra and plotting are sufficiently fluent, not measured classroom evidence. The comparison/retry allocation has no spare buffer when a learner needs substantial correction.')
s=s.replace('`evidence/reviewer-independent-audit.json` and `evidence/reviewer-audit.py`','`evidence/reviewer-recheck-20260908T090021Z-audit.json` and `evidence/reviewer-recheck-20260908T090021Z-audit.py`')
s=s.replace('Next action: retain the corrected content snapshot and this scoped PASS, carry P1-1 into classroom planning, consider the compact summary improvement P1-2, and complete the separately required remaining quality/release gates before any production or student-use claim.','''### Focused recheck read ledger

- Read the preserved original A6 report/session/snapshot/audit as history, retaining its original reference-read ledger above; those original instructions were not replaced by another arm's material.
- Read current paragraaf and opgaven source deltas, including summary, Start feedback, independent feedback, neutral wording and unchanged target. The audit read all three current MD/HTML/PDF files and all actual SVGs; decoded HTML image payloads were compared with the PNG files.
- Read current textbook-plan alignment and timing sections, `evidence/build-result.json`, `evidence/rendered-manifest.json`, current target record and the pinned original target-registry record.
- Visually read six current full pages: paragraaf 6/7/9 and opgaven 2/3/5. Hash comparison verified unchanged answers, all 18 assets, target, and the other 16 previously inspected pages. No teacher/student specialist report verdict was used as approval evidence.
- Recheck order: integrity/currentness comparison first; didactic and rendered delta review second; independent mathematical/target/parity rerun third. Current-snapshot drift check was zero. Exact interval and machine evidence are in `evidence/reviewer-recheck-20260908T090021Z-session.json`.

Next action: retain this current scoped A6 PASS and its snapshot, carry the honest 68-minute guided-route scheduling warning into teacher preparation, and run the separately required A7 quality-reference stage and remaining applicable gates before any production or student-use claim.''')
(O/'2.1.2-review.md').write_text(s,encoding='utf-8')
session={'reviewer':'/root/comparison_sample_x/paragraph_review','review_kind':'focused_final_A6_recheck','start_utc':'2026-09-08 09:00:21 UTC','end_utc':now,'original_active_interval':'2026-09-08 07:51:22–08:06:21 UTC','inactive_gap_excluded':True,'model':'unavailable','reasoning_setting':'unavailable','service_tier':'unavailable','tokens':'unavailable','files_edited':'A6 report and uniquely named reviewer evidence only','review_snapshot_sha256':sha(snapshot.read_bytes()),'snapshot_drift':drift,'report_sha256':sha((O/'2.1.2-review.md').read_bytes()),'verdict':'PASS','hard_fails_open':0,'flags_open':['P0-1','P1-1'],'flags_closed':['P1-2'],'full_pages_inspected':['paragraaf 6','paragraaf 7','paragraaf 9','opgaven 2','opgaven 3','opgaven 5'],'unchanged_previously_inspected_page_count':16}
(O/f'evidence/reviewer-recheck-{stamp}-session.json').write_text(json.dumps(session,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(session,ensure_ascii=False,indent=2))
