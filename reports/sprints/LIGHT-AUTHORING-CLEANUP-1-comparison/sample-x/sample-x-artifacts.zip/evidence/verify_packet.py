from pathlib import Path
from datetime import datetime, timezone
import re,json,hashlib,fitz,subprocess
from PIL import Image
O=Path(__file__).resolve().parent.parent
start=datetime.now(timezone.utc).isoformat()
records={}; errors=[]
target=json.loads((O/'evidence/target-record.json').read_text(encoding='utf-8'))['target_exercise']
headings=['Uitgewerkt voorbeeld','Startopgaven','Begeleide inoefening','Zelfstandige oefening','Doeloefening','Denkertje / Bonusopgave','Herhaling / Herhaling en interleaving']
sources={k:next(O.glob(f'* – {k}.md')) for k in ['paragraaf','opgaven','antwoorden']}
refs=set()
for k,path in sources.items():
 s=path.read_text(encoding='utf-8');h=path.with_suffix('.html').read_text(encoding='utf-8')
 images=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',s);refs.update(images)
 for im in images:
  if not (O/im).is_file(): errors.append(f'Missing {im}')
 if k!='antwoorden':
  assert re.findall(r'^## (.+)$',s,re.M)==headings
  assert target['context'] in s
  for q in target['subquestions']: assert q['prompt'] in s and f"**{q['label']})** " in s
  assert s.count('> - ')==5
 assert h.count('data:image/png;base64,')==len(images)
 assert '<link' not in h
 doc=fitz.open(path.with_suffix('.pdf'));bounds=[]
 for i,page in enumerate(doc):
  for b in page.get_text('blocks'):
   if b[0]<0 or b[1]<0 or b[2]>page.rect.width+0.5 or b[3]>page.rect.height+0.5: bounds.append([i+1,list(b[:4])])
 assert not bounds
 records[k]={'md_words':len(s.split()),'images':len(images),'pdf_pages':len(doc),'pdf_bytes':path.with_suffix('.pdf').stat().st_size,'out_of_page_text_blocks':bounds,'pdf_sha256':hashlib.sha256(path.with_suffix('.pdf').read_bytes()).hexdigest()}
 assert records[k]['pdf_bytes']>10000
 doc.close()
assert sources['paragraaf'].read_text(encoding='utf-8').split('## Uitgewerkt voorbeeld',1)[1]==sources['opgaven'].read_text(encoding='utf-8').split('## Uitgewerkt voorbeeld',1)[1]
assets=list((O/'_assets').iterdir()); paired=[]
for p in assets:
 assert re.fullmatch(r'2\.1\.2_(fig|ex|we|mc)_\d+\.(svg|png)',p.name)
 assert p.with_suffix('.png' if p.suffix=='.svg' else '.svg').is_file()
 if p.suffix=='.png':
  im=Image.open(p);paired.append({'base':p.stem,'png_size':list(im.size),'used_in_md':f'_assets/{p.name}' in refs})
  assert f'_assets/{p.name}' in refs
reports={'start_utc':start,'end_utc':datetime.now(timezone.utc).isoformat(),'pass':not errors,'errors':errors,'source_html_pdf_checks':records,'assets':paired,'source_output_exercise_parity':True,'approved_context_and_question_text_exact':True,'seven_headings_exact':True,'summary_five_points':True,'scope':'Author mechanical checks, not independent content or production approval'}
(O/'evidence/mechanical.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
print(json.dumps(reports,indent=2))
