"""Seal administrative comparison evidence after all assigned reviews and claim release."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

O = Path(__file__).resolve().parent.parent
E = O / 'evidence'

def read(name):
    return json.loads((E / name).read_text('utf-8-sig'))

def write(name, data):
    (E / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    now = datetime.now(timezone.utc).isoformat()
    quality = read('a7-quality-20260908T090436Z-session.json')
    snapshot = read('a7-quality-20260908T090436Z-snapshot.json')
    drift = []
    for item in snapshot['files']:
        path = Path(item['path'])
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
        if actual != item['sha256']:
            drift.append({'path': str(path), 'expected': item['sha256'], 'actual': actual})
    assert not drift, drift
    assert not (O / '2.1.2-quality-ref.yaml').exists()
    final_validation = read('final-validation.json')
    assert final_validation['exit_code'] == 1
    assert '1 error(s), 0 warning(s)' in final_validation['output']
    releases = read('worktree-release.json')['records']
    assert len(releases) == 2
    for release in releases:
        assert release['result']['exit_code'] == 0
        state = json.loads(release['result']['output'])
        assert state['ok'] and not state['lock']['present'] and not state['dirty']

    routing = read('review-routing.json')
    initial = routing['assignments'][0]
    initial['initial_nonblocking_flags'] = 3
    initial['final_nonblocking_flags'] = 2
    initial['total_active_seconds'] = 1083
    quality_duration = (datetime.fromisoformat(quality['active_end_utc'].replace('Z', '+00:00')) - datetime.fromisoformat(quality['active_start_utc'].replace('Z', '+00:00'))).total_seconds()
    routing['assignments'][3].update(start_utc=quality['active_start_utc'], end_utc=quality['active_end_utc'], wall_seconds=quality_duration, status='completed bounded inventory; mandatory A7 production requirement BLOCKED', verdict='BLOCKED', report='2.1.2-quality-record.md', snapshot_drift_count=0)
    routing.pop('active_review_intervals_planned', None)
    routing['active_review_intervals'] = 5
    routing['total_active_review_seconds'] = 899 + 708 + 542 + 184 + quality_duration
    routing['queue_accounting'] = 'Teacher queue 1587s; student dispatch queue approximately 1032s. Pure student slot contention cannot be separated from notification/session-recovery delay. These intervals are not active review time and are not asserted to be wholly idle.'
    write('review-routing.json', routing)

    stages = read('stages.json')
    stages['task_end_utc'] = now
    stages['end_definition'] = 'Administrative evidence seal after reviews, final normal validation and normal release of both owned claims; final inventory generation immediately follows.'
    stages['stages'][-1]['end_utc'] = now
    stages['elapsed_seconds'] = (datetime.fromisoformat(now) - datetime.fromisoformat(stages['task_start_utc'].replace('Z', '+00:00'))).total_seconds()
    stages['production_status'] = 'INCOMPLETE / BLOCKED'
    stages['local_comparison_assignment'] = 'Completed all authorised safe stages and independent blocker record; artifacts ready for immutable copying after inventory generation.'
    write('stages.json', stages)

    ledger = read('author-read-ledger.json')
    for item in ledger['files']:
        if item['path'].endswith('scripts\\validate-paragraph.js'):
            item['read_scope'] += ' Final targeted lines 330–366 reviewed for CRLF verdict-parser fallback; exact behavior reproduced read-only without modifying the report or validator.'
    ledger['updated_utc'] = now
    write('author-read-ledger.json', ledger)

    mechanical = read('mechanical.json')['source_html_pdf_checks']
    metrics = {
        'sealed_utc': now,
        'task_start_utc': stages['task_start_utc'],
        'elapsed_wall_seconds': stages['elapsed_seconds'],
        'author_active_time': None,
        'author_active_time_note': 'Broad author/stage intervals are recorded; fine active versus waiting time was not captured. Stages and reviews overlap.',
        'model': 'unavailable', 'reasoning': 'unavailable', 'tokens': None,
        'unique_content_reviewers': 3, 'unique_quality_record_reviewers': 1, 'unique_reviewers': 4,
        'active_review_intervals': 5, 'release_reviewers': 0,
        'review_active_seconds': routing['total_active_review_seconds'],
        'teacher_queue_seconds': 1587, 'student_dispatch_queue_seconds_approximate': 1032,
        'pure_student_slot_wait_seconds': None,
        'runtime_detour_seconds': None,
        'runtime_detour_note': 'Unused isolated WeasyPrint install after bare-python import failure; exact separate duration unrecorded. Shared runtime rendered every PDF.',
        'three_pdf_builds': 6, 'repair_render_rounds': 5, 'grouped_feedback_cycles': 3,
        'pdf_pages': 22, 'svg_png_pairs': 9, 'markdown_image_uses': 12,
        'pdfs': mechanical,
        'final_content': {'A6': 'PASS / 0 FAIL / 2 flags', 'teacher': 'PASS 14/14', 'student': 'PASS 12/12'},
        'quality_stage': 'BLOCKED; no compliant quality_ref YAML',
        'normal_validator': {'exit_code': 1, 'errors': 1, 'warnings': 0, 'error': 'MISSING 2.1.2-quality-ref.yaml', 'review_parser': 'Legacy fallback due to CRLF blank line; visible structured PASS is independently review-hash-bound.'},
        'frozen_A7_files_rechecked': len(snapshot['files']), 'final_snapshot_drift': drift,
        'worktree_claims_released': True,
    }
    write('final-metrics.json', metrics)
    write('closure-integrity.json', {'checked_utc': now, 'frozen_A7_files': len(snapshot['files']), 'drift': drift, 'normal_validator_exit': 1, 'claims_released': True, 'student_content_unchanged_after_final_build': True})

    rows = '\n'.join(f"| {kind} | {v['pdf_pages']} | {v['pdf_bytes']:,} | {v['md_words']:,} |" for kind, v in mechanical.items())
    report = f'''# Isolated original-snapshot comparison — §2.1.2

The authorised local comparison is complete: full Part A revision, rendering, independent content reviews and the independent mandatory-stage blocker record are retained. **Full Part A production and the handoff remain BLOCKED.** No compliant quality_ref YAML, release approval, student-use approval, publication, push, PR, merge or deployment was produced in this arm.

Output root: `{O}`. The unchanged shared prompt is `evidence/shared-prompt.md`. The final copy allowlist and SHA-256 values are in `evidence/final-inventory.json`; copy that manifest itself as well. Dependencies/caches are explicitly excluded. Both original paired worktrees remain at their assigned commits, clean, with their own claims released normally; directories and artifacts remain in place.

| Final deliverable | PDF pages | PDF bytes | Markdown words |
|---|---:|---:|---:|
{rows}

Word counts split Markdown on whitespace, including markup/captions; they are not reading-level or learner-timing measurements. The packet contains three MD/HTML/PDF sets, nine SVG/PNG pairs, a paragraph-specific builder, the dedicated plan, three substantive review reports, blocked quality record, blocked handoff, all 22 full-page PNGs and reproducible check/source history.

Foundation structural/current-approved-use checks and exact `lesson_authoring` and `paragraph_production` action checks passed at the pinned original platform `96416b6b5bd57094576e9aba0a42d682584ec479` and lessons `f09fd6e88edc5049b026b16b0158e7e188091d2d`. The exact owned De Korenaar target context/a–d remains unchanged; its record status was not promoted. The common smoothie example retains 180 / 1.20 / 3.00. Original geometry checks and independent SVG/source/HTML/PDF audits passed. A7 bound 64 frozen files and matched A6 55/55, teacher 52/52 and student 52/52 snapshot entries. The final closure check found zero drift.

| Independent assignment | Actual active UTC on 2026-09-08 | Active seconds | Result |
|---|---|---:|---|
| A6 original review | 07:51:22–08:06:21 | 899 | PASS after repairs |
| Teacher review | 08:33:26–08:45:14 | 708 | PASS 14/14; TQ-01 closed |
| Student review | 08:50:04–08:59:06 | 542 | PASS 12/12; no required revision |
| Same A6 reviewer, focused refresh | 09:00:21–09:03:25 | 184 | PASS; 0 FAIL, 2 flags |
| Separate A7 quality record | 09:04:36–09:14:40.9596498 | {quality_duration:.3f} | Bounded inventory complete; production BLOCKED |

There were four unique reviewers, five active intervals and zero release reviewers. Total active reviewer time was {routing['total_active_review_seconds']:.3f} seconds. Teacher dispatch queue was 1,587 seconds. Student dispatch queue was approximately 1,032 seconds; pure slot contention cannot be separated exactly from notification/session-recovery delay. Neither queue interval is active review time, and neither is assumed wholly idle. Start was 07:26:45 UTC; administrative seal was {now}. Broad stages and their overlaps are in `evidence/stages.json`. Fine author active time, exact separate runtime-detour duration, backend/model identity, reasoning settings and tokens were not exposed or measured; no values are invented.

Six complete three-PDF builds occurred: one initial build plus five repair rerenders across author visual QA, A6 and teacher feedback cycles. The repair history includes question-letter retention, summary list restoration, keeping graph instructions/table/figure together, a long-axis-label collision, compulsory and guided noninteger break-even practice, honest route timing, earlier answer-model checks with conditional retry and explicit summary model conditions. An attempted extra printed support shortcut was removed after the reviewer identified the compact-only route constraint. `evidence/repair-rounds.json` records each round and its timestamp precision; no fixed count of unrelated “defects” is inferred from the number of renders.

The final A6 flags concern the nine indirectly referenced editable SVG counterparts and scheduling the full guided route. All nine conceptual visuals are used through their PNGs; the necessary SVG sources remain documented in the asset inventory. The compulsory core is planned as 51 + 4 = 55 minutes, with little correction buffer. Full guided use is 68 minutes including feedback and requires separate lesson/homework scheduling. No learner timings were measured. Algebra-operation side annotations and finer badge drawing-base guides are optional student refinements and were not adopted; no required student revision remains.

The separate `2.1.2-quality-record.md` documents actual official 2026 framework changes and the original mandatory Part 0.3/0.5 reference-update requirement. The reference update is excluded here; a passing stub would misrepresent completion. Authorised reference maintenance, renewed independent A7 and normal validation are still required before downstream readiness gates. The final original validator exited 1 with exactly one error, missing `2.1.2-quality-ref.yaml`, and zero warnings (`evidence/final-validation.*`). Its review parser accepted the legacy fallback because a CRLF blank line prevented parsing the visible structured PASS; a read-only reproduction gives null on raw CRLF and PASS on LF-normalized text. No report or validator was rewritten to hide this limitation. The semantic PASS comes from the independent report and A7 hash binding. The source lesson lane checker likewise has no changed Git paths to classify in this output-only experiment; its exit 1 is an applicability limit, not a passing lesson-output PR check.

All PDF builds used shared Python 3.14.3 at `C:/Python314/python.exe`, user-site WeasyPrint 68.1, original Pango path, Pandoc 3.9.0.1, Node 24.13.1 and permitted shared Sharp 0.35.2. Initial setup errors and remedies are recorded in stages/runtime evidence. The unused isolated WeasyPrint target installation never rendered a PDF. Its 1,346 files / 47,793,495 bytes are excluded, along with regenerable caches.

The actual instruction/reference read manifest distinguishes whole-file, excerpt, programmatic and truncated reads; each independent reviewer has its own read ledger. One early unfiltered agent inventory exposed a completed preflight runtime/governance-routing summary. It contained no paragraph draft, answer or graph; no candidate file/diff or other-arm artifact was opened. It was not used as an authoring instruction. The exact observed scope and limitation are in `evidence/isolation-and-exclusions.md`.

Automatic approval review rejected deletion of the unused `evidence/python-runtime` directory with only **“blocked by policy”**. No more specific reason was supplied. Deletion was not retried or worked around; the directory remains in place and is excluded from copying.
'''
    (O / '2.1.2-comparison-report.md').write_text(report, encoding='utf-8')
    print(json.dumps({'sealed_utc': now, 'review_active_seconds': metrics['review_active_seconds'], 'source_snapshot_drift': len(drift), 'claims_released': True, 'production': 'BLOCKED'}, indent=2))

if __name__ == '__main__':
    main()
