$ErrorActionPreference = 'Stop'
$reviewOutput = 'C:\wt\reorganize\comparison\sample-x\output\2.1.2 Opbrengsten, winst en break-even'
$platformSource = 'C:\wt\reorganize\comparison\sample-x\4veco-platform'
$lessonSource = 'C:\wt\reorganize\comparison\sample-x\4veco-lessen'
$manifest = Get-Content -Raw -LiteralPath (Join-Path $reviewOutput 'evidence/rendered-manifest.json') | ConvertFrom-Json
$target = Get-Content -Raw -LiteralPath (Join-Path $reviewOutput 'evidence/target-record.json') | ConvertFrom-Json
$paragraph = Get-Content -Raw -LiteralPath (Join-Path $reviewOutput '2.1.2 Opbrengsten, winst en break-even – paragraaf.md')
$exercises = Get-Content -Raw -LiteralPath (Join-Path $reviewOutput '2.1.2 Opbrengsten, winst en break-even – opgaven.md')
$answers = Get-Content -Raw -LiteralPath (Join-Path $reviewOutput '2.1.2 Opbrengsten, winst en break-even – antwoorden.md')
$expectedHeadings = @('Uitgewerkt voorbeeld','Startopgaven','Begeleide inoefening','Zelfstandige oefening','Doeloefening','Denkertje / Bonusopgave','Herhaling / Herhaling en interleaving')
$headings = @([regex]::Matches($exercises,'(?m)^## (.+)\r?$') | ForEach-Object {$_.Groups[1].Value.Trim()})
$targetChecks = @($target.target_exercise.subquestions | ForEach-Object {
    [ordered]@{label=$_.label; paragraph_contains_exact_prompt=$paragraph.Contains($_.prompt); exercises_contains_exact_prompt=$exercises.Contains($_.prompt)}
})
$refs = @([regex]::Matches(($paragraph + $exercises + $answers),'!\[[^\]]*\]\(([^)]+)\)') | ForEach-Object {$_.Groups[1].Value} | Sort-Object -Unique)
$assetChecks = @($refs | ForEach-Object {
    $asset = Join-Path $reviewOutput $_
    [ordered]@{reference=$_; png_exists=(Test-Path -LiteralPath $asset); svg_exists=(Test-Path -LiteralPath ([IO.Path]::ChangeExtension($asset,'svg')))}
})
$artifactFiles = @(Get-ChildItem -LiteralPath $reviewOutput -File | Where-Object {$_.Extension -in @('.md','.html','.pdf') -and $_.Name -match ' – (paragraaf|opgaven|antwoorden)\.'} | ForEach-Object {$_.FullName})
$artifactFiles += @((Join-Path $reviewOutput '2.1.2-textbook-plan.md'),(Join-Path $reviewOutput 'evidence/target-record.json'),(Join-Path $reviewOutput 'evidence/rendered-manifest.json'))
$artifactFiles += @($manifest.artifacts | ForEach-Object {$_.pages} | ForEach-Object {$_})
$artifactFiles += @($refs | ForEach-Object {(Join-Path $reviewOutput $_); [IO.Path]::ChangeExtension((Join-Path $reviewOutput $_),'svg')})
$artifactHashes = @($artifactFiles | Sort-Object -Unique | ForEach-Object {
    $file = Get-Item -LiteralPath $_
    [ordered]@{path=$file.FullName; bytes=$file.Length; sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLower(); last_write_utc=$file.LastWriteTimeUtc.ToString('o')}
})
$readSpecs = @(
    @($platformSource,'AGENTS.md','Original root instructions; read-first, operating discipline, design principles, review routing, quality and output boundaries; unrelated deployment details not used as review criteria'),
    @($platformSource,'docs/workflows/paragraph-lane-vocabulary.md','Full lane definition'),
    @($platformSource,'docs/workflows/textbook-paragraph-lane.md','Full Part A runbook'),
    @($platformSource,'BUILD-PARAGRAPH.md','Common preconditions, Part A input/production/review and verification sections; heading scan for lane navigation'),
    @($platformSource,'agents/student-experience-review-agent.md','Full review specification, Pass 0–7, rubric, failure conditions and verdict rules'),
    @($platformSource,'skills/econ-exercise-builder.md','Operational Part A timing, seven sections, fading, target coverage, paper route, answers and graph requirements'),
    @($platformSource,'skills/econ-textbook-paragraph.md','Structure/writing/definition/formula/graph and staged visual/triple-coding requirements'),
    @($platformSource,'skills/econ-didactiek.md','Core philosophy, Part A inheritance, differentiation, neutral framing and support routes'),
    @($platformSource,'references/owned/course-blueprint-pedagogical-boundaries.md','Full prior-teaching/preview boundary'),
    @($platformSource,'references/authored/book-outlines/book-2-outline.md','Entry prerequisites, purpose/exit context, 2.1 role matrix and 2.1.2 semantic/prerequisite row'),
    @($lessonSource,'specifications/product-vision.md','Strategic vision through boundary rules'),
    @($lessonSource,'specifications/product-end-state.md','Purpose, product definition, exercise-first/affordance/motivation/rendered-review principles; full-route claims excluded'),
    @($lessonSource,'specifications/companion-core-specifications.md','Purpose and scope boundary only; companion review not in assignment'),
    @($lessonSource,'Boek 2 - Kosten, opbrengsten, elasticiteit en surplus/2.1 Hoofdstuk Kosten en opbrengsten/_chapter-plan.md','Full chapter scope and context'),
    @($lessonSource,'Boek 2 - Kosten, opbrengsten, elasticiteit en surplus/2.1 Hoofdstuk Kosten en opbrengsten/2.1.1 Kostenstructuren/2.1.1 Kostenstructuren – paragraaf.md','Lines 1–195: original cost definitions/formulas, tables, worked example, recall and beginning graph retrieval'),
    @($lessonSource,'Boek 1 - Grondslagen, vraag en aanbod/1.1 Hoofdstuk Economisch denken en rekenen/1.1.3 Grafieken en tabellen/1.1.3 Grafieken en tabellen – paragraaf.md','Theory on tables, axes, scales, coordinates and interpolation; headings/graph-related instruction scan')
)
$readLedger = @($readSpecs | ForEach-Object {
    $path = Join-Path $_[0] $_[1]
    [ordered]@{path=$path; read_scope=$_[2]; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()}
})
$skillPath = 'C:\Users\meije\.codex\plugins\cache\openai-primary-runtime\pdf\26.905.11957\skills\pdf\SKILL.md'
$readLedger += [ordered]@{path=$skillPath; read_scope='Full; read-only PDF inspection workflow'; sha256=(Get-FileHash -LiteralPath $skillPath -Algorithm SHA256).Hash.ToLower()}
$evidence = [ordered]@{
    reviewer='/root/comparison_sample_x/student_review'
    review_start_utc='2026-09-08T08:50:04Z'
    audit_generated_utc=[DateTime]::UtcNow.ToString('o')
    model_settings_tokens='Unavailable: no observable actual model, settings or token meter supplied to reviewer; not inferred'
    scope='Independent printed Part A student-experience review; no content authorship, source mutation, companion/browser-route approval, publication or release authorization'
    platform_head=(& git -C $platformSource rev-parse HEAD)
    lesson_head=(& git -C $lessonSource rev-parse HEAD)
    inspection='All 22 manifest-listed PNG pages viewed individually at full page; contact sheets were not used as substitute; original Markdown used for text verification'
    pages_inspected=@($manifest.artifacts | ForEach-Object {[ordered]@{kind=$_.kind; count=$_.page_count; pages=$_.pages}})
    checks=[ordered]@{
        exact_target_context_in_paragraph=$paragraph.Contains($target.target_exercise.context)
        exact_target_context_in_exercises=$exercises.Contains($target.target_exercise.context)
        exact_target_prompts=$targetChecks
        canonical_seven_heading_order=(($headings -join '|') -eq ($expectedHeadings -join '|'))
        headings=$headings
        exercise_section_identical_to_integrated_paragraph=($paragraph.Substring($paragraph.IndexOf('## Uitgewerkt voorbeeld')) -eq $exercises.Substring($exercises.IndexOf('## Uitgewerkt voorbeeld')))
        referenced_unique_graphs=$refs.Count
        assets=$assetChecks
        printed_pages=(@($manifest.artifacts | ForEach-Object {$_.pages} | ForEach-Object {$_}).Count)
    }
    read_ledger=$readLedger
    artifact_hashes=$artifactHashes
}
$destination = Join-Path $reviewOutput 'evidence/student-review-evidence-20260908.json'
$evidence | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $destination -Encoding utf8
[ordered]@{evidence=$destination; artifact_hash_count=$artifactHashes.Count; checks=$evidence.checks} | ConvertTo-Json -Depth 8
