# Reproduce the isolated Part A packet

Canonical editable lesson sources are the three root Markdown files, the paired `_assets` SVG/PNG files, and root `build_pdf.py`. Review/evidence files describe the actual run. This folder is outside the source lesson worktree and must remain isolated.

Runtime used: Node24.13.1, Python3.14.3 at `C:\Python314\python.exe`, Pandoc3.9.0.1, user-site WeasyPrint68.1, Sharp0.35.2 from permitted shared node_modules. `build_pdf.py` prepends `C:\msys64\mingw64\bin` for Pango. The excluded `evidence/python-runtime` installation is unused.

Render from this paragraph folder:

```powershell
$env:PYTHONUTF8='1'
& C:\Python314\python.exe '.\build_pdf.py'
& C:\Python314\python.exe '.\evidence\render_pages.py'
& C:\Python314\python.exe '.\evidence\verify_packet.py'
```

To intentionally regenerate authored source/assets, first review the corresponding paragraph-specific generators. The initial `evidence/create_plan.py` and `evidence/record_evidence.py` are historical planning/evidence scripts and must not be rerun on the final packet. The initial plan script is historical planning evidence and must not overwrite the repaired final plan or stage log. `evidence/author_content.py` contains the final repaired prose; `evidence/build_graphs.py` contains the graph specifications and calls the original unmodified geometry verifier before rasterization:

```powershell
$env:PYTHONUTF8='1'
& C:\Python314\python.exe '.\evidence\author_content.py'
& C:\Python314\python.exe '.\evidence\build_graphs.py'
if ($LASTEXITCODE -ne 0) { throw 'Geometry failed; stop before rasterization' }
$env:NODE_PATH='C:\wt\reorganize\4veco-platform\node_modules'
node '.\evidence\rasterize.cjs'
```

A rerender changes artifact hashes and requires affected review evidence to be renewed. Do not treat an older review as approval of changed output. PDF creation/editing also inherits the installed PDF skill's artifact-operation protocol and full-page inspection requirement; these shell commands do not replace those requirements.

Final mandatory normal Part A validation is run from the pinned original platform worktree:

```powershell
node '.\scripts\validate-paragraph.js' --mode part-a 'C:\wt\reorganize\comparison\sample-x\output\2.1.2 Opbrengsten, winst en break-even'
```

Expected result in this scope: one missing quality_ref error. The mandatory reference freshness update is out of scope, so no passing stub may be substituted. Independent content PASS, correct geometry, clean source worktrees and existing PDFs do not make production complete. Handoff remains BLOCKED.

For immutable copying, exclude `evidence/python-runtime`, any `__pycache__`, `.pyc` and temporary runtime caches. Preserve root deliverables, `_assets`, all full page PNGs, contact sheets, source/generator scripts, check logs, review/session/read manifests, prompt history and final hash inventory. Do not delete the excluded runtime via a workaround to the earlier automatic approval rejection.
