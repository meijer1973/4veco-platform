"""INITIAL PLAN generator retained as authoring history; do not rerun on the final packet.
HOW TO ADAPT: use the final textbook plan as canonical; later independent-review repairs were applied to that plan.
This initial script also creates initial stage evidence, which must not overwrite the historical log.
"""
import json, hashlib
from pathlib import Path
from datetime import datetime, timezone
OUT = Path(__file__).resolve().parent.parent
P = OUT.parents[1] / '4veco-platform'
L = OUT.parents[1] / '4veco-lessen'
CH = L / 'Boek 2 - Kosten, opbrengsten, elasticiteit en surplus/2.1 Hoofdstuk Kosten en opbrengsten/_chapter-plan.md'
meta = json.loads((P/'references/authored/book-outlines/book-2-outline.meta.json').read_text(encoding='utf-8'))
registry = json.loads((P/'references/authored/course-target-exercises.json').read_text(encoding='utf-8'))
target = next(x for x in registry['exercises'] if x['id']=='2.1.2')
pin = next(x for x in meta['target_registry_pins'] if x['id']=='2.1.2')
sha = lambda p: hashlib.sha256(p.read_text(encoding='utf-8').replace('\r\n','\n').replace('\r','\n').encode()).hexdigest()
assert sha(CH)==meta['read_only_lesson_evidence']['chapter_plans'][0]['sha256']
(OUT/'evidence/target-record.json').write_text(json.dumps(target,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'evidence/foundation-pins.json').write_text(json.dumps({'metadata':meta,'target':target,'chapter_plan_sha256':sha(CH)},ensure_ascii=False,indent=2),encoding='utf-8')
rows=[]
for h in meta['holds']:
    scope = any(s in ['book:2','chapter:2.1','paragraph:2.1.2'] for s in h['scope'])
    effect = 'RELEASED' if h['status']=='released' else ('BLOCKS' if scope and any(a in h['blocks'] for a in ['lesson_authoring','paragraph_production']) else 'NOT_APPLICABLE')
    assert effect!='BLOCKS'
    rows.append(f"| {h['id']} | {h['status']} | {'yes' if scope else 'no'} | lesson_authoring; paragraph_production | {', '.join(h['blocks'])} | {', '.join(h['permits'])} | {', '.join(h['resolution_actions'])} | {effect} | {json.dumps(h['release_evidence'],ensure_ascii=False)} |")
pins='\n'.join(f"| {s['source_kind']} path / SHA-256 | `{s['path']}` / `{s['sha256']}` |" for s in meta['authority_sources'])
plan=f'''# Part A Textbook Plan: 2.1.2 Opbrengsten, winst en break-even

Created from the dedicated template before content authoring. Scope: local comparison revision only; source lesson worktree is read-only. Source snapshots: platform `96416b6b5bd57094576e9aba0a42d682584ec479`; lessons `f09fd6e88edc5049b026b16b0158e7e188091d2d`.

## Book foundation check

### Authority, outline, chapter, and target pins

| Required pin | Exact value/evidence |
|---|---|
{pins}
| Active v6 version | v6-three-year umbrella |
| Active detailed v5 version | v5 |
| Approved outline path/version | references/authored/book-outlines/book-2-outline.md / {meta['version']} |
| Outline semantic SHA-256 | {meta['semantic_authority']['sha256']} |
| Outline approval status | approved_with_holds; owner approved; lifecycle proof in foundation-pins.json |
| Chapter-plan path | {CH.as_posix()} |
| Chapter-plan version | lesson commit f09fd6e88edc5049b026b16b0158e7e188091d2d; no own version field |
| Chapter-plan SHA-256/currentness | {sha(CH)}; canonical LF hash matches outline metadata |
| Target registry record ID/status | 2.1.2 / {pin['target_status']} |
| Target record SHA-256 | {pin['target_record_sha256']} |
| Structural currentness | npm.cmd run check:book-outline-currentness; PASS, evidence/foundation-structural.txt |
| Approved-use currentness | npm.cmd run check:book-outline-currentness -- --require-approved; PASS, evidence/foundation-approved.txt |

The target status string is not silently promoted. Exact owner-approved replacement, integration commit and released H-212-STALE-REF authorize this pinned target. Historical outline row wording is read with its current lifecycle projection.

### Canonical paragraph semantics

| Required semantic decision | Paragraph-specific value/evidence |
|---|---|
| Paragraph role | Add TO=P×Q, GO=TO/Q, winst=TO−TK, algebraic break-even, and TK/TO graph zones (outline §2.1 role matrix). |
| Chapter dependency | §2.1.1 cost relations precede §2.1.2; §1.1.3 graph/function skills supply representational prerequisites. |
| Incoming prerequisites | Cost substitution, TK=TCK+TVK, totals versus averages, linear equation manipulation, coordinate reading/plotting and units. |
| Explicit non-goals | Marginal costs/revenue, MO=MK, optimal output/price, demand or supply changes, elasticity, welfare areas; no new method through bonus. |
| Downstream prepares-for | §2.1.3 total-to-increment comparisons, §2.1.4 consolidation, §2.2.2 revenue. |
| Retrieval | Opgave 1 cost substitution/units; Opgave 2 compact current concept check. Re-activate graph coordinates in explicit instruction and guided support. |
| Interleaving | Opgave 9: total/average cost units and spreading fixed costs (§2.1.1); no new theory. |
| Operation emphasis | Formula choice, substitution, comparison, linear equation solving, exact graph construction/read-off, continuous/whole-unit interpretation, bounded conclusion. |
| Misconception boundary | Omzet is not winst; GO=P requires fixed unit price and Q>0; break-even means equal nonzero totals; profit is vertical distance, never an area. |
| Model conditions/relevant range | One named period per context; all production is sold; Q≥0; fixed price and per-unit variable cost; unchanged capacity/cost structure in the plotted range; GO only Q>0. Target calculations at 500–1,000; axes show mathematical extensions down to 0, explained as model intercepts rather than observed production. |

| Prerequisite | Classification | Evidence and support decision |
|---|---|---|
| Basic multiplication/subtraction | previously_taught_probably_secure | A04 prior curriculum; small retrieval calculation still checks use. No observed learner mastery claimed. |
| §2.1.1 TK functions and total/average units | previously_taught_retrieval_required | Approved §2.1.1 target plus pinned existing teaching; Opgave 1 and 9. |
| Linear equations/plotting | previously_taught_not_secure_enough_to_assume | §1.1.3 graph/function teaching alone does not prove security; theory gives explicit graph method, example reworks algebra, guided route fades support. |
| Book 1 supplied revenue/profit formulas | preview_or_familiarity_only | Owned pedagogical boundary; formal TO/GO/winst/break-even taught here in full. |
| Break-even algebra and vertical profit distance | new_formal_learning | Approved target a–d; explicit explanation, worked example, guided, independent and target practice. |

### Open holds and current-action effect

| Hold ID | Status | Scope match? | Current action | Listed in blocks | Listed in permits | Resolution action | Effect | Release evidence |
|---|---|---|---|---|---|---|---|---|
{chr(10).join(rows)}

### Foundation verdict

Current actions: lesson_authoring; paragraph_production.

Foundation verdicts: **PASS_FOR_LESSON_AUTHORING**; **PASS_FOR_PARAGRAPH_PRODUCTION**. Both exact action commands pass (evidence/foundation-authoring.txt and foundation-production.txt). The unrelated open holds and the book-root assembly hold do not block this paragraph. This verdict is separate from content quality and production validation.

## Part A backward-design plan

### Goals and target route

Use target-record.json unchanged. Four goals: calculate/interpret TO, GO and profit; distinguish continuous break-even from first whole no-loss quantity; construct TK/TO and zones; mark profit at a fixed Q as vertical distance. The registry source is a reviewed owner-approved textbook target, not an official CvTE paper, so an official exam-source/correction-model trace is not applicable. Original answer forms and target a–d are preserved verbatim.

| Lesson goal | Target subquestion/operation | Worked example | Start check | Guided practice | Independent practice | Covered/gap |
|---|---|---|---|---|---|---|
| TO/GO | a: TO function, GO=P for Q>0 with unit | Step 1 | 2a | 4a, 5a | 6a | Covered |
| Profit | b: two Q substitutions; compare TO−TK | Step 2, 80/150 smoothies | 2b | 3a, 4b, 5b | 6b, 40/80 tickets | Covered |
| Break-even | c: algebra TO=TK; continuous quantity and upward whole-unit interpretation | Step 3, exact 100 plus explanation of noninteger case in theory | 2b equality meaning | 3b, 4c, 5c | 6c; noninteger transfer in target | Covered |
| Graph | d: axes, units, TK and TO, BE point, zones | Step 4; staged theory fig_1–3 | retrieval handled in instruction (no long Start graph) | 3 read full plot; 4 complete base; 5 verbal without plot | 6d constructs plot | Covered |
| Profit distance | d: €200 at Q=1,000 as vertical segment, no area | Step 4: €90 at Q=150 | 2b misconception | 3a, 4d, 5b | 6d at Q=80 | Covered |

### Exercise, explanation, and worked-example sequence

Target-first design is fixed above before prose. Exact seven exercise headings; summary box after worked example, before Startopgaven. All support printed. Contexts: common smoothiebar (theory/example), poster studio retrieval, notebooks recognition, badges partial construction, keyrings verbal practice, school theatre independent, De Korenaar target, book sale optional critique, ceramics cumulative. Check against the supplied chapter/prerequisite snapshot; no foodtruck/fietsenmaker/sportshirt independent reuse.

Whole-lesson core equation: motivation 2 + instruction 10 + worked example 7 + compact summary/transitions 2 + actual Startopgaven 6 + actual Zelfstandige oefening 11 + actual Doeloefening 12 = **50 minutes**, leaving 5 minutes for feedback. Start: 1 (4), 2 (2). Independent: 6a (1), 6b (2), 6c (2), 6d (6). Target: a (1), b (2), c (3), d (6). Estimates assume calculator, ruler and squared paper, using already-taught substitution. They are planning estimates, not observed learner timings.

Optional guided use: 3 (2), 4 (4), 5 (3) = 9 minutes. For a support lesson, use 3–5 instead of the 11-minute independent block, then use independent 6 as homework: 48 minutes + 5 minutes feedback = 53. The default printed short route remains unchanged; teacher chooses support without lowering the target or asserting automatic routing. Bonus 8 (8–10) and cumulative 9 (4–5) are after core/homework; they are not added to the 50-minute core claim.

### Textbook visuals and answer model

Graphs: fig_1 TO only; fig_2 add TK at identical scale; fig_3 add break-even and vertical difference; we_1 full worked-example solution; ex_1 notebook fully labeled; ex_2 badge TK-only base; ex_3 badge solution; ex_4 theatre answer; ex_5 bakery target answer. All raw SVG → repository Python geometry verifier → Sharp PNG at 720 px; no altered graph skill or local mirror. Every curve/point/reference is computed from equations and inspected after rasterization. Vertical axis is totals (€ per period), not price. Small-font guard is resolved by full-width figures and explicit full-page review.

Answer procedure: 1. Opbrengst en gemiddelde opbrengst; 2. Totale bedragen en winst; 3. Break-even en gehele aantallen; 4. Tekenen en interpreteren. Partial tasks use the relevant step, never an alternative shortcut. Substitution, units, why statements and graph solution references for every relevant question. Round money to cents; preserve algebraic value before operational whole-unit rounding.

### Specification fulfilment and quality gate

| Requirement | Evidence | Review/proof | Status before authoring |
|---|---|---|---|
| Full approved operation chain | plan, three source MDs, pinned target | independent paragraph review passes 0–2 | planned |
| Paper route and ≤55 minutes | exact headings, guided fading, above equation | teaching/student checks | planned |
| Accurate legible graphs | SVG/PNG pairs, geometry log, final page PNGs | full rendered-page inspection | planned |
| Reproducible outputs | build_pdf.py, 3 HTML/PDF files | mechanical source/render checks | planned |
| Quality record | independent freshness-stage record | stop at stale inspectie reference | blocked by shared scope |

Quality floor: typical 4 vwo student can perform the intended actions with supplied teaching; no misleading calculation, missing graph, weak route, unreadable page, or fabricated PASS. Vision pillars: exercise-first, visual/dual coding, student usability (advantage); readable printable files (parity). Improvement included now: explicit adjacent whole-unit verification, grouped answer actions and positive support route. Reject scope creep: marginal theory and companion production.

### Part A review and Part B handoff

Author is comparison_sample_x. Original routing requires independent econ-paragraph-review and a separate independent quality-ref agent. Reviewer(s) may review but never author the content. At most one child reviewer at a time. As no student-use/release claim is made, release review is excluded by assignment; substantive reviewer roles and observed settings are recorded. Final artifacts remain local. Quality-reference stage is explicitly incomplete due to the common mandated reference freshness update outside scope. Handoff must remain BLOCKED for downstream production until quality-reference validity is restored through authorized source work and applicable release review is completed.
'''
(OUT/'2.1.2-textbook-plan.md').write_text(plan,encoding='utf-8')
ledger={'task_start_utc':'2026-09-08T07:26:45Z','author':'comparison_sample_x','model':'unavailable (inherited runtime setting not exposed)','reasoning_setting':'unavailable','actual_tokens':None,'stages':[{'stage':'setup_and_instruction_read','start_utc':'2026-09-08T07:26:45Z','end_utc':datetime.now(timezone.utc).isoformat()},{'stage':'plan_and_author','start_utc':datetime.now(timezone.utc).isoformat(),'end_utc':None}],'initial_failures':['Source discovery used incorrect book folder name; corrected using rg --files.','One product-end-state read used platform-relative path; corrected to sibling lessons.'],'scope':'local isolated output; sources read only; no publication'}
(OUT/'evidence/stages.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
print(OUT/'2.1.2-textbook-plan.md')
