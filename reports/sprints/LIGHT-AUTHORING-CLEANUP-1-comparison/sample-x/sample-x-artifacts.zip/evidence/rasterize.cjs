// HOW TO ADAPT: Rasterize only after build_graphs.py verifies every actual SVG.
const fs=require('fs'),path=require('path'),sharp=require('sharp');
const out=path.resolve(__dirname,'..','_assets');
(async()=>{for(const name of fs.readdirSync(out).filter(x=>x.endsWith('.svg'))){await sharp(fs.readFileSync(path.join(out,name))).resize(720).png().toFile(path.join(out,name.replace('.svg','.png')));console.log(name+' -> PNG');}console.log('Sharp '+sharp.versions.sharp);})();
