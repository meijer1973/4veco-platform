"""Build a local, dependency-excluding SHA-256 inventory; never copy or delete files."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os

OUTPUT = Path(__file__).resolve().parent.parent
DESTINATION = OUTPUT / "evidence" / "final-inventory.json"
EXCLUDED_RUNTIME = OUTPUT / "evidence" / "python-runtime"


def regular_files(root):
    for directory, subdirectories, filenames in os.walk(root, followlinks=False):
        directory = Path(directory)
        subdirectories[:] = [name for name in subdirectories if not (directory / name).is_symlink()]
        for name in filenames:
            path = directory / name
            if not path.is_symlink():
                yield path


def main():
    files = []
    excluded = []
    for path in regular_files(OUTPUT):
        relative = path.relative_to(OUTPUT)
        if path == DESTINATION:
            continue  # The manifest cannot contain its own hash.
        reasons = []
        if path.is_relative_to(EXCLUDED_RUNTIME):
            reasons.append("unused trial runtime; deletion rejected and never retried")
        if "__pycache__" in relative.parts or path.suffix == ".pyc":
            reasons.append("regenerable Python cache")
        size = path.stat().st_size
        if reasons:
            excluded.append({"path": relative.as_posix(), "bytes": size, "reason": "; ".join(reasons)})
            continue
        files.append({"path": relative.as_posix(), "bytes": size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    files.sort(key=lambda row: row["path"])
    excluded.sort(key=lambda row: row["path"])
    record = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "output_root": str(OUTPUT),
        "scope": "Exact local copy allowlist; append this manifest itself when copying. No publication or release approval.",
        "file_count": len(files),
        "total_bytes": sum(row["bytes"] for row in files),
        "files": files,
        "excluded_count": len(excluded),
        "excluded_bytes": sum(row["bytes"] for row in excluded),
        "exclusions": excluded,
    }
    DESTINATION.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in record.items() if key not in ("files", "exclusions")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
