# Historical initial evidence writer: do not rerun; it would overwrite repaired final manifests and stage history.
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
O=Path(__file__).resolve().parent.parent
P=Path(r'C:\wt\reorganize\comparison\sample-x\4veco-platform')
L=P.parent/'4veco-lessen'
now=datetime.now(timezone.utc).isoformat()
ledger={
'AGENTS.md':'Original routing/foundation/lane/governance/readiness/design/automatic skills and Review and Tool Routing; initial long read was truncated; scoped sections were re-read.',
'BUILD-PARAGRAPH.md':'Introduction, foundation and common preconditions, all Part A stages A1 through A-verify; Part B only to establish boundary.',
'BUILD-CHAPTER.md':'First130 lines: architecture, book foundation, chapter prerequisites/assembly boundary.',
'build-scripts/README.md':'First150 lines, shared renderer and lane classification.',
'docs/workflows/paragraph-lane-vocabulary.md':'Entire file.',
'docs/workflows/textbook-paragraph-lane.md':'Entire file.',
'skills/econ-textbook-paragraph.md':'Entire content in initial read.',
'skills/econ-exercise-builder.md':'Entire content; exact route and seven-stage contract revisited.',
'skills/econ-pdf-builder.md':'Entire file; instantiated unchanged build contract.',
'skills/economic-graph.md':'Entire file; unchanged standard and mandatory geometry verification.',
'skills/econ-didactiek.md':'Pedagogical method, sequencing, worked examples, precision; initial long output partly truncated.',
'skills/econ-paragraph-review.md':'Protocol/Pass0/Pass1 and review rules; independent reviewer reads full required reference chain.',
'skills/econ-quality-control.md':'Part0 freshness, framework overview and quality-ref contract sections; no dependent compliant ref generated.',
'skills/econ-word-templates.md':'First135 lines establish Office-only scope; not applied to Part A PDF output.',
'references/authored/book-outlines/book-2-outline.md':'Book foundation and chapter2.1/target roles plus hold explanations; initial full read partly truncated.',
'references/authored/book-outlines/book-2-outline.meta.json':'Full machine parse for plan hold table; matching action/subject explicitly evaluated by original checker.',
'references/owned/course-blueprint-pedagogical-boundaries.md':'Entire file.',
'references/owned/course-blueprint-v6.md':'Opening authority boundaries; line location supplied by initial rg.',
'references/owned/course-blueprint-v5.md':'Overview/table and exact chapter2.1 lesson-goal/target anchors.',
'references/authored/didactiek-principes.md':'Lines1–305 covering cognitive load, dual coding, fading and implementation.',
'references/authored/economic_mathematical_precision_reference.md':'Initial long read; targeted sections7–8 re-read at lines223–405.',
'references/authored/economie-terminologie.md':'Opening70 lines and targeted TO/GO/TK/profit/break-even entries via rg.',
'references/external/amstelveencollege_quality_standards.md':'Entire file.',
'references/authored/textbook-rendered-page-acceptance-standard.md':'Entire file and evidence convention/boundaries re-read.',
'references/authored/textbook-figure-standard.md':'First185 lines, small-source-font guard and rendered evidence.',
'build-scripts/templates/template-textbook-paragraph-plan.md':'Entire file; dedicated plan created before drafting.',
'build-scripts/templates/textbook-to-companion-handoff.md':'Entire file; handoff headings preserved.',
'build-scripts/lib/verify_svg_geometry.py':'First175 lines and verification helper API; unmodified selftest run.',
'scripts/validate-paragraph.js':'CLI/modes and targeted assets, review-verdict, quality-ref and Part A gating code.',
'build-scripts/workflows/check-paragraph-lane-scope.js':'Opening classification and CLI usage.',
'agents/teacher-learning-quality-review-agent.md':'Required inputs, scope and review sections.',
'agents/student-experience-review-agent.md':'Scope, student assumptions and review sections.'}
rows=[]
for rel,sections in ledger.items():
 path=P/rel
 if not path.exists():
  candidates=list(P.rglob(Path(rel).name))
  candidates=[p for p in candidates if '.git' not in p.parts]
  if len(candidates)==1:path=candidates[0]
 rows.append({'path':str(path),'read_scope':sections,'exists':path.exists(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None})
for path in [L/'AGENTS.md',L/'specifications/product-vision.md',L/'specifications/product-end-state.md',L/'specifications/companion-core-specifications.md']:
 rows.append({'path':str(path),'read_scope':'Read source instruction/scope; longer product documents used scoped sections to confirm Part A boundaries.','exists':path.exists()})
for name in ['chapter_2.1_plan.md']:
 for path in L.rglob(name):rows.append({'path':str(path),'read_scope':'Entire file; exact canonical LF hash verified in foundation evidence.','exists':True})
for path in L.rglob('* – paragraaf.md'):
 if path.name.startswith(('2.1.1 ','2.1.2 ')):rows.append({'path':str(path),'read_scope':'Entire source paragraph for pinned prior knowledge/context; not treated as compliant template.','exists':True})
rows.append({'path':r'C:\Users\meije\.codex\plugins\cache\openai-primary-runtime\pdf\26.905.11957\skills\pdf\SKILL.md','read_scope':'Entire file; announced and used PDF render/inspect protocol; artifact operation marker emitted once.','exists':True})
(O/'evidence/author-read-ledger.json').write_text(json.dumps({'recorded_utc':now,'basis':'Actually read scopes, including explicit truncation limitations; no claim that unseen parts were read.','files':rows},indent=2),encoding='utf-8')
# Broad stage intervals avoid invented finer timing that was not observable.
p=O/'evidence/stages.json';s=json.loads(p.read_text(encoding='utf-8'))
s['stages'][1]['stage']='plan_author_graphs_render_and_author_visual_QA'
s['stages'][1]['end_utc']=now
s['stages'].append({'stage':'independent_review_repairs_and_final_evidence','start_utc':now,'end_utc':None,'note':'A6 review overlapped last author QA; reviewer records its own actual interval. Granular unrecorded author stage boundaries unavailable.'})
s['build_runs_observed']=[{'start_utc':'2026-09-08T07:44:38.548335+00:00','end_utc':'2026-09-08T07:44:41.146023+00:00','pages':[10,6,5]}, {'start_utc':'2026-09-08T07:50:08.721499+00:00','end_utc':'2026-09-08T07:50:10.255703+00:00','pages':[10,6,6]}, {'start_utc':'2026-09-08T07:56:16.300539+00:00','end_utc':'2026-09-08T07:56:17.572908+00:00','pages':[10,6,6]}, {'start_utc':'2026-09-08T07:57:35.655393+00:00','end_utc':'2026-09-08T07:57:36.887774+00:00','pages':[10,6,6]}]
s['runtime_deviations']=['Initial bare python import weasyprint failed ModuleNotFoundError. An isolated WeasyPrint68.1 installation was made under evidence/python-runtime before exact shared Python was retested successfully. Isolated installation is unused by all PDF builds; retained as evidence.', 'Shared executable C:/Python314/python.exe Python3.14.3 and user-site WeasyPrint68.1 used for rendering, with original Pango path. No model/settings/tokens measurement exposed.']
s['initial_failures'] += ['SVG helper checkmark output caused cp1252 UnicodeEncodeError; rerun with PYTHONUTF8=1 completed geometry before final raster.', 'sharp/package.json not exported; used sharp.versions.sharp to observe0.35.2.', 'Automatic approval review rejected a PowerShell exact-path checked deletion of unused evidence/python-runtime: blocked by policy. No deletion retry or workaround; temporary runtime remains.']
p.write_text(json.dumps(s,indent=2),encoding='utf-8')
print(now)
print('Ledger rows',len(rows),'missing paths',[r['path'] for r in rows if not r['exists']])
