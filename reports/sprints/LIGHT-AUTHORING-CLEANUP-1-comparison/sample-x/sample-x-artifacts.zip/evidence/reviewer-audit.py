"""Independent review evidence only. Reads source/output; writes reviewer evidence."""
from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
import json, re, hashlib, base64, subprocess, xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pypdf import PdfReader

class ReadHTML(HTMLParser):
    def __init__(self):
        super().__init__();self.blocks=[];self.images=[];self.h2=[];self.capture=[]
    def handle_starttag(self,tag,attrs):
        if tag=='img':self.images.append(dict(attrs))
        if tag in ['p','h1','h2','h3','li','td','th']: self.capture.append([tag,[]])
    def handle_data(self,data):
        for obj in self.capture: obj[1].append(data)
    def handle_endtag(self,tag):
        if self.capture and self.capture[-1][0]==tag:
            _,parts=self.capture.pop();text=''.join(parts)
            if tag=='h2':self.h2.append(text)
            if not self.capture:self.blocks.append(text)

OUT=Path(__file__).resolve().parent.parent
PLATFORM=OUT.parents[1]/'4veco-platform'
LESSONS=OUT.parents[1]/'4veco-lessen'
def sha(data): return hashlib.sha256(data).hexdigest()
def canon(obj): return json.dumps(obj,ensure_ascii=False,separators=(',',':'))
def normalize(s): return re.sub(r'\s+','',s).replace('−','-')
report={'utc':datetime.now(timezone.utc).isoformat(),'artifacts':[],'graphs':[]}
expected_headings=['Uitgewerkt voorbeeld','Startopgaven','Begeleide inoefening','Zelfstandige oefening','Doeloefening','Denkertje / Bonusopgave','Herhaling / Herhaling en interleaving']
for kind in ['paragraaf','opgaven','antwoorden']:
    md=next(OUT.glob(f'* – {kind}.md'))
    txt=md.read_text(encoding='utf-8-sig')
    ht=md.with_suffix('.html')
    soup=ReadHTML();soup.feed(ht.read_text(encoding='utf-8-sig'))
    source_html=subprocess.run(['pandoc','--from=markdown','--to=html5'],input=txt.encode(),capture_output=True,check=True).stdout.decode()
    source_parser=ReadHTML();source_parser.feed(source_html)
    refs=re.findall(r'!\[([^\]]*)\]\(([^)]+)\)',txt)
    images=soup.images
    image_matches=[sha(base64.b64decode(im['src'].split(',',1)[1]))==sha((OUT/ref).read_bytes()) and im.get('alt')==alt for im,(alt,ref) in zip(images,refs)]
    reader=PdfReader(md.with_suffix('.pdf'))
    pdf_pages=[page.extract_text() for page in reader.pages]
    (OUT/'evidence'/f'reviewer-{kind}-pdf-text.txt').write_text('\n\n'.join(f'PAGE {i+1}\n{x}' for i,x in enumerate(pdf_pages)),encoding='utf-8')
    block_checks=[]
    joined=normalize(''.join(pdf_pages))
    for block in soup.blocks:
        text=normalize(block)
        if text: block_checks.append({'text':block[:110],'present_in_pdf':text in joined})
    item={'kind':kind,'md_sha256':sha(md.read_bytes()),'html_sha256':sha(ht.read_bytes()),'pdf_sha256':sha(md.with_suffix('.pdf').read_bytes()),'pages':len(reader.pages),'markdown_image_count':len(refs),'html_image_count':len(images),'image_payload_and_alt_matches':image_matches,'h2':re.findall(r'^## (.+)$',txt,re.M),'html_h2':soup.h2,'html_pdf_text_blocks':block_checks}
    if kind!='antwoorden': item['seven_headings_correct']=item['h2']==expected_headings
    item['md_html_text_blocks_equal']=[normalize(x) for x in source_parser.blocks]==[normalize(x) for x in soup.blocks]
    item['md_html_text_differences']=[{'md':a,'html':b} for a,b in zip(source_parser.blocks,soup.blocks) if normalize(a)!=normalize(b)]
    report['artifacts'].append(item)

# Independent numeric expectations from the questions, not author's geometry verdicts.
models={'fig_1':(180,F('1.2'),3,180,600,150,1),'fig_2':(180,F('1.2'),3,180,600,150,2),'fig_3':(180,F('1.2'),3,180,600,150,3),'we_1':(180,F('1.2'),3,180,600,150,3),'ex_1':(60,1,F('2.5'),100,300,80,3),'ex_2':(75,1,4,60,300,50,0),'ex_3':(75,1,4,60,300,50,3),'ex_4':(250,2,7,100,800,80,3),'ex_5':(500,F('0.8'),F('1.5'),1100,1900,1000,3)}
for name,(fixed,v,p,qmax,ymax,qp,stage) in models.items():
    root=ET.fromstring((OUT/'_assets'/f'2.1.2_{name}.svg').read_text())
    checks=[]
    def econ(x,y): return ((float(x)-80)*qmax/600,(310-float(y))*ymax/265)
    for e in root.iter():
        if 'data-curve' in e.attrib:
            c=e.attrib['data-curve']
            for suf in ['1','2']:
                q,y=econ(e.attrib['x'+suf],e.attrib['y'+suf]); predicted=float(p)*q if c=='TO' else fixed+float(v)*q
                checks.append({'element':c+suf,'q':q,'amount':y,'expected':predicted,'pass':abs(y-predicted)<1e-6})
        if 'data-on' in e.attrib:
            q,y=econ(e.attrib['cx'],e.attrib['cy'])
            for c in e.attrib['data-on'].split():
                predicted=float(p)*q if c=='TO' else fixed+float(v)*q
                checks.append({'element':'point-'+c,'q':q,'amount':y,'expected':predicted,'pass':abs(y-predicted)<1e-6})
        if 'data-profit' in e.attrib:
            q1,y1=econ(e.attrib['x1'],e.attrib['y1']);q2,y2=econ(e.attrib['x2'],e.attrib['y2']);profit=float((p-v)*qp-fixed)
            checks.append({'element':'profit','q':q1,'difference':y1-y2,'expected':profit,'pass':abs(q1-qp)<1e-6 and abs(q2-qp)<1e-6 and abs((y1-y2)-profit)<1e-6})
    be=F(fixed)/(p-v)
    report['graphs'].append({'file':name,'break_even_exact':str(be),'break_even_amount_exact':str(p*be),'checks':checks,'pass':all(x['pass'] for x in checks)})

report['independent_calculations']={
    'smoothie_table':[[q,str(3*q),str(F(180)+F('1.2')*q),str(3*q-F(180)-F('1.2')*q)] for q in [0,60,80,99,100,101,150]],
    'exercise1':{'TK40':200,'TK80':280,'GTK40':5},
    'exercise2c':{'continuous':'32.4','first_whole_no_loss':33},
    'exercise3':{'TO80':200,'TK80':140,'profit80':60,'BE':40,'BE_amount':100},
    'exercise4':{'profit20':-15,'profit50':75,'BE':25,'BE_amount':100},
    'exercise5':{'profit50':29,'BE':'35.5','first_whole_no_loss':36,'profit35':-1,'profit36':1},
    'exercise6':{'profit40':-50,'profit80':150,'BE':50,'BE_amount':350},
    'exercise7':{'TO':'1.5Q','GO':'1.5 euro/brood','profit500':-150,'profit1000':200,'BE_exact':'5000/7','BE_amount_exact':'7500/7','first_whole_no_loss':715,'profit714':'-0.20','profit715':'0.50'},
    'exercise8':{'Q':50,'TO':230,'GO':'4.60'},
    'exercise9':{'TK50':350,'TK100':500,'GTK50':7,'GTK100':5,'GCK50':4,'GCK100':2}}

registry=json.loads((PLATFORM/'references/authored/course-target-exercises.json').read_text(encoding='utf-8-sig'))
def seek(obj):
    if isinstance(obj,dict):
        if obj.get('id')=='2.1.2' and 'target_exercise' in obj:return obj
        for val in obj.values():
            x=seek(val)
            if x is not None:return x
    if isinstance(obj,list):
        for val in obj:
            x=seek(val)
            if x is not None:return x
target=json.loads((OUT/'evidence/target-record.json').read_text(encoding='utf-8-sig'))
report['target']={'registry_equal':seek(registry)==target,'record_sha256':sha(canon(target).encode()),'matches_approved_hash':sha(canon(target).encode())=='19b466dd6f7b541a3bb701d4de80ce13fe9ea58356313e24b23b21698093e1f9'}
report['target']['verbatim']={}
for kind in ['paragraaf','opgaven']:
    text=next(OUT.glob(f'* – {kind}.md')).read_text(encoding='utf-8-sig')
    report['target']['verbatim'][kind]=target['target_exercise']['context'] in text and all(s['prompt'] in text for s in target['target_exercise']['subquestions'])
ptext=next(OUT.glob('* – paragraaf.md')).read_text(encoding='utf-8-sig')
otext=next(OUT.glob('* – opgaven.md')).read_text(encoding='utf-8-sig')
report['exercise_extraction_exact']=ptext[ptext.index('## Uitgewerkt voorbeeld'):].strip()==otext[otext.index('## Uitgewerkt voorbeeld'):].strip()
out=OUT/'evidence/reviewer-independent-audit.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'target':report['target'],'graphs':[(g['file'],g['pass']) for g in report['graphs']],'artifacts':[{'kind':a['kind'],'pages':a['pages'],'images_ok':all(a['image_payload_and_alt_matches']),'missing_text_blocks':[b for b in a['html_pdf_text_blocks'] if not b['present_in_pdf']]} for a in report['artifacts']]},ensure_ascii=False,indent=2))
