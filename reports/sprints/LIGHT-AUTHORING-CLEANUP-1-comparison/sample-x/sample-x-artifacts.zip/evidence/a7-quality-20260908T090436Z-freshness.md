# A7 mandatory official-source quick check — 2026-09-08

Independent checker: `/root/comparison_sample_x/quality_record`. Internal local experiment evidence only. Official websites were searched and opened during the active interval beginning 09:04:36 UTC; the final three official pages below were directly reopened and the clock returned **2026-09-08 09:07:58 UTC**. All observations below are retrieval-date observations, not invented publication timestamps.

The original reference is `4veco-platform/references/external/inspectie-standaarden.md`, SHA-256 `623f05ed173cd55814f133f30181131b477cd94ea54125c8fb1c1f29bb2858ed`. Its `last_verified` is **2026-04-12** and its framework is **2021, bijgesteld 2025**. The elapsed calendar age is **149 days**, inside Part 0.3's 3–9 month quick-check window. This internal developer record uses the standard cascading rule under Part 0.4; it is not an external inspectie report.

Executed searches, restricted to `onderwijsinspectie.nl`:

- `onderzoekskader 2026 wijzigingen inspectie onderwijs`
- `inspectie onderwijs standaarden 2026`
- `inspectie onderwijs nieuws onderzoekskader 2026`
- `site:onderwijsinspectie.nl onderzoekskader "2026" "bijgestelde" "voortgezet"`

| Official page actually retrieved | Dates actually observed | What the quick check verified |
|---|---|---|
| [De onderzoekskaders](https://www.onderwijsinspectie.nl/onderwerpen/onderzoekskaders) | Retrieved 2026-09-08; no separate publication date shown in the returned page | Current index identifies the 2021 frameworks with the 2026 adjustment and links the VO framework. It describes annual adjustments and a planned major revision in 2027. |
| [Onderzoekskaders 2026 vastgesteld](https://www.onderwijsinspectie.nl/actueel/nieuws/2026/07/03/onderzoekskaders-2026-vastgesteld) | News date 03-07-2026 at 16:00, without a displayed timezone; effective 01-08-2026 | Adjusted frameworks, including VO, have been adopted. The announcement also identifies the new supervisory-visit forms and changes arising from legislation. |
| [Bijgestelde onderzoekskaders 2026](https://www.onderwijsinspectie.nl/onderwerpen/onderzoekskader-2021-wat-is-er-veranderd/bijstelling-2026) | Retrieved 2026-09-08; effective 01-08-2026; no separate publication date shown | OP0 and OP1 in VO were amended for the revised legal basis of attainment targets. The page also identifies VO amendments involving OP1, SKA3 and BKA2 for school-to-work legislation, plus VABA legal-reference changes. Some provisions concern specific educational populations; their applicability to this 4-vwo paragraph has not been comprehensively adjudicated. These are actual changes requiring reference work, not evidence for “no changes found.” |
| [VO onderzoekskader document landing page](https://www.onderwijsinspectie.nl/documenten/2021/07/01/onderzoekskader-2021-voortgezet-onderwijs) | Retrieved 2026-09-08; body states 2026 applies from 01-08-2026 and replaces 2025. Download card still displays publication 01-08-2025. | The body explicitly establishes the current-version replacement. The old card date is recorded as metadata inconsistency rather than treated as evidence that the 2025 framework remains current. Full 221-page PDF comparison was not performed in this bounded quick check. |
| [Ontwikkelingen in het toezicht](https://www.onderwijsinspectie.nl/actueel/nieuws/2026/03/09/ontwikkelingen-in-het-toezicht) | News date 09-03-2026 at 09:00, without a displayed timezone | Confirms development of the 2027 framework and planned changes to the role of results; does not make future OR1 changes the current 2026 rule. |
| [Bijgestelde onderzoekskaders 2025](https://www.onderwijsinspectie.nl/onderwerpen/onderzoekskader-2021-wat-is-er-veranderd/bijstelling-2025) | Retrieved 2026-09-08; effective date 01-08-2025 | Historical check confirms the reference's 2025 context, including OP0 assessment and the OP2 student-participation change. It does not establish currentness after the 2026 replacement. |

## Decision at the mandatory stage

**BLOCKED.** Original `skills/econ-quality-control.md` Part 0.5, quick-check step 5, requires: “If changes found: update the specific standard(s) in the reference file, update `last_verified` date”. Part 0.3 also requires the reference file to be updated when the quick check finds changes. Actual changes have been found.

The shared comparison instruction explicitly excludes authority/reference updates and requires source-only snapshots. The original root also treats external references as machine-refreshed source material. Therefore no reference text, reference date, skill date, or authority was changed. A Markdown blocker record does not satisfy the YAML closure requirement. No compliant quality_ref YAML, no passing stub, no current inspectie mapping and no standard-level compliance verdict were produced.

Required follow-up is separate authorised reference maintenance: compare current VO standards and the state of changes to the local reference, assess the applicability of each change, update the reference through its proper source-maintenance process and update the relevant verified dates. Only then rerun independent A7 against the final unchanged or freshly reviewed packet, write lane-owned schema-v2 evidence if all requirements are met, rerun the normal Part A validator, and proceed through applicable downstream gates. The 2027 overhaul remains a future verification concern.

This is a quick verification that establishes the blocker. It is not a comprehensive legal analysis or an external claim that the lesson, school or department meets inspectie standards.
