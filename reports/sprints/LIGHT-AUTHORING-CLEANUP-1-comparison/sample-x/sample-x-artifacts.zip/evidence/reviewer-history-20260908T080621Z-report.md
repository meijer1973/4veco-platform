# Paragraph Review: 2.1.2 Opbrengsten, winst en break-even

## 1. Scope and evidence

Independent A6 reviewer: `/root/comparison_sample_x/paragraph_review`. I did not author or edit student content. I requested corrections from the author and independently rechecked the resulting files. This review concerns the isolated Part A experiment only. It does not grant production, release, student-use, integration, or companion approval. The separately known quality-reference freshness blocker is outside this content verdict.

Review started: **2026-09-08 07:51:22 UTC**. Review completed: **2026-09-08 08:06:21 UTC**. Actual runtime model identifier, reasoning setting, service tier, and input/output/token usage: **unavailable**. No settings or token counts are inferred. No child agent was spawned.

Platform HEAD was independently confirmed as `96416b6b5bd57094576e9aba0a42d682584ec479`; source-lessons HEAD as `f09fd6e88edc5049b026b16b0158e7e188091d2d`. Both teaching repositories were read-only. No other comparison arm or parent candidate/cleanup content was read.

Reviewed: all three Markdown files, all three corresponding HTML files, all three PDFs, all nine SVG/PNG pairs, the textbook plan, target record and foundation evidence. PDF inspection used **every complete page**, not only contact sheets: paragraaf 1–10, opgaven 1–6, antwoorden 1–6. After the author's repair, the changed full pages were reinspected: paragraaf 7–8, opgaven 3–4, antwoorden 1–2; the other page PNG hashes remained unchanged. Total: 22 distinct final pages, with six additional changed-page inspections. There was no clipping, missing mathematical glyph, detached essential graph instruction, or unreadable table found. Sparse final homework pages are an efficiency consideration, not a content defect.

Initial snapshot: `evidence/reviewer-snapshot-start.json`. Final reviewed snapshot: `evidence/reviewer-snapshot-final.json`, SHA-256 **`073f5d8d95c18c07b294f3f8653846559966ee7c557a45345c48e233504e883b`**. It records individual hashes for all reviewed student artifacts, assets, page PNGs, target and plan. Final PDF hashes:

| Artifact | SHA-256 |
|---|---|
| paragraaf.pdf | `47d25cdd8ae65140e0b15315e8a5f96d2ba9b3305334b5633fe1f8fb6c071d8b` |
| opgaven.pdf | `6c6489261303621217702a528965e31ec133e193801a675c9280a4602322bae8` |
| antwoorden.pdf | `c53d37e809566dac7a7fbf9dbcf2688fb847c655022a744797f65d9747a55aa4` |

Final author build: 07:57:35.655393–07:57:36.887774 UTC; final Poppler render began 07:57:37.095773 UTC, 120 dpi. HTML was checked structurally and against source/text/image payloads; the actual complete printed rendering was inspected through these PDFs. No separate responsive-browser or interactive-surface approval is implied.

## 2. Verdict

**PASS**

Scoped A6 content review after author corrections. **0 open FAIL items; 3 nonblocking FLAG items**, recorded below. All three sequential passes were completed. The initial upward-rounding practice gap was corrected. Mathematical calculations, target fidelity, graph geometry and source/render parity pass. The guided route needs more classroom time than the compulsory core; that limitation is now stated honestly in the plan.

## 3. Pass 0: Asset and file integrity

Pass 0 was completed before substantive review; no blocking asset failure was found. Evidence: `evidence/reviewer-pass0.json` and the final independent audit.

| Check | Result | Evidence |
|---|---|---|
| 0.1 Image references | PASS | All 12 Markdown image uses resolve in `_assets/`. |
| 0.2 SVG/PNG pairing | PASS | Nine complete pairs; no missing counterpart. |
| 0.3 Naming | PASS | All 18 files follow `2.1.2_{fig,ex,we}_{number}.{svg,png}`. |
| 0.4 Orphans | FLAG P0-1 | Every visual is used through its PNG; nine SVG source counterparts are not directly referenced by a Markdown image. No unused conceptual visual was found. |
| 0.5 Required outputs | PASS | Three source Markdown files, three HTML renders, three PDFs and build_pdf.py exist. All PDFs exceed 10 KB. |

**P0-1 — FLAG, check 0.4, `_assets/` and all source files:** the literal file-reference check reports nine SVGs that are used indirectly through their paired PNGs. Retain the necessary source SVGs and document this source/print pairing in an asset inventory; do not insert redundant images into student pages merely to silence the check. This does not impede reading or printing.

## 4. Pass 1: Didactic architecture

### Strengths

- The problem-first smoothie context gives revenue, costs and break-even a clear purpose; the learning aim and §2.1.1 connection are visible on paragraaf p.1.
- Figures 1–3 keep the same axes, scale, colours and economic context while adding costs and interpretation (pp.2–4). Tables, formulas and explanations agree, and the graph instructions are adjacent to their figures.
- The worked example follows the target's four operations with simpler numbers (pp.5–6). Its graph, five-point non-heading summary and Startopgaven form the required continuous route.
- The guided visual route follows recognition → completion → verbal reasoning without a supplied graph → independent construction (pp.7–9; opgaven pp.3–5). Support wording is neutral and optional; the goal remains unchanged.
- The check confronts zero-cost and area-as-profit misconceptions. The repaired Start 2c now makes every learner interpret upward rounding before the target. The bonus critiques the constant-price assumption; the closing task retrieves previously taught total/average costs.

### Check coverage

| Checks | Result and observations |
|---|---|
| 1.1.1–1.1.3 | PASS: concrete hook, explicit cost prerequisite, early scope. |
| 1.2.1–1.2.5 | PASS: manageable concept order; progressive figures; adjacent explanations; verbal/table/graph/algebra representations; the same equality is connected algebraically and graphically. |
| 1.3.1–1.3.4 | PASS: representations support the main relationships, colours and line styles persist, target graph production is properly faded, no ability labels. |
| 1.4.1–1.4.3 | PASS: omzet/winst warning explains the tempting error; loss calculations and the current-content check confront the distinctions. |
| 1.5.1–1.5.6 | PASS after correction: goal/operation coverage is explicit; seven exact level-2 headings and summary adjacency are correct in both source documents; prerequisites and current-content checks are distinct; target operation and answer forms are preserved. |
| 1.5.7 | PASS for the required core equation; residual classroom FLAG P1-1 below. |
| 1.5.8–1.5.10 | PASS: bonus is assumption critique, one short cumulative task uses taught content, normal explanation and support are available on paper with no device/internal-lane directions. |
| 1.6.1, 1.6.3–1.6.5 | PASS: compact five-point box in the correct place; accurate §2.1.3 forward reference; no added top-level stage or internal architecture language. |
| 1.6.2 | FLAG P1-2: summary abbreviates the break-even assumptions too heavily. |
| 1.7.1–1.7.6 | PASS with P1-1 scheduling caution: visible goals, low-stakes checks, neutral differentiated support, concept-serving contexts, end-of-target self-monitoring and a recognisable bonus. |
| 1.8 | Not applicable: this is a theory paragraph, not Chapter 5 test preparation. |

### Issues and correction history

**Resolved P1-R1 — initially FLAG, checks 1.5.1/1.5.6:** all pre-target calculated break-even amounts were integers, while target 7c requires a noninteger and upward rounding. The author added compulsory Start 2c (32.4 → 33, with increasing profit stated) and changed guided 5 to `TK = 71 + 2Q`, giving 35.5 → 36 with boundary checks. The new question/answer and their six affected rendered pages were independently checked. The compulsory short route now rehearses the rounding distinction; the optional route also applies it inside a complete algebraic example. The target stayed verbatim.

**P1-1 — FLAG, checks 1.5.7/2.5.4, textbook plan timing and paragraaf pp.7–9/opgaven pp.3–5:** the revised core equation is `2 + 10 + 7 + 2 + 7 + 11 + 12 = 51` minutes, plus four minutes feedback = 55. This is a reasonable planning estimate for students whose substitution, algebra and plotting are sufficiently fluent, not measured classroom evidence. The full guided detour adds 13 minutes, reaching 64 before feedback. The plan now explicitly acknowledges that it must be scheduled over lessons or homework and preserves guided → independent → target. For a typical 4-vwo learner needing support, even the two minutes assigned to completing and marking graph 4d are tight. **Action:** carry the scheduling warning into teacher preparation and observe the first class run; preserve independent graph practice rather than silently skipping it to meet 55 minutes. The formal core-time contract passes; a universal one-lesson claim would not.

**P1-2 — FLAG, check 1.6.2, paragraaf p.6/opgaven p.2, summary third bullet:** “binnen de modelvoorwaarden” does not restate which conditions make this simple break-even model valid. The theory correctly states fixed price and constant variable cost per product, but the summary only explicitly retains the fixed-price condition in its TO/GO bullet. **Action:** make the third summary point name fixed price and constant variable cost per product, retaining the five-point limit. This is a retrieval-quality improvement, not a mathematical error in the teaching.

## 5. Pass 2: Mathematical and conceptual precision

Evidence: `evidence/reviewer-independent-audit.json` and `evidence/reviewer-audit.py`. The reviewer independently recomputed the numerical results and decoded actual SVG coordinates; the author's `geometry_passed` fields were not accepted as proof by themselves.

| Check group | Result |
|---|---|
| 2.1.1, 2.1.3–2.1.4, 2.1.6–2.1.7 | PASS: cost/revenue amounts belong on the vertical axis and output on the horizontal; units, relevant intercepts, plotted points, labels and vertical profit segments are correct for all nine SVGs. |
| 2.1.2, 2.1.5, 2.1.8 | No demand/supply steepness claim, supply curve or curve shift; those market-specific checks are not applicable. |
| 2.2.1, 2.2.3–2.2.4 | PASS: nonnegative Q, Q>0 for GO, model assumptions, period and numerical checks are present; comparisons retain the same Q. |
| 2.2.2/2.2.5 | No collective-demand piecewise function or switching of demand-function notation. Bonus price tiers are correctly evaluated directly; no unintroduced piecewise notation is demanded. |
| 2.3.1–2.3.4 | PASS for applicable terminology, definitions and relationships; no horizontal/vertical summation operation. |
| 2.4.1–2.4.4 | PASS: every worked calculation and exercise is solvable; hints use the intended method; the answer key and three solution figures match. |
| 2.5.1–2.5.3 | PASS: §2.1.1 actually teaches retrieved cost functions/averages; §1.1.3 teaches plotting and reading; the §2.1.3 forward reference is accurate; notation is compatible. |
| 2.5.4 | Content stays within the LIGHT target's scope; see P1-1 for learner-fluency and timing limits. |
| 2.6.1–2.6.3, 2.6.5–2.6.8, 2.6.10 | PASS: named firm/period, explicit ceteris paribus, total/per-product units, exact representation agreement, distinct cost terms, bounded model assumptions and whole-unit interpretation. |
| 2.6.4/2.6.9 | No movement/shift or market slope-language claim to assess. |

Independent numerical checks:

| Case | Verified result |
|---|---|
| Smoothie theory/example | TO=3Q; GO=€3 per smoothie; at Q=60,80,100,150 profit is −€72, −€36, €0, €90; BE=(100,300). |
| 1 | TK40=€200, TK80=€280; GTK40=€5 per poster. |
| 2 | GO=€4 for Q>0; break-even means equal totals, not zero costs; profit is a vertical difference; 32.4 requires 33 whole products when profit increases with Q. |
| 3 | At 80: TO=€200, TK=€140, profit=€60; BE=(40,100). |
| 4 | Profit20=−€15, profit50=€75; BE=(25,100); correct complete graph. |
| 5, repaired | At 50: TO=€200, TK=€171, profit=€29; BE=35.5, first whole=36; profit35=−€1, profit36=€1. |
| 6 | Profit40=−€50, profit80=€150; BE=(50,350), first whole=50. |
| 7 | TO=1.50Q; GO=€1.50 per loaf; profit500=−€150, profit1000=€200; exact BE=(5000/7,7500/7); first whole no-loss=715; profit714=−€0.20, profit715=€0.50. |
| 8 | At 50 books TO=€230 and GO=€4.60; differing per-unit prices invalidate one constant-price TO line. |
| 9 | TK50=€350, TK100=€500; GTK=€7 then €5; fixed-cost spreading correctly explains the decrease. |

All actual SVG curve endpoints, marked curve points and profit segments pass independent coordinate/formula checks. The target record equals the pinned registry record and its canonical SHA-256 is `19b466dd6f7b541a3bb701d4de80ce13fe9ea58356313e24b23b21698093e1f9`. Target context and a–d are verbatim in both student sources. Its status remains `candidate_review_ready`; the plan explicitly distinguishes that string from the owner-approved replacement and released action hold.

The opgaven body is an exact extraction of the paragraaf exercise body. Independently reconverted Markdown has the same normalised text blocks as the saved HTML. Every HTML image's decoded PNG bytes and alt text match its Markdown reference. All HTML content text blocks, including table cells, are present in the corresponding PDF extraction. This complements the full-page visual checks; it does not replace them.

**Pass 2 issues: none.**

## 6. Read ledger and limits

Paths below are within this sample's pinned platform (`P`) or lessons (`L`) worktree unless explicitly named output (`O`). For large references, the ledger identifies the sections actually inspected; it does not claim unrelated companion, governance, or curriculum chapters were substantively reviewed.

| Read source | Scope used |
|---|---|
| P/AGENTS.md; L/AGENTS.md | Canonical read-first, scope, quality discipline, design principles, independent-review routing and applicable read-only operating rules. |
| P/BUILD-PARAGRAPH.md | Common conditions, Book foundation and Part A through A-verify (lines 1–456). |
| P/docs/workflows/paragraph-lane-vocabulary.md; textbook-paragraph-lane.md | Full lane definitions, outputs, paper-route boundary and closure contract. |
| P/skills/econ-paragraph-review.md | All three passes, required references, calibration and prohibitions; test-preparation subsection treated as N/A. |
| P/skills/econ-exercise-builder.md | Time-budget and exact sequence/fading rules, especially §§2–3.2. |
| P/references/authored/didactiek-principes.md | Core philosophy, cognitive load, dual coding, target-aligned fading, differentiation, interleaving, misconceptions, Bloom and review/checklist appendices. |
| P/references/authored/economic_mathematical_precision_reference.md | Economic object, ceteris paribus, representations/units, cost/revenue/break-even, graphs, algebra, exercises and failure checks. |
| P/references/authored/economie-terminologie.md | Relevant D1 terms, abbreviation list, common pitfalls and canonical formulas. |
| P/references/external/amstelveencollege_quality_standards.md | Full school-fit overlay. |
| P/references/owned/course-blueprint-pedagogical-boundaries.md | Full prior-teaching/preview/target boundary. |
| P/references/authored/book-outlines/book-2-outline.md and its .meta.json content in O/evidence/foundation-pins.json | Authority pins, §2.1 role and foundation dimensions, prerequisites, model conditions, conventions and relevant lifecycle holds. V6/V5 pins inspected through these foundation records, not claimed as full rereads of both blueprints. |
| P/references/authored/course-target-exercises.json; O/evidence/target-record.json | Exact §2.1.2 record, target prompts, answer requirements and canonical hash equality. |
| L/specifications/product-vision.md; product-end-state.md; companion-core-specifications.md | Strategic promise and efficiency; target-first operational definition, core properties, scope and companion boundaries. |
| L/Boek 2…/2.1 Hoofdstuk Kosten en opbrengsten/_chapter-plan.md | Full chapter plan and its limitation as a historical draft; current record/hold evidence takes precedence over its old status prose. |
| L/…/2.1.1 Kostenstructuren/…– paragraaf.md | Theory/formulas, total/average distinction and spreading effect (opening through summary). |
| L/…/1.1.3 Grafieken en tabellen/…– paragraaf.md | Plotting/axis procedure, reading and interpolation theory. |
| L/…/2.1.3 Marginale kosten en marginale opbrengsten/…– paragraaf.md | Opening, goals, scope and marginal-total formulas for forward-compatibility. |
| O/2.1.2-textbook-plan.md; evidence/foundation-{structural,approved,authoring,production}.txt; foundation-pins.json | Plan and all four recorded currentness results, action scope, target binding and five prerequisite classifications. Recorded checker results were inspected, not claimed as reviewer reruns. |
| O/three source MD/HTML/PDF files; all _assets pairs; evidence/rendered-manifest.json and all listed pages | Full student content, initial and corrected; exact artifact coverage stated above. |
| O/build_pdf.py; evidence/{build-result.json,render_pages.py,graph-specs.json} | Reproducibility path, render provenance and comparison with actual assets. |
| P/build-scripts/workflows/check-book-outline-currentness.js | Focused read of hashing and currentness logic for target fingerprint interpretation. |
| C:/Users/meije/.codex/plugins/cache/openai-primary-runtime/pdf/26.905.11957/skills/pdf/SKILL.md | Full PDF read-only verification skill. |

The first audit attempt found the bundled Python lacked BeautifulSoup. I replaced that dependency in the reviewer-only evidence script with Python's standard HTML parser; no student artifact or repository dependency was changed. An initial raw text comparison was sensitive to HTML writer whitespace; the final comparison normalises whitespace and separately checks image bytes and target wording.

Next action: retain the corrected content snapshot and this scoped PASS, carry P1-1 into classroom planning, consider the compact summary improvement P1-2, and complete the separately required remaining quality/release gates before any production or student-use claim.

