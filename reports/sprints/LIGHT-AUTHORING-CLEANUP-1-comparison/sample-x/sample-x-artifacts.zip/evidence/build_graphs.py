"""HOW TO ADAPT: change graph specs; scaffold first, verify actual SVG before rasterization."""
from pathlib import Path
import sys, json, subprocess, xml.etree.ElementTree as ET
from dataclasses import dataclass
OUT=Path(__file__).resolve().parent.parent
P=OUT.parents[1]/'4veco-platform'
sys.path.insert(0,str(P/'build-scripts/lib'))
from verify_svg_geometry import Plot

@dataclass
class TotalLine:
    fixed: float
    slope: float
    maximum_q: float
    maximum_y: float
    def valid_endpoints(self,plot):
        endq=min(self.maximum_q,(self.maximum_y-self.fixed)/self.slope)
        return plot.to_xy(0,self.fixed),plot.to_xy(endq,self.fixed+self.slope*endq)

specs=[
dict(file='fig_1',title='Smoothiebar: totale opbrengst',fixed=180,v=1.2,p=3,qmax=180,ymax=600,unit='smoothies per marktdag',period='marktdag',stage=1,qprofit=150,qticks=[60,100,150],yticks=[180,300,450]),
dict(file='fig_2',title='Smoothiebar: opbrengst en kosten',fixed=180,v=1.2,p=3,qmax=180,ymax=600,unit='smoothies per marktdag',period='marktdag',stage=2,qprofit=150,qticks=[60,100,150],yticks=[180,300,450]),
dict(file='fig_3',title='Smoothiebar: break-even en winst',fixed=180,v=1.2,p=3,qmax=180,ymax=600,unit='smoothies per marktdag',period='marktdag',stage=3,qprofit=150,qticks=[60,100,150],yticks=[180,300,450]),
dict(file='we_1',title='Smoothiebar: uitgewerkt voorbeeld',fixed=180,v=1.2,p=3,qmax=180,ymax=600,unit='smoothies per marktdag',period='marktdag',stage=3,qprofit=150,qticks=[80,100,150],yticks=[180,300,450]),
dict(file='ex_1',title='Notitieboekjes: lees de twee bedragen',fixed=60,v=1,p=2.5,qmax=100,ymax=300,unit='boekjes per marktdag',period='marktdag',stage=3,qprofit=80,qticks=[40,80],yticks=[60,100,140,200]),
dict(file='ex_2',title='Badgekraam: voeg TO zelf toe',fixed=75,v=1,p=4,qmax=60,ymax=300,unit='badges per dag',period='dag',stage=0,qprofit=50,qticks=[20,40,50,60],yticks=[75,150,225]),
dict(file='ex_3',title='Badgekraam: volledige grafiek',fixed=75,v=1,p=4,qmax=60,ymax=300,unit='badges per dag',period='dag',stage=3,qprofit=50,qticks=[25,50],yticks=[75,100,200]),
dict(file='ex_4',title='Schooltheater: winst bij 80 kaartjes',fixed=250,v=2,p=7,qmax=100,ymax=800,unit='kaartjes per voorstelling',period='voorstelling',stage=3,qprofit=80,qticks=[50,80],yticks=[250,350,560]),
dict(file='ex_5',title='Bakkerij De Korenaar: winst bij 1.000',fixed=500,v=.8,p=1.5,qmax=1100,ymax=1900,unit='broden per maand',period='maand',stage=3,qprofit=1000,qticks=[500,714.2857142857,1000],yticks=[500,1071.4285714,1500]),
]
def num(x):
    if abs(x-round(x))<1e-7: return f'{int(round(x)):,}'.replace(',','.')
    return f'{x:,.2f}'.replace(',','X').replace('.',',').replace('X','.')
def text(x,y,value,size=18,anchor='middle',color='#2D3748',extra=''):
    return f'<text x="{x:.4f}" y="{y:.4f}" font-size="{size}" text-anchor="{anchor}" fill="{color}" {extra}>{value}</text>'
manifest=[]
for s in specs:
    plot=Plot(80,310,600/s['qmax'],265/s['ymax'])
    xy=plot.to_xy
    qbe=s['fixed']/(s['p']-s['v']); ybe=s['p']*qbe
    # 1. Scaffold reserves axis and title zones before curves/data.
    parts=['<svg xmlns="http://www.w3.org/2000/svg" width="720" height="360" viewBox="0 0 720 360" font-family="Arial">',
      '<rect width="720" height="360" rx="8" fill="#F7FAFC"/>',
      '<defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10z" fill="#2D3748"/></marker></defs>',
      '<line x1="80" y1="310" x2="80" y2="43" stroke="#2D3748" stroke-width="2" marker-end="url(#arrow)"/>',
      '<line x1="80" y1="310" x2="686" y2="310" stroke="#2D3748" stroke-width="2" marker-end="url(#arrow)"/>',
      text(15,180,f"{'TO' if s['stage']==1 else 'TK en TO'} (€ per {s['period']})",17,extra='transform="rotate(-90 15 180)"'),
      text(380,355,f"Q ({s['unit']})",18),text(360,25,s['title'],21,color='#1E2761'),text(72,329,'0',16,anchor='end')]
    # 2. Scale marks; no horizontal grid or unnecessary reference lines.
    for q in s['qticks']:
        x,_=xy(q,0)
        parts+=[f'<line x1="{x}" x2="{x}" y1="310" y2="315" stroke="#2D3748"/>',text(x,330,num(q),16)]
    for y in s['yticks']:
        _,py=xy(0,y)
        parts+=[f'<line x1="75" x2="80" y1="{py}" y2="{py}" stroke="#2D3748"/>',text(71,py+5,num(y),12 if len(num(y)) > 6 else 16,anchor='end')]
    # 3. Actual lines and direct endpoint labels.
    curves=[]
    if s['stage']!=0:curves.append(('TO',0,s['p'],'#7B2D8E',''))
    if s['stage']!=1:curves.append(('TK',s['fixed'],s['v'],'#E67E22','stroke-dasharray="10 4"'))
    for name,fixed,slope,color,style in curves:
        fn=TotalLine(fixed,slope,s['qmax'],s['ymax'])
        (x1,y1),(x2,y2)=fn.valid_endpoints(plot)
        parts+=[f'<line data-curve="{name}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="3" {style}/>',text(x2-7,y2-10,name,19,anchor='end',color=color,extra='font-weight="bold"')]
    # 4. Mathematically computed BE dot and reference lines.
    if s['stage']==3:
        x,y=xy(qbe,ybe)
        parts+=[f'<line data-reference="BE-x" x1="{x}" y1="{y}" x2="{x}" y2="310" stroke="#718096" stroke-dasharray="4 4"/>',f'<line data-reference="BE-y" x1="80" y1="{y}" x2="{x}" y2="{y}" stroke="#718096" stroke-dasharray="4 4"/>',f'<circle data-on="TO TK" cx="{x}" cy="{y}" r="4" fill="#2D3748"/>',text(x,y-18,'break-even',17)]
    # 5. Annotations: one vertical profit segment, no area; labels clear of lines.
    if s['stage']==3:
        q=s['qprofit'];to=s['p']*q;tk=s['fixed']+s['v']*q;x,ytop=xy(q,to);_,ybottom=xy(q,tk)
        parts += [f'<line data-profit="true" data-q="{q}" x1="{x}" y1="{ytop}" x2="{x}" y2="{ybottom}" stroke="#1E8449" stroke-width="4"/>',f'<circle data-on="TO" cx="{x}" cy="{ytop}" r="4" fill="#7B2D8E"/>',f'<circle data-on="TK" cx="{x}" cy="{ybottom}" r="4" fill="#E67E22"/>']
        # Profit label outside the plotted line region, connected with a short leader.
        mid=(ytop+ybottom)/2
        labelx=x-55;labely=ybottom+33
        parts += [f'<path d="M{x},{mid} L{x-20},{mid} L{labelx},{labely-12}" stroke="#1E8449" fill="none"/>',text(labelx,labely,f'€{num(to-tk)} winst',18,color='#1E8449',extra='font-weight="bold"')]
        parts += [text(210,65,'verlies: TO &lt; TK',17),text(470,65,'winst: TO &gt; TK',17)]
    parts+=['</svg>']
    path=OUT/'_assets'/f"2.1.2_{s['file']}.svg"
    path.write_text('\n'.join(parts),encoding='utf-8')
    # 6. Re-read actual SVG. Verify drawn endpoints/sample points using unmodified repository helper.
    root=ET.parse(path).getroot(); nodes=list(root)
    for name,fixed,slope,color,style in curves:
        line=next(n for n in nodes if n.attrib.get('data-curve')==name)
        points=[(float(n.attrib['cx']),float(n.attrib['cy'])) for n in nodes if name in n.attrib.get('data-on','').split()]
        endpoints=tuple((float(line.attrib[f'x{i}']),float(line.attrib[f'y{i}'])) for i in [1,2])
        plot.add_curve(name,TotalLine(fixed,slope,s['qmax'],s['ymax']),endpoints,points)
        for cx,cy in points:
            q=(cx-80)/plot.px_per_Q;amount=(310-cy)/plot.px_per_P
            assert abs(amount-(fixed+slope*q))<1e-8
    plot.verify()
    for n in nodes:
        if 'data-reference' in n.attrib:
            if n.attrib['data-reference']=='BE-x': assert abs(float(n.attrib['x1'])-xy(qbe,ybe)[0])<1e-8 and float(n.attrib['y2'])==310
            else: assert float(n.attrib['x1'])==80 and abs(float(n.attrib['y2'])-xy(qbe,ybe)[1])<1e-8
        if n.attrib.get('data-profit'):
            q=float(n.attrib['data-q']);assert float(n.attrib['x1'])==float(n.attrib['x2'])==xy(q,0)[0]
            assert abs((float(n.attrib['y2'])-float(n.attrib['y1']))/plot.px_per_P-(s['p']*q-s['fixed']-s['v']*q))<1e-8
    manifest.append({**s,'q_break_even':qbe,'y_break_even':ybe,'geometry_passed':True,'actual_svg_reparsed':True})
(OUT/'evidence/graph-specs.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
subprocess.run(['python',str(P/'build-scripts/lib/verify_svg_geometry.py')],check=True)
print('Geometry complete. Rasterize only after this successful result.')
