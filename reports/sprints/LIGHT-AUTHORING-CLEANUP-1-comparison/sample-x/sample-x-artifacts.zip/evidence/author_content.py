"""HOW TO ADAPT: edit the three source text blocks; derive the exercise copy from one block."""
from pathlib import Path
import json, re
OUT=Path(__file__).resolve().parent.parent
NAME='2.1.2 Opbrengsten, winst en break-even'
target=json.loads((OUT/'evidence/target-record.json').read_text(encoding='utf-8'))
theory='''# 2.1.2 Opbrengsten, winst en break-even

Een smoothiebar ontvangt op een schoolmarkt €240. Dat klinkt als een mooi bedrag. Maar de kraam, bekers en ingrediënten kosten ook geld. Hoeveel smoothies moet de bar verkopen om alle kosten terug te verdienen?

**Na deze paragraaf kun je** opbrengst en winst berekenen, break-even bepalen en beide in een grafiek laten zien. Je onderscheidt een berekende hoeveelheid van een geheel aantal producten.

In §2.1.1 leerde je `TK = TCK + TVK`: totale kosten bestaan uit constante en variabele kosten. Die kostenkennis gebruik je nu samen met de verkoopopbrengst.

### Van verkoop naar totale opbrengst

De smoothiebar vraagt €3,00 per smoothie. Bij 60 verkochte smoothies ontvangt de bar `3,00 × 60 = €180`.

> **Definitie: totale opbrengst (TO)**  
> Het totale bedrag dat een onderneming door verkoop ontvangt. Een ander woord is omzet.

> **Formule: totale opbrengst**  
> `TO = P × Q`  
> `P` is de vaste prijs in euro per product. `Q` is het aantal verkochte producten in de gekozen periode; `Q ≥ 0`.

In onze modellen wordt alles wat wordt gemaakt ook verkocht. Per situatie blijft de prijs per product gelijk. Ook de constante kosten, variabele kosten per product en productiecapaciteit blijven binnen het onderzochte bereik gelijk. Alle bedragen horen bij dezelfde periode.

De TO-lijn laat het verband tussen afzet en totale opbrengst zien, **terwijl alle andere omstandigheden gelijk blijven**. Voor de smoothiebar geldt op deze marktdag `TO = 3,00Q`.

| Q (smoothies per marktdag) | TO (€ per marktdag) |
|---:|---:|
| 0 | 0 |
| 60 | 180 |
| 100 | 300 |
| 150 | 450 |

Teken Q horizontaal en TO verticaal. Kies een gelijke schaal per as. Zet bijvoorbeeld de punten `(0; 0)` en `(150; 450)` en verbind ze. Zonder verkoop is TO nul; daarom begint de lijn in de oorsprong.

![Figuur 1. Eerst de opbrengstlijn: ieder verkocht product levert dezelfde prijs op.](_assets/2.1.2_fig_1.png)

### Van totaal naar gemiddeld

> **Definitie: gemiddelde opbrengst (GO)**  
> De opbrengst per verkocht product.

> **Formule: gemiddelde opbrengst**  
> `GO = TO / Q`, alleen voor `Q > 0`.  
> GO heeft de eenheid euro per product.

Bij 60 smoothies is `GO = 180 / 60 = €3,00` per smoothie. Omdat ieder product dezelfde prijs heeft, geldt `GO = (P × Q) / Q = P`. Bij nul verkochte smoothies kun je niet door Q delen: GO is dan niet gedefinieerd.

### Van opbrengst naar winst

> **Definitie: winst**  
> Het verschil tussen totale opbrengst en totale kosten. Een negatieve uitkomst betekent verlies.

> **Formule: winst**  
> `winst = TO − TK`  
> TO, TK en winst zijn bedragen voor dezelfde periode en dezelfde Q.

De smoothiebar betaalt €180 voor kraamhuur en apparatuur. Ingrediënten en bekers kosten €1,20 per smoothie. Dus `TK = 180 + 1,20Q`. Dit lineaire kostenmodel geldt hier voor 0 tot en met 180 smoothies op één marktdag, bij gelijkblijvende omstandigheden.

| Q (smoothies per marktdag) | TO (€) | TK (€) | Winst (€) |
|---:|---:|---:|---:|
| 0 | 0 | 180 | −180 |
| 60 | 180 | 252 | −72 |
| 100 | 300 | 300 | 0 |
| 150 | 450 | 360 | 90 |

De tweede grafiek voegt TK toe met dezelfde assen en schaal. Gebruik `(0; 180)` en `(150; 360)`. TK begint boven nul: de kraamhuur moet ook zonder verkoop worden betaald.

![Figuur 2. Voeg de kosten toe. Bij 60 smoothies liggen de kosten boven de opbrengst.](_assets/2.1.2_fig_2.png)

> **Let op: omzet is geen winst**  
> €180 omzet bij 60 smoothies lijkt een opbrengst om te houden. Maar de kosten zijn €252. De winst is `180 − 252 = −€72`: een verlies van €72.

### Break-even: precies alle kosten terugverdienen

> **Definitie: break-even-afzet**  
> De afzet waarbij TO en TK gelijk zijn. De winst is precies nul.

> **Voorwaarde voor break-even**  
> `TO = TK`  
> Gebruik hier het model met vaste prijs, constante variabele kosten per product en gelijkblijvende capaciteit.

Bij 100 smoothies zijn TO en TK allebei €300. Break-even betekent dus niet dat kosten of opbrengst nul zijn. De lijnen snijden elkaar bij `(100; 300)`.

Bij een onbekende break-even-afzet stel je de twee formules gelijk. Trek eerst de variabele-kostenterm aan beide kanten af. Deel daarna door het resterende bedrag per product. Controleer de uitkomst door dezelfde Q in TO én TK in te vullen.

Soms krijg je een niet-geheel aantal. Een continue uitkomst van bijvoorbeeld 32,4 producten is een punt op de modellijn. Bij alleen hele producten is 33 het eerste aantal zonder verlies, wanneer de winst met Q stijgt. Rond dan naar boven. Is break-even precies 100, dan is 100 zelf al zonder verlies; 101 is het eerste aantal met positieve winst.

### Winst aflezen: vergelijk op dezelfde Q

Lees bij één Q recht omhoog naar beide lijnen. Ligt TO hoger, dan is er winst. Ligt TK hoger, dan is er verlies. De **verticale afstand** is het verschil tussen twee eurobedragen. Kleur geen oppervlakte tussen de lijnen als winst.

In figuur 3 zie je de verlieszone links van 100 en de winstzone rechts ervan. Bij 150 smoothies is de verticale afstand `450 − 360 = €90`. De zones geven aan bij welke hoeveelheden verlies of winst ontstaat; het zijn geen geldbedragen om als oppervlakte te meten.

![Figuur 3. Het snijpunt geeft break-even; de verticale lijn bij 150 geeft €90 winst.](_assets/2.1.2_fig_3.png)
'''
exercise='''## Uitgewerkt voorbeeld

Een smoothiebar op een schoolmarkt betaalt €180 voor kraamhuur en apparatuur. Ingrediënten en bekers kosten €1,20 per smoothie. Elke smoothie wordt verkocht voor €3,00. Dus `TK = 180 + 1,20Q`. Q is het aantal smoothies op de marktdag. Het model geldt voor 0–180 smoothies; alle geproduceerde smoothies worden verkocht.

**Vraag:** stel TO op en verklaar GO. Bereken de winst bij 80 en 150 smoothies. Bepaal break-even en het eerste gehele aantal zonder verlies. Teken TK en TO, markeer de zones en geef de winst bij 150 als verticale afstand aan.

**Stap 1. Opbrengst en gemiddelde opbrengst**

`TO = P × Q = 3,00Q`, in euro per marktdag. Voor `Q > 0` is `GO = TO / Q = 3,00Q / Q = €3,00` per smoothie. Dat is de prijs: iedere smoothie wordt voor hetzelfde bedrag verkocht.

**Stap 2. Totale bedragen en winst**

| Q | TO (€ per marktdag) | TK (€ per marktdag) | Winst (€ per marktdag) |
|---:|---:|---:|---:|
| 80 | 3,00 × 80 = 240 | 180 + 1,20 × 80 = 276 | 240 − 276 = −36 |
| 150 | 3,00 × 150 = 450 | 180 + 1,20 × 150 = 360 | 450 − 360 = 90 |

Bij 80 smoothies is er €36 verlies. Bij 150 smoothies is er €90 winst. De opbrengst stijgt hier sneller dan de kosten, terwijl de vaste kraamkosten gelijk blijven.

**Stap 3. Break-even en gehele aantallen**

`TO = TK`  
`3,00Q = 180 + 1,20Q`  
`1,80Q = 180`  
`Q = 180 / 1,80 = 100` smoothies.

Controle: `TO = 3,00 × 100 = €300` en `TK = 180 + 1,20 × 100 = €300`. De continue break-even-afzet is 100 smoothies. Dat is al een geheel aantal: 100 is het eerste aantal zonder verlies. Bij 99 is de winst `297 − 298,80 = −€1,80`.

**Stap 4. Tekenen en interpreteren**

Zet Q (smoothies per marktdag) horizontaal; TK en TO (€ per marktdag) verticaal. Kies gelijke schaalstappen per as. Teken TO door `(0; 0)` en `(150; 450)`. Teken TK door `(0; 180)` en `(150; 360)`. Gebruik een liniaal.

Markeer `(100; 300)`. Links ervan is TO lager dan TK: verlies. Rechts ervan is TO hoger: winst. Teken bij Q = 150 één verticale lijn van €360 naar €450. Die lijn geeft `450 − 360 = €90` winst weer.

![Uitgewerkt voorbeeld. TK en TO, break-even bij 100 en €90 winst bij 150 smoothies.](_assets/2.1.2_we_1.png)

> **Samenvatting §2.1.2**
>
> - `TO = P × Q`; bij één vaste prijs en `Q > 0` geldt `GO = TO / Q = P`.
> - `winst = TO − TK`: positief is winst, negatief is verlies.
> - Break-even: los `TO = TK` op bij vaste prijs, constante variabele kosten per product en gelijkblijvende capaciteit; rond een niet-geheel minimum zonder verlies naar boven.
> - In de TK/TO-grafiek is het snijpunt break-even. Bij één Q is winst een verticale afstand, geen oppervlakte.
> - In §2.1.3 onderzoek je veranderingen in kosten en opbrengsten per extra product.

## Startopgaven

**Opgave 1 — Ophalen**

Een posterstudio heeft `TK = 120 + 2Q`. Q is het aantal posters per week; TK is in euro per week. De capaciteit blijft gelijk.

a) Bereken TK bij 40 posters en bij 80 posters.

b) Bereken GTK bij 40 posters. Noteer de eenheid. Leg kort uit waarom TK en GTK verschillende eenheden hebben.

**Opgave 2 — Begripscheck**

a) Een verkoper verkoopt elk product voor €4,00. Leg voor Q > 0 uit waarom GO €4,00 per product is.

b) Een klasgenoot zegt: “Bij break-even heeft het bedrijf geen kosten. Rechts van het snijpunt is de gekleurde oppervlakte de winst.” Verbeter beide fouten in je eigen woorden.

c) Een model geeft een continue break-even-afzet van 32,4 producten. De winst stijgt als Q toeneemt. Is 32 of 33 het eerste gehele aantal zonder verlies? Leg uit waarom.

**Controle:** Vergelijk je antwoorden bij opgaven 1 en 2 met het antwoordmodel. Verbeter zo nodig één stap en leg kort uit waarom.

**Korte route:** Startopgaven → Zelfstandige oefening → Doeloefening.  
**Extra hulp nodig?** Maak eerst Begeleide inoefening.

## Begeleide inoefening

*Heb je deze hulp niet nodig? Ga dan verder met Zelfstandige oefening.*

**Opgave 3 — Lees een uitgewerkte grafiek**

Een kraam verkoopt notitieboekjes voor €2,50 per stuk. `TK = 60 + Q`. Q is het aantal verkochte boekjes op één marktdag; TK en TO zijn in euro per marktdag. Bekijk de uitgewerkte grafiek.

![Opgave 3. De notitieboekjeskraam: beide lijnen, break-even en winst bij 80 boekjes.](_assets/2.1.2_ex_1.png)

a) Lees bij Q = 80 de twee bedragen af. Vul in: `winst = TO − TK = … − … = …` euro. Leg uit waarom je verticaal vergelijkt.

b) Lees het break-evenpunt af. Vul in: “Bij … boekjes geldt TO = TK = €… . Bij minder boekjes is er … .”

**Opgave 4 — Maak de grafiek af**

Een badgekraam heeft `TK = 75 + Q` en verkoopt iedere badge voor €4,00. Q is het aantal badges op één dag. Het model geldt voor 0–60 badges. Bedragen zijn in euro per dag.

a) Maak TO: `TO = … × Q`. Wat is GO voor Q > 0?

b) Bereken de winst bij 20 en 50 badges: bereken eerst TO en TK, trek daarna TK van TO af.

c) Maak de vergelijking af en los haar op: `4Q = 75 + Q`. Bepaal ook het eerste gehele aantal zonder verlies.

d) De assen en TK staan al hieronder. Bereken twee punten voor TO en teken de lijn erbij. Markeer zelf het snijpunt, de zones en de verticale winstafstand bij Q = 50.

![Opgave 4. De kostenlijn staat er al; voeg zelf de opbrengstlijn en de markeringen toe.](_assets/2.1.2_ex_2.png)

**Opgave 5 — Nu zonder getekende hulp**

Een sleutelhangerkraam heeft `TK = 71 + 2Q` en een vaste prijs van €4,00. Q is het aantal sleutelhangers per marktdag. De kostenstructuur blijft gelijk voor 0–60 stuks; alles wordt verkocht.

a) Stel TO op en verklaar GO voor Q > 0.

b) Bereken de winst bij Q = 50. Beschrijf in woorden tussen welke twee bedragen je de verticale winstafstand zou tekenen.

c) Bepaal algebraïsch break-even en het eerste gehele aantal zonder verlies. Geef aan aan welke kant van het snijpunt de verlieszone ligt.

## Zelfstandige oefening

**Opgave 6 — Schooltheater**

Een schooltheater verkoopt kaartjes voor een vaste prijs van €7,00. De kosten zijn `TK = 250 + 2Q`. Q is het aantal verkochte kaartjes voor één voorstelling. Het model geldt voor 0–100 kaartjes; bedragen zijn in euro per voorstelling.

a) Stel TO op. Verklaar voor Q > 0 waarom GO gelijk is aan de prijs.

b) Bereken de winst bij 40 en 80 verkochte kaartjes.

c) Bepaal algebraïsch de continue break-even-afzet en het eerste gehele aantal kaartjes zonder verlies.

d) Teken TK en TO nauwkeurig in één assenstelsel op ruitjespapier. Benoem assen en eenheden, markeer break-even en de winst- en verlieszone. Geef de winst bij Q = 80 als verticale afstand aan.

Vergelijk je uitwerking van opgave 6 met het antwoordmodel. Controleer ook assen, snijpunt en verticale winstlijn. Herstel zo nodig een reken- of tekenfout en maak die stap opnieuw voordat je de Doeloefening maakt.

## Doeloefening

**Opgave 7 — Bakkerij De Korenaar**

TARGET_CONTEXT

TARGET_QUESTIONS

Controleer na je poging je berekeningen en grafiek met het antwoordmodel. Noteer één stap die goed ging en één stap die je opnieuw wilt oefenen.

## Denkertje / Bonusopgave

**Opgave 8 — Eén lijn voor twee prijzen?**

Een boekenmarkt vraagt €5 voor elk van de eerste 40 verkochte boeken. Daarna kost elk extra boek €3. Een leerling zegt: “Er is steeds een vaste prijs op het prijskaartje, dus voor alle verkopen samen geldt GO = €5 en is TO één rechte lijn.”

Beoordeel de uitspraak met één zelfgekozen tegenvoorbeeld. Leg uit welke modelvoorwaarde uit deze paragraaf hier niet geldt. Je hoeft geen nieuwe grafiek te tekenen.

## Herhaling / Herhaling en interleaving

**Opgave 9 — Kosten per mok**

Een keramiekatelier heeft per week €200 constante kosten en €3 variabele kosten per mok. De capaciteit blijft gelijk bij 50–100 mokken.

a) Bereken TK en GTK bij 50 en bij 100 mokken. Noteer de eenheden.

b) Leg uit waarom TK stijgt terwijl GTK daalt. Gebruik de constante kosten in je uitleg.
'''
questions='\n\n'.join(f"{q['label']}) {q['prompt']}" for q in target['target_exercise']['subquestions'])
exercise=exercise.replace('TARGET_CONTEXT',target['target_exercise']['context']).replace('TARGET_QUESTIONS',questions)
answers='''# Antwoorden §2.1.2 — Opbrengsten, winst en break-even

**Afrondingsregel:** rond geldbedragen af op centen. Reken tussendoor met de onafgeronde uitkomst. Geef de continue break-even-afzet eerst exact of met een benaderingsteken. Rond daarna alleen voor het eerste gehele aantal zonder verlies naar boven, als de uitkomst niet geheel is.

De stappen volgen het uitgewerkte voorbeeld: 1. Opbrengst en gemiddelde opbrengst; 2. Totale bedragen en winst; 3. Break-even en gehele aantallen; 4. Tekenen en interpreteren. Gebruik bij een deelvraag de bijbehorende stap.

**Opgave 1 — Ophalen**

**a) Totale bedragen.** Bij Q = 40: `TK = 120 + 2 × 40 = €200` per week. Bij Q = 80: `TK = 120 + 2 × 80 = €280` per week. *Waarom:* bij meer posters stijgen de variabele kosten; de €120 constante kosten blijven gelijk.

**b) Gemiddelde kosten.** `GTK = TK / Q = 200 / 40 = €5,00` per poster. TK betreft alle posters samen in één week. GTK verdeelt dat bedrag over het aantal posters. *Waarom:* een totaalbedrag en een bedrag per product meten iets anders. Herhaal §2.1.1 als dit onderscheid nog lastig is.

**Opgave 2 — Begripscheck**

**a) Stap 1.** `TO = 4,00Q`; `GO = TO / Q = 4,00Q / Q = €4,00` per product voor Q > 0. *Waarom:* ieder product brengt hetzelfde bedrag op. Bij Q = 0 is delen door Q niet mogelijk.

**b) Stap 3 en 4.** Break-even betekent TO = TK; de winst is nul, maar de kosten hoeven niet nul te zijn. Winst bij één Q is de verticale afstand van TK naar TO, geen oppervlakte. *Waarom:* je trekt twee eurobedragen bij dezelfde hoeveelheid van elkaar af.

**c) Stap 3.** Het eerste gehele aantal zonder verlies is 33. Bij 32 ligt Q nog onder de grens van 32,4 en is er verlies. Bij 33 ligt Q boven de grens en is er winst, omdat de winst volgens dit model met Q stijgt. *Waarom:* een operationeel minimum zonder verlies rond je bij een niet-gehele uitkomst naar boven af.

**Opgave 3 — Lees een uitgewerkte grafiek**

**a) Stap 2 en 4.** Bij 80 boekjes: `TO = 2,50 × 80 = €200` en `TK = 60 + 80 = €140` per marktdag. `winst = TO − TK = 200 − 140 = €60` per marktdag. *Waarom:* verticaal blijft Q gelijk; alleen het bedrag verandert.

**b) Stap 3.** Bij 40 boekjes geldt `TO = 2,50 × 40 = €100` en `TK = 60 + 40 = €100`. Bij minder boekjes is er verlies. *Waarom:* links van het snijpunt ligt TK boven TO.

**Opgave 4 — Maak de grafiek af**

**a) Stap 1.** `TO = P × Q = 4,00Q`, in euro per dag. `GO = TO / Q = 4,00Q / Q = €4,00` per badge voor Q > 0. *Waarom:* alle badges hebben dezelfde prijs.

**b) Stap 2.** Bij 20 badges: `TO = 4 × 20 = €80`; `TK = 75 + 20 = €95`; `winst = 80 − 95 = −€15` per dag. Bij 50 badges: `TO = 4 × 50 = €200`; `TK = 75 + 50 = €125`; `winst = 200 − 125 = €75` per dag. *Waarom:* er zijn voldoende verkopen nodig om de constante kosten terug te verdienen.

**c) Stap 3.** `TO = TK → 4Q = 75 + Q → 3Q = 75 → Q = 75 / 3 = 25` badges. Controle: TO = 4 × 25 = €100 en TK = 75 + 25 = €100. Continue break-even is 25 badges; het eerste gehele aantal zonder verlies is ook 25. *Waarom:* een exacte gehele uitkomst hoeft niet verder omhoog.

**d) Stap 4.** TO loopt door `(0; 0)` en `(50; 200)`; TK door `(0; 75)` en `(50; 125)`. Break-even is `(25; 100)`. Links is de verlieszone, rechts de winstzone. Bij 50 badges loopt de winstlijn verticaal van €125 naar €200: €75 winst per dag. *Waarom:* het verschil op de verticale as vergelijkt dezelfde hoeveelheid badges.

![Antwoord 4d. De aangevulde badgegrafiek.](_assets/2.1.2_ex_3.png)

**Opgave 5 — Nu zonder getekende hulp**

**a) Stap 1.** `TO = 4,00Q` in euro per marktdag; `GO = TO / Q = 4,00Q / Q = €4,00` per sleutelhanger voor Q > 0. *Waarom:* alle verkochte producten hebben dezelfde prijs.

**b) Stap 2 en 4.** `TO = 4 × 50 = €200`; `TK = 71 + 2 × 50 = €171`. `winst = 200 − 171 = €29` per marktdag. De verticale lijn loopt bij Q = 50 van €171 naar €200. *Waarom:* TO ligt €29 boven TK bij diezelfde hoeveelheid.

**c) Stap 3.** `TO = TK → 4Q = 71 + 2Q → 2Q = 71 → Q = 71 / 2 = 35,5` sleutelhangers. Controle: TO = 4 × 35,5 = €142 en TK = 71 + 2 × 35,5 = €142. De continue break-even-afzet is 35,5; het eerste gehele aantal zonder verlies is 36. Bij 35 is TO = €140 en TK = €141: €1 verlies. Bij 36 is TO = €144 en TK = €143: €1 winst. De verlieszone ligt links van 35,5. *Waarom:* je kunt geen halve sleutelhanger verkopen; het eerste gehele aantal boven de continue grens dekt alle kosten.

**Opgave 6 — Schooltheater**

**a) Stap 1.** `TO = P × Q = 7,00Q` in euro per voorstelling. `GO = TO / Q = 7,00Q / Q = €7,00` per kaartje, voor Q > 0. *Waarom:* ieder kaartje brengt dezelfde vaste prijs op.

**b) Stap 2.** Bij 40 kaartjes: `TO = 7 × 40 = €280`; `TK = 250 + 2 × 40 = €330`; `winst = 280 − 330 = −€50` per voorstelling. Bij 80 kaartjes: `TO = 7 × 80 = €560`; `TK = 250 + 2 × 80 = €410`; `winst = 560 − 410 = €150` per voorstelling. *Waarom:* de opbrengst neemt in dit bereik sterker toe dan de kosten.

**c) Stap 3.** `TO = TK → 7Q = 250 + 2Q → 5Q = 250 → Q = 250 / 5 = 50` kaartjes. Controle: TO = 7 × 50 = €350 en TK = 250 + 2 × 50 = €350. Zowel de continue break-even-afzet als het eerste gehele aantal zonder verlies is 50. *Waarom:* 50 kaartjes dekken precies alle kosten; bij 49 is er nog €5 verlies.

**d) Stap 4.** Horizontaal: Q (kaartjes per voorstelling). Verticaal: TK en TO (€ per voorstelling). TO door `(0; 0)` en `(80; 560)`; TK door `(0; 250)` en `(80; 410)`. Break-even: `(50; 350)`. Links verlies, rechts winst. Bij Q = 80 is de verticale afstand `560 − 410 = €150`. *Waarom:* op één Q lees je de twee totalen af.

![Antwoord 6d. Schooltheater, met €150 winst bij 80 kaartjes.](_assets/2.1.2_ex_4.png)

**Opgave 7 — Bakkerij De Korenaar**

**a) Stap 1.** `TO = P × Q = 1,50Q`, in euro per maand. Voor Q > 0 geldt `GO = TO / Q = 1,50Q / Q = €1,50` per brood. *Waarom:* elk brood wordt voor dezelfde vaste prijs verkocht; de totale opbrengst gedeeld door het aantal broden geeft die prijs terug. (2 punten)

**b) Stap 2.** Bij Q = 500: `TO = 1,50 × 500 = €750`; `TK = 500 + 0,80 × 500 = €900`; `winst = 750 − 900 = −€150` per maand. Bij Q = 1.000: `TO = 1,50 × 1.000 = €1.500`; `TK = 500 + 0,80 × 1.000 = €1.300`; `winst = 1.500 − 1.300 = €200` per maand. *Waarom:* de €750 omzet bij 500 broden is onvoldoende voor €900 kosten; bij 1.000 broden is er wel een positief verschil. (2 punten)

**c) Stap 3.**

`TO = TK`  
`1,50Q = 500 + 0,80Q`  
`0,70Q = 500`  
`Q = 500 / 0,70 = 5.000/7 = 714,285714…` broden per maand.

De **continue break-even-afzet is ongeveer 714,29 broden per maand**. Op dit punt geldt exact TO = TK = 7.500/7 euro, ongeveer €1.071,43 per maand.

Het **eerste gehele aantal zonder verlies is 715 broden per maand**. Controle van de grens: bij 714 is `TO = 1,50 × 714 = €1.071,00` en `TK = 500 + 0,80 × 714 = €1.071,20`, dus €0,20 verlies. Bij 715 is `TO = €1.072,50` en `TK = €1.072,00`, dus €0,50 winst. *Waarom:* 714 ligt onder de continue grens; afronden op het dichtstbijzijnde gehele getal zou hier nog verlies geven. 715 is geen exact break-evenpunt. (3 punten)

**d) Stap 4.** Horizontale as: hoeveelheid Q (broden per maand). Verticale as: TK en TO (€ per maand). TO loopt door `(0; 0)` en `(1.000; 1.500)`. TK loopt door `(0; 500)` en `(1.000; 1.300)`.

Het snijpunt is exact `(5.000/7; 7.500/7)`, afgerond `(714,29; 1.071,43)`. Links ligt de verlieszone, rechts de winstzone. Bij Q = 1.000 loopt één verticale lijn van €1.300 naar €1.500: `1.500 − 1.300 = €200` winst per maand. De assen tonen ook de wiskundige verlenging naar nul; conclusies over de werkelijke bakkerij blijven bij dezelfde maand en ongewijzigde kostenstructuur/capaciteit. *Waarom:* de winst vergelijkt twee eurobedragen bij hetzelfde aantal broden; een oppervlakte is hier geen winst. (4 punten)

![Antwoord 7d. Bakkerij De Korenaar: break-even en €200 winst als verticale afstand bij 1.000 broden.](_assets/2.1.2_ex_5.png)

**Opgave 8 — Modelantwoord en beoordelingscriteria**

Een tegenvoorbeeld is Q = 50 boeken. De eerste 40 leveren `40 × €5 = €200` op. De volgende 10 leveren `10 × €3 = €30` op. TO is €230 en GO is `230 / 50 = €4,60` per boek. GO is dus niet €5. Vanaf het 41e boek stijgt TO per extra boek met €3 in plaats van €5; één rechte TO-lijn past niet bij beide delen. De modelvoorwaarde “alle producten tegen dezelfde vaste prijs” ontbreekt. Dit voorbeeld zegt nog niets over winst: daarvoor ontbreken de kosten.

Beoordelingscriteria:

- Een correct tegenvoorbeeld met meer dan 40 boeken, met opbrengst uit beide prijsdelen.
- GO juist berekend met de eenheid euro per boek.
- De ontbrekende vaste-prijsvoorwaarde genoemd en de claim over één rechte lijn onderbouwd.

**Opgave 9 — Kosten per mok**

**a) Totale en gemiddelde kosten.** `TK = 200 + 3Q`. Bij 50 mokken: `TK = 200 + 3 × 50 = €350` per week; `GTK = 350 / 50 = €7,00` per mok. Bij 100 mokken: `TK = 200 + 3 × 100 = €500` per week; `GTK = 500 / 100 = €5,00` per mok. *Waarom:* de totalen gelden voor de hele week, de gemiddelden voor één mok.

**b) Verklaring.** De totale variabele kosten nemen toe van €150 naar €300; daardoor stijgt TK. Dezelfde €200 constante kosten worden over meer mokken verdeeld: GCK daalt van `200 / 50 = €4,00` naar `200 / 100 = €2,00` per mok. De €3 variabele kosten per mok blijven gelijk, dus GTK daalt. *Waarom:* hogere totale kosten kunnen samengaan met lagere kosten per product. Herhaal §2.1.1 als dit nog lastig is.
'''
# Keep source question letters explicit and preserved in every render.
exercise=re.sub(r'(?m)^([a-d])\) ',r'**\1)** ',exercise)
# Keep the first table and its matching visual adjacent.
theory=theory.replace('| Q (smoothies per marktdag) | TO (€ per marktdag) |','::: {.visual-block}\n\n| Q (smoothies per marktdag) | TO (€ per marktdag) |',1)
theory=theory.replace('(_assets/2.1.2_fig_1.png)','(_assets/2.1.2_fig_1.png)\n\n:::',1)
# Keep graph instructions and figure as a readable unit.
exercise=exercise.replace('**Stap 4. Tekenen en interpreteren**','::: {.visual-block}\n\n**Stap 4. Tekenen en interpreteren**',1)
exercise=exercise.replace('(_assets/2.1.2_we_1.png)','(_assets/2.1.2_we_1.png)\n\n:::',1)
# The long target answer may span pages, but its graph interpretation must stay together.
answers=answers.replace('**d) Stap 4.** Horizontale as:','::: {.visual-block}\n\n**d) Stap 4.** Horizontale as:',1)
answers=answers.replace('(_assets/2.1.2_ex_5.png)','(_assets/2.1.2_ex_5.png)\n\n:::',1)
(OUT/f'{NAME} – paragraaf.md').write_text(theory+'\n'+exercise,encoding='utf-8')
(OUT/f'{NAME} – opgaven.md').write_text(f'# Opgaven §2.1.2 — Opbrengsten, winst en break-even\n\n'+exercise,encoding='utf-8')
(OUT/f'{NAME} – antwoorden.md').write_text(answers,encoding='utf-8')
print('Authored 3 Markdown sources; target context and subquestions inserted verbatim.')
