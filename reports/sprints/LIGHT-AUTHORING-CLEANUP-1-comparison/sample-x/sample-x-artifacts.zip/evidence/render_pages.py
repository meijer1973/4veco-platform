"""HOW TO ADAPT: render every final PDF page with Poppler and assemble QA contact sheets."""
from pathlib import Path
import subprocess,json
from PIL import Image,ImageOps,ImageDraw
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent.parent
manifest={'start_utc':datetime.now(timezone.utc).isoformat(),'dpi':120,'artifacts':[]}
for kind in ['paragraaf','opgaven','antwoorden']:
    pdf=next(OUT.glob(f'* – {kind}.pdf'));folder=OUT/'evidence/rendered'/kind;folder.mkdir(parents=True,exist_ok=True)
    subprocess.run(['pdftoppm','-r','120','-png',str(pdf),str(folder/'page')],check=True)
    pages=sorted(folder.glob('page-*.png'))
    sheet=Image.new('RGB',(900,((len(pages)+2)//3)*465),'#d6dce3')
    for i,page in enumerate(pages):
        im=Image.open(page);im.thumbnail((285,425));x=(i%3)*300+(300-im.width)//2;y=(i//3)*465+25
        sheet.paste(im,(x,y));ImageDraw.Draw(sheet).text((x,y-18),f'{kind} / {i+1}',fill='black')
    sheet.save(folder/'contact-sheet.png')
    manifest['artifacts'].append({'kind':kind,'pdf':str(pdf),'pages':[str(x) for x in pages],'contact_sheet':str(folder/'contact-sheet.png'),'page_count':len(pages)})
manifest['end_utc']=datetime.now(timezone.utc).isoformat()
(OUT/'evidence/rendered-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({x['kind']:x['page_count'] for x in manifest['artifacts']}))
