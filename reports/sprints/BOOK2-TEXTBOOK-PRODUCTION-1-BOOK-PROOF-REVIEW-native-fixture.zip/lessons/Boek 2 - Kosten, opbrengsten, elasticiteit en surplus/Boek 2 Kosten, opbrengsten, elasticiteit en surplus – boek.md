::: {.book-front}

# boek front

Reviewed fixture matter.

:::

<div class="page-break"></div>

<div id="book-boek-chapter-2-1"></div>

<h1 id="book-boek-2-1-hoofdstuk-2.1-hoofdstuk">Hoofdstuk 2.1 hoofdstuk</h1>
<div id="book-boek-paragraph-2-1-1"></div><h1 id="book-boek-2-1-test">2.1.1 Test</h1>
<p>UNIQUE-hoofdstuk-2.1.1.</p>
<div id="book-boek-paragraph-2-1-2"></div><h1 id="book-boek-2-1-test-1">2.1.2 Test</h1>
<p>UNIQUE-hoofdstuk-2.1.2.</p>
<div id="book-boek-paragraph-2-1-3"></div><h1 id="book-boek-2-1-test-2">2.1.3 Test</h1>
<p>UNIQUE-hoofdstuk-2.1.3.</p>
<div id="book-boek-paragraph-2-1-4"></div><h1 id="book-boek-2-1-test-3">2.1.4 Test</h1>
<p>UNIQUE-hoofdstuk-2.1.4.</p>
<figure>
<img alt="Technical fixture only" src="_assets/2.1.1_fig_1.svg"/>
<figcaption aria-hidden="true">Technical fixture only</figcaption>
</figure>


<div class="page-break"></div>

<div id="book-boek-chapter-2-2"></div>

<h1 id="book-boek-2-2-hoofdstuk-2.2-hoofdstuk">Hoofdstuk 2.2 hoofdstuk</h1>
<div id="book-boek-paragraph-2-2-1"></div><h1 id="book-boek-2-2-test">2.2.1 Test</h1>
<p>UNIQUE-hoofdstuk-2.2.1.</p>
<div id="book-boek-paragraph-2-2-2"></div><h1 id="book-boek-2-2-test-1">2.2.2 Test</h1>
<p>UNIQUE-hoofdstuk-2.2.2.</p>
<div id="book-boek-paragraph-2-2-3"></div><h1 id="book-boek-2-2-test-2">2.2.3 Test</h1>
<p>UNIQUE-hoofdstuk-2.2.3.</p>
<div id="book-boek-paragraph-2-2-4"></div><h1 id="book-boek-2-2-test-3">2.2.4 Test</h1>
<p>UNIQUE-hoofdstuk-2.2.4.</p>


<div class="page-break"></div>

<div id="book-boek-chapter-2-3"></div>

<h1 id="book-boek-2-3-hoofdstuk-2.3-hoofdstuk">Hoofdstuk 2.3 hoofdstuk</h1>
<div id="book-boek-paragraph-2-3-1"></div><h1 id="book-boek-2-3-test">2.3.1 Test</h1>
<p>UNIQUE-hoofdstuk-2.3.1.</p>
<div id="book-boek-paragraph-2-3-2"></div><h1 id="book-boek-2-3-test-1">2.3.2 Test</h1>
<p>UNIQUE-hoofdstuk-2.3.2.</p>
<div id="book-boek-paragraph-2-3-3"></div><h1 id="book-boek-2-3-test-2">2.3.3 Test</h1>
<p>UNIQUE-hoofdstuk-2.3.3.</p>
<div id="book-boek-paragraph-2-3-4"></div><h1 id="book-boek-2-3-test-3">2.3.4 Test</h1>
<p>UNIQUE-hoofdstuk-2.3.4.</p>


<div class="page-break"></div>

::: {.book-back}

# boek back

Reviewed fixture matter.

:::
