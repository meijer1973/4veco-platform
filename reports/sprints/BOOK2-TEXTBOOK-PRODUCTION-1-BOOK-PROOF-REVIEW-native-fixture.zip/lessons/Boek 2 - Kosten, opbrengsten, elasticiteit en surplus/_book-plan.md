Fixture plan, not approval.
