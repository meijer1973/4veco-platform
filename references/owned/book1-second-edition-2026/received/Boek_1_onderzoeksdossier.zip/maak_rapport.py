from pathlib import Path
import json, re, hashlib, html
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent
A=json.loads((ROOT/'audit.json').read_text())
OUT=ROOT/'Boek_1_onderzoek_en_invoerplan.pdf'
F=Path('/usr/share/fonts/truetype/dejavu')
for name,fn in [('Body','DejaVuSans.ttf'),('BodyB','DejaVuSans-Bold.ttf'),('BodyI','DejaVuSans.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(F/fn)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyB',italic='BodyI',boldItalic='BodyB')
NAVY=HexColor('#17394c'); BLUE=HexColor('#106d87'); GREY=HexColor('#536675'); PALE=HexColor('#edf4f6'); LINE=HexColor('#d7e2e6')
styles={
 'title':ParagraphStyle('title',fontName='BodyB',fontSize=25,leading=30,textColor=NAVY,spaceAfter=15),
 'h1':ParagraphStyle('h1',fontName='BodyB',fontSize=18,leading=23,textColor=NAVY,spaceAfter=13),
 'h2':ParagraphStyle('h2',fontName='BodyB',fontSize=11.3,leading=15,textColor=BLUE,spaceBefore=9,spaceAfter=4),
 'p':ParagraphStyle('p',fontName='Body',fontSize=10,leading=14.3,textColor=NAVY,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='Body',fontSize=8.4,leading=11,textColor=GREY,spaceAfter=4),
 'issue':ParagraphStyle('issue',fontName='Body',fontSize=9.3,leading=12.9,textColor=NAVY,spaceAfter=5),
 'cell':ParagraphStyle('cell',fontName='Body',fontSize=8.6,leading=12,textColor=NAVY),
 'th':ParagraphStyle('th',fontName='BodyB',fontSize=8.6,leading=12,textColor=white),
 'mono':ParagraphStyle('mono',fontName='Mono',fontSize=7.8,leading=11.2,textColor=NAVY,spaceAfter=5),
 'kicker':ParagraphStyle('kicker',fontName='BodyB',fontSize=9,leading=13,textColor=BLUE,spaceAfter=12),
}
story=[]
def p(s,style='p'): return Paragraph(s,styles[style])
def add(s,style='p'): story.append(p(s,style))
def h(s):add(s,'h2')
def esc(s):return html.escape(str(s))
def table(headers,rows,widths):
    data=[[p(esc(x),'th') for x in headers]]+[[p(str(x),'cell') for x in row] for row in rows]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,1),(-1,-1),.35,LINE),('ROWBACKGROUNDS',(0,1),(-1,-1),[white,PALE])]))
    story.append(t);story.append(Spacer(1,9))
def page(title):story.append(PageBreak());add(title,'h1')
def box(text):
    t=Table([[p(text)]],colWidths=[491]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),PALE),('BOX',(0,0),(-1,-1),.5,LINE),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.append(t);story.append(Spacer(1,9))

add('4 VWO ECONOMIE  /  ONDERZOEK  /  2 OKTOBER 2026','kicker')
add('Boek 1 vervangen door de tweede editie','title')
add('Inhoudelijke beoordeling en uitvoerplan voor 4veco-platform en 4veco-lessen','h2')
box('<b>Advies:</b> gebruik dit bronpakket als de nieuwe basis. Voer een gerichte revisie en een gecontroleerde editiemigratie uit. Er is geen aanwijzing dat het hele boek opnieuw geschreven moet worden. Alleen de PDF vervangen is onvoldoende.')
add('De nieuwe editie heeft een samenhangende opbouw van rekenvaardigheden naar vraag, aanbod en marktevenwicht. Zij bevat drie hoofdstukken, twaalf paragrafen en 114 opgaven. De belangrijkste eerder gemelde inhoudelijke problemen zijn al aangepakt. De resterende werkzaamheden betreffen vooral oefenroutes, enkele concrete tekst-/omslagpunten en de aansluiting tussen bronnen, registratie en publicatie.')
table(['Aangeleverd','Omvang','Beoordeling'],[
 ['Leerlingboek','132 pagina\u2019s','Volledige nieuwe editie; doelopgaven per paragraaf aanwezig.'],
 ['Antwoordenboek','66 pagina\u2019s','Uitwerkingen bij 114 opgaven; slotpagina bewust leeg.'],
 ['Docenteninformatie','26 pagina\u2019s','Doelen, afstemming en 21 kernlesplannen; tijd is geschat.'],
 ['Bewerkbaar bronpakket','3 pakketten','Manuscripten, figuren, scripts, opgavenregistraties en bewijslogs.']
],[115,90,286])
h('Voor omschakeling noodzakelijk')
add('1. Harmoniseer de negen theorieparagrafen met de normale en uitdagende oefenroute van boeken 2-4; herbegroot de lessen.<br/>2. Corrigeer de omslag en de verklapte hoeveelheid bij §1.3.1, opgave 8.<br/>3. Leg de tweede editie en haar gewijzigde doelen afzonderlijk vast.<br/>4. Maak de bouwroute veilig, archiveer de eerste editie en zet navigatie en controles samen om.')
h('Wat dit onderzoek wel vaststelt')
add('Alle twaalf leerlingmanuscripten zijn gelezen. De twaalf doeloefeningen zijn vergeleken met de antwoordmodellen en de live doelregistratie. Er zijn gerichte PDF-inspecties en heruitgevoerde pakketcontroles gedaan. De uitkomsten zijn bruikbaar voor een concrete implementatieopdracht. Dit is geen volledige CE-audit, klasproef of nieuwe formele goedkeuring van alle targets.','small')
add('De repository is tijdens dit onderzoek niet gewijzigd. Bronverwijzingen en peildatum staan op de laatste pagina. Het aparte controledossier bevat de kwaliteitlog, de paragraafvergelijking en de validatieresultaten.','small')

page('1. Wat moet inhoudelijk worden aangepast?')
h('Oefenroute: begeleiding hoort bij de normale route')
add('Alle negen theorieparagrafen bieden nu een korte route zonder begeleide inoefening en verwijzen alleen bij extra hulp naar die begeleiding. Dat wijkt af van de huidige route van boeken 2-4. De begeleiding zelf is al aanwezig: voornamelijk de instructietekst, docentplanning en borging moeten veranderen.')
box('<b>Normale route:</b> Startopgaven → Begeleide inoefening → Zelfstandige oefening → Doeloefening.<br/><b>Uitdagende route:</b> Startopgaven → Zelfstandige oefening → Doeloefening → Denkertje / Bonusopgave.<br/>Herhaling is extra bij beide routes. Startopgaven bepalen niet automatisch welke route een leerling krijgt.')
add('Vervang ook de introductie die leerlingen meteen uitnodigt begeleiding over te slaan. Bruikbare tekst: <i>“Begeleide inoefening hoort bij leren: je oefent met denkstappen en doet steeds meer zelf.”</i> Pas zowel de manuscripten als de auteursscripts en validators aan; de bestaande validators eisen juist nog de oude formulering. [Z1, R2]')
add('Vindplaatsen in het complete leerlingboek: p. 9, 19, 32, 52, 62, 72, 90, 102 en 112. De gemengde paragrafen hebben een andere functie; leg hun werkroute passend bij hun eigen opgaven vast, zonder kunstmatig alle theoriekoppen toe te voegen. Het platformcontract geldt formeel voor Boek 2+: de uitbreiding naar deze nieuwe editie moet expliciet in de werkwijze komen. [R2]','small')
h('Lesplanning: geen begeleiding boven op een volle les stapelen')
add('Elk hoofdstuk bevat zeven kernlessen van 55 minuten: samen 21. Hoofdstuk 1 noemt 6-8 lessen als eerste planningsmarge; hoofdstukken 2 en 3 noemen 7-9. De kernbegrotingen behandelen begeleiding nog als optionele extra tijd. Herbereken de normale route inclusief die begeleiding en de uitdagende route inclusief bonus. Maak extra lestijd zichtbaar waar nodig. Twaalf paragrafen betekenen hier niet twaalf lessen. [Z2]')
h('Omslag: bekende inhoudelijke fout niet alleen toelichten')
add('De indexgrafiek en tabel op p. 1 stemmen niet volledig overeen; de meegeleverde README erkent dit al. Ook “hogere prijs → minder vraag” vervaagt het onderscheid tussen vraag en gevraagde hoeveelheid. Maak grafiek en tabel consistent en gebruik bijvoorbeeld “hogere eigen prijs → kleinere gevraagde hoeveelheid”, met ceteris paribus. Een waarschuwing in de docentengids herstelt de leerlingomslag niet. [Z3]')
h('§1.3.1, opgave 8: één deelantwoord wordt weggegeven')
add('Op p. 93 vraagt de zelfstandige oefening het nieuwe aanbod te berekenen. Het kader eronder noemt al 64 kilo. Vervang <i>“De berekende 64 kilo is aangeboden kaas”</i> door <i>“De berekende hoeveelheid is aangeboden kaas.”</i> De uitleg over aanbod versus verkoop blijft bruikbaar; 64 kilo blijft in het antwoordmodel staan. [Z4]')

page('2. Vergelijking van de twaalf paragrafen')
add('De paragraafnummers blijven gelijk. Contexten, oefeningen en soms eindhandelingen veranderen wel. Een oud nummer of een oude status <i>reviewed_final</i> bewijst daarom geen goedkeuring van de nieuwe opgave. Onderstaande pagina\u2019s horen bij de aangeleverde 132-paginaversie. [Z1, R3]')
rows=[
 ['1.1.1 · 7 · p.11','Goede grondslag voor schaarste, alternatieve kosten en doelafhankelijke keuzes. Nieuw voorbeeld, geen reden voor volledige herschrijving.'],
 ['1.1.2 · 18 · p.22','Verhoudingen, procentpunten en indexpunten helder. Kernuitkomsten gecontroleerd, waaronder 120/150 en 25% groei.'],
 ['1.1.3 · 30 · p.36','Algebra en oppervlakte expliciet toegevoegd. Sterke voorbereiding op Boek 2; uitbreiding ook in doelen en registraties opnemen.'],
 ['1.1.4 · 36 · p.40-41','Eerder gemiste grafiekconstructie en interpolatie nu aanwezig. Keuze, netto-opbrengst, index en bronbeoordeling gecombineerd.'],
 ['1.2.1 · 8 · p.56','Koopkeuze plus lineaire vraagfunctie en assnijpunten. Oude zelfstandige trapgrafiek is geen nieuw einddoel: leg deze wijziging vast.'],
 ['1.2.2 · 19 · p.66','Eigen prijs en substituut gescheiden; effecten 60 → 50 → 70. Vooruitverwijzing is nu correct.'],
 ['1.2.3 · 30 · p.76','Collectieve vraag en nulbijdrage begrijpelijk begrensd. Bij P=8 telt 0+8=8. Noodzakelijke geldigheidsintervallen behouden.'],
 ['1.2.4 · 37 · p.80-81','Goede bronselectie en twee tegengestelde effecten. Nulbijdrage wordt al in 1.2.3 getoetst; nieuwe verdeling van doelbewijs vastleggen.'],
 ['1.3.1 · 9 · p.94','Aanbod versus verkoop helder; twee oorzaken afzonderlijk. Kleine correctie nodig bij zelfstandige opgave 8 op p.93.'],
 ['1.3.2 · 20 · p.106','Evenwicht, overschotten en werkelijke transacties correct gescheiden. Verkoopvoorwaarden staan expliciet in de bron.'],
 ['1.3.3 · 31 · p.116','Nieuwe target: één vraagverschuiving. Twee verschuivingen kwalitatief in opgave 27/bonus 32; oude target eist ook gezamenlijke algebra.'],
 ['1.3.4 · 37 · p.120-121','Nieuwe target: één aanbodschok en een aparte prijsvergelijking. Oude target vergelijkt een aanbod- en een vraagschok afzonderlijk.']
]
table(['§ · Doelopgave · Boekpagina','Beoordeling / gevolg'],rows,[121,370])
add('Aanbevolen keuze: neem de nieuwe opzet als editievoorstel over en beoordeel de veranderde eindhandelingen expliciet. Als de oude eisen van bijvoorbeeld §1.3.3 toch verplicht blijven, moeten doelopgave en zelfstandige voorbereiding eerst worden aangevuld. Alleen een nieuw bestand onder een oud target-ID hangen is onvoldoende.','small')

page('3. Gevolgen voor boeken 2, 3 en 4')
add('De nieuwe editie biedt een sterkere rekenkundige instap voor Boek 2. Er is op basis van deze vergelijking geen aanleiding om boeken 2-4 in hun geheel te herschrijven. Wel moeten verwijzingen, voorkennisclaims en afgeleide lesmiddelen op de gebruikte editie worden gecontroleerd. De huidige Boek 2-levering is de chatuitgave met Nederlandse notatie en woordformules; vergelijk daarmee, niet met een oudere gearchiveerde productie. [R6]')
table(['Voorkennis','Concreet bewijs in het nieuwe Boek 1','Vervolg'],[
 ['Procenten en indexen','1.1.2 doel 18; 1.1.4 doel 36e-f','Elasticiteit en economische vergelijkingen.'],
 ['Formules en vergelijkingen','1.1.3 doel 30d-e; 1.2.1 doel 8c-d; 1.3.2 doel 20a-b','Kosten, opbrengsten, break-even en marktmodellen.'],
 ['Grafieken en oppervlakte','1.1.3 doel 30a-b/f-g; 1.1.4 doel 36c-d','Surplusgebieden later inhoudelijk onderwijzen; geometrie is voorbereid.'],
 ['Vraag en oorzaken','1.2.1 doel 8; 1.2.2 doel 19; 1.2.3 doel 30','Elasticiteit en formeel consumentensurplus.'],
 ['Aanbod en evenwicht','1.3.1 doel 9; 1.3.2 doel 20; 1.3.3 doel 31','Welvaart, marktaanpassing en latere interventies.'],
 ['Bronnen en uitleg','Doelen 1.1.4, 1.2.4 en 1.3.4','Onderbouwde modelconclusies; geen oorzaken verzinnen.']
],[104,241,146])
add('Dit is bewijs van aangeboden en gevraagde handelingen, niet van beheersing door iedere leerling. Formele kostenstructuren, marginale analyse, inkomenselasticiteitsclassificatie en surplus-/welvaartsanalyse blijven vervolgonderwijs. Een kennismaking in Boek 1 rechtvaardigt niet dat instructie in Boek 2 wordt ingekort. [Z1, R7]','small')
h('Eerdere backlog: wat is al opgelost?')
table(['Issue #221','Bevinding bij deze editie'],[
 ['B1-E2-01 · gemengde target','Grafiekconstructie en interpolatie zichtbaar aanwezig in 1.1.4. Sluit na review met dit editiegebonden bewijs.'],
 ['B1-E2-02 · vooruitverwijzing','1.2.2 verwijst nu naar collectieve vraag. Inhoudelijk opgelost in de nieuwe tekst.'],
 ['B1-E2-03 · te veel formalisme','Nulbijdragen behouden; formele knik-/stukgewijze analyse niet als zelfstandige eis. Noodzakelijke modelgrenzen blijven terecht staan.'],
 ['B1-E2-04 · previews','Surplus is begrensde kennismaking; geen formele Ei-classificatie. Oude kritiek niet blind herhalen.'],
 ['B1-E2-05 · oude 1.4/1.5','Nog een repositorytaak. Aanwezigheid van de ZIP ruimt de oude actieve boom niet op.']
],[152,339])

page('4. Concrete migratie in de repositories')
h('Fase 1: ontvangst en editie-identiteit vastleggen')
add('Bewaar de ontvangen ZIP en haar SHA-256 als onveranderlijk herkomstbewijs. Maak voor de nieuwe editie een eigen revisie-ID, bijvoorbeeld <i>book1-second-edition-2026</i>. Pin beide repositorycommits en inventariseer de volledige oude Boek 1-boom. Gebruik de archief-/hashcontrole van de Boek 2-import als patroon. [R4, R5]')
h('Fase 2: inhoud en bouwroute repareren')
add('Voer de correcties uit pagina 2 door in de werkbronnen, auteursscripts en relevante QA-records. Harmoniseer de twaalf doelrecords en voorkennisverwijzingen. Bouw eerst de hoofdstukken, daarna de complete leerling-, antwoorden- en docentenboeken. Beoordeel het resultaat op de uiteindelijke bestanden. De oorspronkelijke ontvangst blijft apart bewaard.')
h('Fase 3: de standaardlevering in één samenhangende wijziging omzetten')
table(['Oppervlak','Voorgestelde verandering'],[
 ['4veco-lessen: nieuw boek','Binnen de bestaande Boek 1-map een eigen edities/tweede-editie-2026/ met boek/, hoofdstukken/ en bronnen/. Dit is een voorstel voor de mapnaam, geen reeds bestaande route.'],
 ['Bewerkbare bronnen','Bewaar de hoofdstukstructuur en relatieve assetpaden. De bestanden uit chapter-order.json zijn de leerlingbron; Antwoorden.md en Docenteninformatie.md de bijbehorende werkbronnen.'],
 ['4veco-platform','Beheer bouw-/importtooling, editie-selectie, doelregistratie, benodigde verwijzingsupdates en een Boek 1-controle met eigen manifest.'],
 ['Archief','Bewaar de eerste editie, de oude 1.4/1.5 en historische bewijsstukken traceerbaar. Controleer bestandset en inhoudhashes; oude reviews blijven historisch.'],
 ['Navigatie en downloads','Nieuwe Boek 1-README, boeklanding en hoofdindex verwijzen naar dezelfde editie. Pas manifest/gegenereerde navigatie via de eigenaarstooling aan.'],
 ['Beleid en bewijs','Maak “Book 1 is frozen” expliciet van toepassing op de eerste editie. Registreer bronontvangst, inhoudelijke review, levering en companionstatus afzonderlijk.']
],[119,372])
add('Werk in gekoppelde taakbranches/werkbomen volgens de bestaande repositoryprocedure. Houd inhoud, bron-/uitvoerbestanden en verwijzingen samen beoordeelbaar. Een import is op zichzelf geen targetgoedkeuring en geen vrijgave van een nieuwe companion. [R1, R4-R6]','small')
h('Voorkom een mengsel van oude en nieuwe edities')
add('Oude presentaties, toetsen, samenvattingen en speldata mogen niet door een gelijk paragraafnummer automatisch bij de tweede editie belanden. Koppel elk hergebruikt middel aan editie + paragraaf + opgave. Oude PDF-URL\u2019s vragen een bewuste keuze: behouden als historisch, of gebruikerslinks naar het nieuwe bestand aanpassen. Zet geen HTML-verwijspagina neer onder een PDF-bestandsnaam.')

page('5. De bouwroute en de controles')
add('Het complete boek wordt uit negen aangeleverde hoofdstuk-PDF\u2019s samengesteld. De gecombineerde boek-Markdown is een afgeleide leesbron. Een tekstcorrectie alleen in die export komt niet vanzelf in de printmaster terecht. [Z5]')
table(['Hoofdstuk','Gedrag van build_all.py','Gevolg'],[
 ['H1','Standaard: huidige manuscripten bouwen. --regenerate overschrijft.','Veilige standaard is al grotendeels aanwezig.'],
 ['H2','Standaard: auteursscripts regenereren. --manuscripts behoudt handmatige tekstwijzigingen.','Onbedoeld verlies van broncorrecties mogelijk.'],
 ['H3','Standaard: regeneratie van manuscripten en figuren. build.py bewaart directe wijzigingen.','Andere betekenis van hetzelfde bouwcommando.']
],[79,218,194])
add('Maak één normale bouwroute die actuele manuscripten rendert en een aparte, expliciete regeneratieroute. Werk bij regeneratie ook de auteursscripts bij. Houd vragen, antwoorden, figuren en QA-records synchroon; alleen een PDF aanpassen is geen bronreparatie.')
box('<b>Juiste volgorde:</b> werkbronnen corrigeren → hoofdstukexports bouwen → gecontroleerde invoer-/paginametadata bijwerken → boek samenstellen → losse exports vernieuwen → inhoud, vormgeving, links en behoud controleren.')
add('prepare_inputs.py schrijft het manifest en de invoerhashes opnieuw vanuit de huidige input. Dat is bruikbaar voor voorbereiding, maar geen bewijs dat de nieuwe input is goedgekeurd. Bewaar een onveranderlijke ontvangstregistratie en leg iedere gereviewde opvolger afzonderlijk vast. De huidige scripts veronderstellen bovendien 40 leerlingpagina\u2019s per hoofdstuk; een gewijzigde omvang vraagt bewuste aanpassing van metadata en controles. [Z5]')
h('Daadwerkelijk uitgevoerd')
table(['Controle','Uitkomst','Betekenis'],[
 ['Boekassemblage','1513 / 1513 geslaagd','207 oorspronkelijke pagina\u2019s vergeleken; behoud buiten navigatiegebieden.'],
 ['Hoofdstuk 2','1441 / 1441 geslaagd','Lokale numerieke, geometrische, bron-/PDF- en structuurcontroles.'],
 ['Hoofdstuk 3','1439 / 1439 geslaagd','Lokale numerieke, geometrische en structuurcontroles.'],
 ['Hoofdstuk 1','Niet voltooid','Validator stopt door ontbrekend Lato in een hardgecodeerd fontpad.'],
 ['Schone herbouw','Niet uitgevoerd','De meegestuurde rebuild-log is historisch pakketbewijs, geen eigen herbouw.']
],[115,119,257])
add('De assemblagecheck vergelijkt op 90 dpi buiten navigatiegebieden. Zij bewijst geen vakinhoudelijke juistheid. De routechecks eisen nog oude tekst: actualiseer ze. Voeg Boek 1 apart toe aan de platformvalidatie; behoud de bestaande Boek 2-4-controles. [R8]','small')

page('6. Kwaliteitlog: inhoud en didactiek')
add('Onderstaande punten zijn concrete vervolgwerkzaamheden. “Hoog” betekent dat het punt vóór omschakeling van de standaardeditie moet zijn opgelost of expliciet als editiegebonden beperking moet zijn beoordeeld. Middelzware, kleine tekstfouten kunnen in dezelfde revisie mee. Volledige velden en bronpaden staan ook in audit.json.','small')
def issue_block(idx,title,category,severity,evidence,action,proof):
    content=[p(f'{idx} · {title}','h2'),p(f'<b>Categorie:</b> {category}  |  <b>Ernst:</b> {severity}','small'),p(f'<b>Bewijs en geraakt oppervlak:</b> {evidence}','small'),p(f'<b>Actie:</b> {action}','issue'),p(f'<b>Sluitbewijs:</b> {proof}','small')]
    story.append(KeepTogether(content));story.append(Spacer(1,3))
issue_block('01','Oefenroute en lesduur','didactische consistentie','hoog','Negen routeteksten [Z1], drie docentengidsen [Z2] en routechecks in alle drie validate.py-bestanden.','Normale route met begeleiding, uitdagende route met bonus; tekst, scripts, validators en lesbegroting samen bijwerken.','Nieuwe route staat in bron en PDF; echte taakselectie en benodigde lesduur zijn verantwoord.')
issue_block('02','Omslag herstellen','inhoud / asset','middel','Leerlingboek p.1 en de erkende beperkingen in README.md [Z3].','Indexgrafiek en tabel dezelfde cijfers geven; vraagtaal economisch precies maken.','Nieuwe omslag visueel gecontroleerd op getallen, labels en betekenis; nieuwe hash vastgelegd.')
issue_block('03','Verklapt deelantwoord','opgavekwaliteit','middel','§1.3.1 opgave 8, p.93; leerlingmanuscript en auteursscript [Z4].','64 kilo uit het leerlingkader halen; conceptuele toelichting en antwoordmodel behouden.','De nieuwe leerling-PDF bevat geen onbedoelde numerieke oplossing bij de zelfstandige vraag.')
issue_block('04','Editie en doelen adopteren','curriculum / versiebeheer','hoog','Lokale nieuwe outline en targets versus twaalf live reviewed_final-records [Z1, R3].','Nieuwe doelversie vastleggen; uitbreidingen en verschoven eindhandelingen afzonderlijk beoordelen. Beschermde referenties via eigenaar-/CLI-werkwijze behandelen.','Iedere nieuwe doelhandeling heeft een aantoonbare leer-/oefenroute; status en versie zijn expliciet, oude reviewstatus is niet gekopieerd.')
add('Platformoverdracht is voor alle punten nodig, omdat ook de productieroute, registratie of gegenereerde uitvoer geraakt wordt. De tekstwijzigingen zelf horen in de werkbronnen van de nieuwe editie.','small')

page('7. Kwaliteitlog: repository en onderhoud')
issue_block('05','Bouwroute en bronintegriteit','tooling','hoog','build_all.py verschilt per hoofdstuk; complete boekbron is afgeleid; prepare_inputs.py herregistreert input [Z5].','Niet-destructieve standaardbuild invoeren; oorspronkelijke ontvangst en nieuwe gereviewde invoer gescheiden bewaren.','Een gecontroleerde broncorrectie blijft na twee normale builds behouden en verschijnt in alle relevante exports.')
issue_block('06','Eerste editie en actieve boom scheiden','repositoryhygiëne / navigatie','hoog','Eerste-editieboekmanifest, freeze-regels, oude 1.4/1.5 en issue #221 [R1, R4, R9].','Archief met bestand-/hashbewijs; aparte nieuwe editie; actieve downloads, manifest en navigatie gelijktijdig omzetten.','Geen gemengde standaardlevering; oude inhoud blijft traceerbaar; alleen de nieuwe twaalf paragrafen vormen de actieve printstructuur.')
issue_block('07','Afgeleide middelen en voorkennis controleren','afgeleide artefacten','middel','Nieuwe paginering en opgaven; huidige Boek 2-uitgave en voorkennisafspraken [Z1, R6-R7].','Verwijzingen, presentaties, toetsen en companiondata aan de nieuwe editie toetsen; passende acties per bestand vastleggen.','Afhankelijkhedenlijst toont wat behouden, gewijzigd of gearchiveerd is; print- en companionstatus blijven onderscheiden.')
issue_block('08','Releasecontroles uitbreiden','QA / reproduceerbaarheid','middel','Pakketchecks testen de oude route; platformcheck heeft alleen Boek 2-4-roots; H1-fontpad blokkeert lokale controle [Z5, R8].','Boek 1-validatie toevoegen; fonts en renderer vastleggen; volledige bronherbouw en gerichte actuele review uitvoeren.','Nieuwe releasechecks slagen, bestaande Boek 2-4-controles blijven intact en schone herbouw is vastgelegd.')
issue_block('09','Backlog en oud registerconflict reconciliëren','kwaliteitlogintegriteit','middel','Issue #221 en registertarget §1.2.3: Ben heeft bij P=4 volgens tabel 1, maar volgens -3P+11 geen geldige positieve vraag [R3, R9].','Opgeloste punten met nieuwe editiebewijzen afsluiten. Registerconflict apart herstellen; niet naar de nieuwe target kopiëren.','Statusrapporten verwijzen naar de juiste editie en actuele bewijsstukken; tabel/formule/antwoord zijn consistent.')

page('8. Bronnen, grenzen en oplevercriteria')
add('Peildatum: 2 oktober 2026. Repositoryhoofden bij de vergelijking:','small')
add('4veco-platform  '+A['repositories']['platform']['commit'],'mono')
add('4veco-lessen    '+A['repositories']['lessons']['commit'],'mono')
add('Ontvangen ZIP SHA-256:','small');add(A['intake']['sha256'][:32]+'<br/>'+A['intake']['sha256'][32:],'mono')
add('<b>Z1:</b> ontvangen bronpakket: sources/book-1-outline-second-edition-v1.md; twaalf bronmanuscripten in source_chapters/; QA/target_exercises.json; leerling- en antwoord-PDF.<br/><b>Z2:</b> source_chapters/*/Docenteninformatie.md en complete docentengids.<br/><b>Z3:</b> input/cover.png; README.md; qa/visual-review.md.<br/><b>Z4:</b> source_chapters/Boek_1_H3_Tweede_editie_bronpakket/1.3.1 Aanbod en aanbodfactoren - paragraaf.md (bestandsnaam gebruikt een en-dash); leerlingboek p.93.<br/><b>Z5:</b> README.md; build/prepare_inputs.py; build/build_book.py; build/validate_book.py; de drie build_all.py- en validate.py-bestanden.','small')
P='https://github.com/meijer1973/4veco-platform/blob/'+A['repositories']['platform']['commit']+'/'
L='https://github.com/meijer1973/4veco-lessen/blob/'+A['repositories']['lessons']['commit']+'/'
from urllib.parse import quote
sources=[
 ('R1','Werkwijze en eigenaarschap',P+'AGENTS.md'),
 ('R2','Actueel oefenroutecontract',P+'skills/econ-exercise-builder.md'),
 ('R3','Live doelregistratie',P+'references/authored/course-target-exercises.json'),
 ('R4','Boek 1-manifest: eerste editie',P+'build-scripts/books/book-manifests/book-1.json'),
 ('R5','Voorbeeld: Boek 2-importcontrole',P+'build-scripts/maintenance/check-book2-chat-import.js'),
 ('R6','Huidige standaardlevering Boek 2',L+quote('Boek 2 - Kosten, opbrengsten, elasticiteit en surplus/README.md')),
 ('R7','Boek 2-voorkennis en pedagogische grenzen',P+'references/authored/book-outlines/book-2-outline.md'),
 ('R8','Scope route- en leveringscontrole',P+'build-scripts/books/exercise-route-revision.js'),
 ('R9','Backlog tweede editie Boek 1', 'https://github.com/meijer1973/4veco-platform/issues/221')
]
for key,label,url in sources:add(f'<b>{key}</b> · <link href="{esc(url)}" color="#106d87">{esc(label)}</link>','small')
h('Wanneer kan de standaardlevering veilig omschakelen?')
add('De redactionele punten zijn hersteld; de nieuwe targets en route zijn beoordeeld; bron, antwoorden, figuren en exports horen bij dezelfde revisie; de hoofdstukken en het boek zijn opnieuw gebouwd; archiefhashes en navigatie kloppen; een controle op de uiteindelijke PDF\u2019s is vastgelegd. De bestaande vereisten voor review en publicatie blijven gelden.','small')
add('Het controledossier bevat audit.json, de twaalf paragraafbeoordelingen, uitgevoerde controlelogs, relevante repo-bronsnapshots en het script voor dit rapport. Het bevat geen gewijzigde boekeditie. Vervolgboeken zijn beoordeeld op integratiecontract en relevante voorkennis; er is geen nieuwe volledige inhoudsaudit van boeken 2-4 uitgevoerd.','small')

def footer(c,doc):
    c.setStrokeColor(LINE);c.line(52,48,543,48)
    c.setFont('Body',8);c.setFillColor(GREY);c.drawString(52,33,'Boek 1 · Onderzoek en invoerplan · 02-10-2026')
    c.drawRightString(543,33,str(doc.page))
    if doc.page>1:
        c.setFont('Body',7.7);c.drawString(52,810,'4VECO / TWEEDE EDITIE / ONDERZOEKSADVIES')

doc=SimpleDocTemplate(str(OUT),pagesize=(595.2756,841.8898),rightMargin=52,leftMargin=52,topMargin=53,bottomMargin=62,title='Boek 1 - Onderzoek en invoerplan',author='Onderzoeksadvies voor 4veco')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
