from pathlib import Path
import json
from html import escape
from markdown_it import MarkdownIt
ROOT=Path(__file__).resolve().parent
MD=MarkdownIt('commonmark',{'html':True,'breaks':True}).enable('table')
PAGES=[];EX=[];NUMERIC=[]
CURRENT_SECTION='';CURRENT_PAGE=0
ROUTE='Korte route: Startopgaven → Zelfstandige oefening → Doeloefening. Extra hulp nodig? Maak eerst Begeleide inoefening.'
SKIP='Heb je deze hulp niet nodig? Ga dan verder met Zelfstandige oefening.'
def p(t,cls=''):
    h=MD.render(t.strip())
    if cls:h=h.replace('<p>',f'<p class="{cls}">',1)
    return h

def box(title,t,cls='box'):
    inner=t if t.startswith(('<p','<table','<div','<ol','<ul')) else p(t)
    return f'<div class="{cls}"><p><strong>{title}</strong></p>{inner}</div>'
def fig(name,caption='',compact=False):
    return f'<figure'+(' class="compact"' if compact else '')+f'><img src="_assets/{name}.svg" alt="{escape(caption,quote=True)}"/>'+f'<figcaption>{caption}</figcaption></figure>'
def table(headers,rows,cls=''):
    h=f'<table class="{cls}"><thead><tr>'+''.join('<th>'+MD.renderInline(str(a))+'</th>' for a in headers)+'</tr></thead><tbody>'
    for row in rows:h+='<tr>'+''.join('<td>'+MD.renderInline(str(a))+'</td>' for a in row)+'</tr>'
    return h+'</tbody></table>'
def title(ref,t):
    return f'<p class="kicker">{ref} · BOEK 1 · TWEEDE EDITIE</p><h1 class="paragraph-title" id="p{ref.replace(".","")}">{t}</h1>'
def goals(items):return box('Na deze paragraaf kun je', '<ul>'+''.join('<li>'+MD.renderInline(t)+'</li>' for t in items)+'</ul>','box goals')
def ex(n,title,context,questions,answers,kind='practice',extra='',ansfig=None,criteria=None):
    assert len(questions)==len(answers),(n,len(questions),len(answers))
    e={'number':n,'title':title,'section':CURRENT_SECTION,'page':CURRENT_PAGE,'kind':kind,'context':context,'questions':questions,'answers':answers,'answer_figure':ansfig,'criteria':criteria}
    EX.append(e)
    h=f'<div class="exercise {"target" if kind=="target" else ""}" id="ex{n}"><h3>Opgave {n} · {title}</h3>'+p(context)+extra
    for i,q in enumerate(questions):h+=f'<div class="question"><span class="letter">{chr(97+i)}.</span><div class="qbody">{p(q)}</div></div>'
    return h+'</div>'
def page(section,t,body):
    global CURRENT_SECTION,CURRENT_PAGE
    PAGES.append({'section':section,'title':t,'body':body})
    return body

def at(section,n):
    global CURRENT_SECTION,CURRENT_PAGE
    CURRENT_SECTION=section;CURRENT_PAGE=n

def ck(label,expr,result):NUMERIC.append({'label':label,'expression':expr,'expected':result})
def write_pages(path,pages):
    path.write_text('\n\n'.join('<!-- PAGE '+json.dumps({'section':x['section'],'title':x['title']},ensure_ascii=False)+' -->\n\n'+x['body'] for x in pages))
def write_all():
    group=[('1.1','Voorblad.md'),('1.1.1','1.1.1 Schaarste, keuzes en alternatieve kosten – paragraaf.md'),('1.1.2','1.1.2 Verhoudingen, percentages en indexcijfers – paragraaf.md'),('1.1.3','1.1.3 Tabellen, grafieken en formules – paragraaf.md'),('1.1.4','1.1.4 Gemengde opgaven – opgaven.md'),('Overzicht','Hoofdstukoverzicht.md')]
    names=[]
    for sec,name in group:
        pp=[a for a in PAGES if a['section']==sec]
        write_pages(ROOT/name,pp);names.append(name)
    (ROOT/'chapter-order.json').write_text(json.dumps(names,ensure_ascii=False,indent=2))
    (ROOT/'QA/exercises.json').write_text(json.dumps(EX,ensure_ascii=False,indent=2))
    (ROOT/'QA/numerical_cases.json').write_text(json.dumps(NUMERIC,ensure_ascii=False,indent=2))
