# Gerenderde controle · definitieve hoofdstukuitvoer

## Uitgevoerde controle

- Alle 40 leerlingpagina’s, 20 antwoordpagina’s en 8 docentpagina’s gerenderd met PyMuPDF.
- Alle pagina’s visueel bekeken via contactbladen; tekst, tabellen, figuren en paginavoet gecontroleerd.
- De gecombineerde doelopgave op leerlingpagina 32 en de begeleide antwoordpagina 11 aanvullend
  met Poppler gerenderd en afzonderlijk op grotere schaal bekeken.
- Aandachtspunten: de afzonderlijke formulebewerkingen op leerlingpagina 23; de compacte
  grafiek op p. 28; afbouw van steun op p. 29; de combinatie van drie bronnen op p. 32;
  tegenoverliggende bronnen/vragen p. 36–37; de begrippenlijst p. 40; de docenttabellen.

## Aangepast tijdens de controle

- De hoofdstukopening spreekt over “Na dit hoofdstuk” in plaats van “Na deze paragraaf”.
- Formulestappen blijven op afzonderlijke regels zichtbaar.
- De compacte grafiek is opnieuw berekend voor haar eigen kortere canvas;
  de afbeelding is niet verticaal samengedrukt en de tekst niet verkleind.
- De assen van de eerste prijs–hoeveelheidsfiguren gebruiken dezelfde reserveringseenheid als de bron.
- De per-eenheidvergelijking en de deel/geheelvergelijking staan naast elkaar als afzonderlijke gevallen,
  niet als één rekenschema.
- Een verbale interpolatievraag is toegevoegd tussen de gedeeltelijk ingevulde grafiek en de zelfstandige productie.
- De docentmatrix noemt bestaande begeleide taken nauwkeurig en claimt geen afzonderlijke
  begeleide per-eenheid- of bronclaimtaak waar die niet is gedrukt.

## Uitkomst en grenzen

Geen zichtbare afsnijding, ontbrekende figuren, verkeerde vervangingssymbolen of overlappende
figuurlabels aangetroffen in de gecontroleerde uitvoer. Alle ontworpen pagina’s passen op
hun bedoelde PDFpagina; er is geen doorgelopen extra pagina. De verhouding tussen afbeelding
breedte en hoogte blijft behouden. Dit is een lokale auteurs-/productiecontrole,
geen onafhankelijke vakreview of classroom trial.

De bronbundel bewaart niet alle tijdelijke renderafbeeldingen. De drie PDF’s,
bouwscripts, SVG’s en de reproduceerbaarheidscontrole maken nieuwe renders mogelijk.
