"""Regenerate a temporary copy; compare every PDF page's text and raster with delivery."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import fitz
ROOT = Path(__file__).resolve().parent
STEMS = ['Boek_1_H1_Economisch_denken_en_rekenen_Tweede_editie',
         'Boek_1_H1_Antwoorden_Tweede_editie',
         'Boek_1_H1_Docenteninformatie_Tweede_editie']

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def main() -> None:
    results = []
    with tempfile.TemporaryDirectory(prefix='4veco_b1h1_rebuild_') as temp:
        target = Path(temp) / 'chapter'
        shutil.copytree(ROOT, target, ignore=shutil.ignore_patterns('__pycache__', 'output', 'paragrafen', '*.zip'))
        run = subprocess.run([sys.executable, str(target / 'build_all.py'), '--regenerate'],
                             cwd=target, text=True, capture_output=True, timeout=240)
        (ROOT / 'QA/rebuild_log.txt').write_text(run.stdout + '\n' + run.stderr)
        run.check_returncode()
        for stem in STEMS:
            with fitz.open(ROOT / 'output' / (stem + '.pdf')) as old, fitz.open(target / 'output' / (stem + '.pdf')) as new:
                item = {'file': stem + '.pdf', 'original_pages': len(old), 'rebuilt_pages': len(new), 'pages': []}
                if len(old) != len(new):
                    raise AssertionError(f'Page count changed: {stem}')
                for n, (a, b) in enumerate(zip(old, new), 1):
                    original = a.get_pixmap(alpha=False)
                    rebuilt = b.get_pixmap(alpha=False)
                    item['pages'].append({'page': n,
                        'text_equal': a.get_text() == b.get_text(),
                        'dimensions_equal': original.width == rebuilt.width and original.height == rebuilt.height,
                        'pixel_hash_equal': sha(original.samples) == sha(rebuilt.samples)})
                item['pass'] = all(x['text_equal'] and x['dimensions_equal'] and x['pixel_hash_equal'] for x in item['pages'])
                results.append(item)
    report = {'scope': 'Temporary clean regeneration of author manuscripts, assets and PDFs; exact extracted text and 72 dpi rendering comparison of every page.',
              'files': results, 'total_pages_compared': sum(x['original_pages'] for x in results), 'pass': all(x['pass'] for x in results)}
    (ROOT / 'QA/rebuild_verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print('Rebuild verification:', report['pass'], report['total_pages_compared'], 'pages')
    if not report['pass']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
