"""Build the delivered chapter. --regenerate also resets manuscripts from author scripts."""
from pathlib import Path
import argparse
import subprocess
import sys
ROOT = Path(__file__).resolve().parent

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--regenerate', action='store_true',
                        help='Overwrite manuscripts and figures from the original authoring scripts.')
    args = parser.parse_args()
    scripts = ['make_assets.py', 'author_chapter.py', 'author_answers.py', 'author_teacher.py'] if args.regenerate else []
    scripts += ['build.py', 'validate.py', 'export_paragraphs.py']
    for script in scripts:
        print(f'\n--- {script} ---', flush=True)
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)

if __name__ == '__main__':
    main()
