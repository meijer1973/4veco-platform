# Hoofdstukplan vóór uitwerking — Boek 1, tweede editie, §1.1

Basis: `sources/book-1-outline-second-edition-v1.md`, expliciet gebruikt op verzoek van de eigenaar op 8 september 2026. Dit is nieuwe tweededitieproductie; geen wijziging of herbeoordeling van de gedrukte eerste editie. De nieuwe doelen en doelopgaven zijn lokale uitwerkingen van de nieuwe opzet, geen gepromoveerde repositoryrecords.

## Backward design

| Doel | Doelopgave: observeerbare handeling | Uitgewerkt voorbeeld | Start | Begeleid | Zelfstandig | Status |
|---|---|---|---|---|---|---|
| 111: schaarste en haalbare keuze | 7a: middel, twee haalbare maar onverenigbare toepassingen | Buurtzaal stap 1 | 2 | 3,4 | 5,6 | Gepland |
| 111: netto bedrag per tijdseenheid naar totaal | 7b: beide uitkomsten berekenen met eenheid | Buurtzaal stap 2 | 1 | 3,4 | 5 | Gepland |
| 111: beste opgegeven alternatief, niet verschil of betaling | 7c | Buurtzaal stap 3 | 2 | 3,4 | 5,6 | Gepland |
| 111: expliciet besliscriterium en begrenzing | 7d | Buurtzaal stap 4 | 2 | 4 | 6 | Gepland |
| 112: bedrag per eenheid en deel/geheel | 18a,f | Klimclub a,f | 10 | 12,14 | 15,17 | Gepland |
| 112: getekende procentuele verandering | 18b | Klimclub b | 10,11 | 12 | 15 | Gepland |
| 112: nieuwe waarde na procentuele verandering | 18c | Klimclub c | 11 | 12 | 15 | Gepland |
| 112: index uit benoemde basis | 18d | Klimclub d | 11 | 13 | 16 | Gepland |
| 112: verandering tussen twee niet-100-indexen | 18e | Klimclub e | 11 | 13 | 16 | Gepland |
| 112: procentpunten versus relatieve procenten | 18f,g | Klimclub f,g | 11 | 14 | 17 | Gepland |
| 113: tabel, variabele, schaal, assen, zelf tekenen | 30a | Rolschaatsen A | 23 | 24,25 | 27 | Gepland |
| 113: interpoleren op een verondersteld recht segment | 30b | Rolschaatsen B | 23 | 24,25 | 27 | Gepland |
| 113: bronclaim controleren met percentage en beperking | 30c | Rolschaatsen C | 22 | 24,26 | 27 | Gepland |
| 113: invullen en terugrekenen uit verstrekte formule | 30d,e | Materiaalhuur D,E | 22 | 26 | 28 | Gepland |
| 113: basis en hoogte van rechthoek/driehoek | 30f,g | Plattegrond F,G | 22 | 26 | 29 | Gepland |
| 114: selecteren, onverenigbare activiteitkeuze, totaal en alternatieve kosten | 36a,b | Bronkeuze p34 | eerdere doelen | eerdere doelen | 34,35 | Gepland |
| 114: onafhankelijke grafiek, interpolatie, percentage en indexclaim | 36c–f | Bronkeuze p34 | eerdere doelen | eerdere doelen | 34,35 | Gepland |

Rekenen met tabelverschillen per horizontale eenheid wordt expliciet uitgelegd in 113 en toegepast in 27; het begrip marginale kosten wordt niet geïntroduceerd. Formules voor kosten, opbrengst, winst, elasticiteit en surplus zijn geen nieuwe zelfstandige kennis in dit hoofdstuk.

## Paginaraming
1: hoofdstukopening. 2–8: 111. 9–19: 112. 20–33: 113. 34–38: 114. 39–40: overzicht en begrippen. Maximum 40 leerlingpagina’s; antwoorden en docentmateriaal apart.

## Didactische routes
De drie theorieparagrafen gebruiken de zeven repositorykoppen in de voorgeschreven volgorde. Samenvatting tussen uitgewerkt voorbeeld en startopgaven. Bij 112 en 113 worden instructie en oefening in fasen verdeeld; niet alle optionele stof past bovenop één kernles. Concrete lesroutes volgen na de vraagspecificatie in Docenteninformatie.md.


## Uitvoeringsnotitie na de bouw

De tabel hierboven bewaart de startbeslissingen vóór de uitwerking. De definitieve
dekking staat in `Docenteninformatie.md`, p. 2–4, en de volledige vraag-/antwoordregistratie
in `QA/exercises.json`. De volgende verwijzingen zijn in de uitvoering verfijnd:

- In §1.1.1 toetst 7d de onjuiste claim dat gratis ruimte geen alternatieve kosten heeft; 7e
  toetst het andere keuzecriterium. Het buurtzaalvoorbeeld modelleert dit in stap 4 en 5.
- Bij §1.1.3 halen startopgaven 22–23 alleen de korte reken- en asconventies op.
  Formulegebruik en oppervlaktegeometrie krijgen hun eerste expliciete instructie
  op p. 23–24; deze voorkennis wordt niet onterecht als al beheerst opgevoerd.
- De bronclaimvaardigheid van 30c wordt voorbereid op p. 25–26 en in zelfstandig
  27c. Niet elk begeleid onderdeel hoeft elke doelhandeling opnieuw te toetsen.
- 26c is toegevoegd voor verbaal interpoleren zonder grafiek, tussen een ingevuld
  grafiekvoorbeeld en de onafhankelijke grafiekproductie van 27 en 30.
- Het gemengde target 36 bevat ook 36g: advies met het gegeven bezoekersdoel en
  een expliciete begrenzing van de modelclaim. Dit gebruikt geen nieuwe theorie.

De uiteindelijke leerlingindeling is 40 pagina’s; antwoordboek 20, docenteninformatie 8.
De gedrukte uitwerking bevat 38 opgaven en 100 deelvragen. De beginstatus “Gepland”
in de historische tabel is geen open inhoudsgat: controles en definitieve
dekking zijn in de genoemde uitvoer vastgelegd. Er wordt geen extern reviewoordeel geclaimd.
