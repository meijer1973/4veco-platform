"""Create the editable answer manuscript from the checked question/answer registry."""
from author_common import *
import json
E={x['number']:x for x in json.loads((ROOT/'QA/exercises.json').read_text())}
AP=[]
def add(sec,t,b):AP.append({'section':sec,'title':t,'body':b})
FIGS={25:('1.1.3_ans_25','A1 · Opgave 25: alle punten, lijnstukken en hulplijnen.'),27:('1.1.3_ans_27','A2 · Opgave 27: Q = 100 bij P = € 5; de bronwaarden zijn behouden.'),29:('1.1.3_ans_29','A3 · Opgave 29: de rechthoek is 40 m², de driehoek 20 m².'),30:('1.1.3_ans_30','A4 · Opgave 30a–c: de interpolatie ligt op het gegeven rechte segment.'),36:('1.1.4_ans_36','A6 · Opgave 36c–d: de grafiek hoort bij bron B, niet bij bron C.'),37:('1.1.4_ans_37','A7 · Opgave 37b: basis 6 meter en hoogte 3 meter.')}
def item(n,first=0,last=None,diagram=True):
    e=E[n];last=len(e['answers']) if last is None else last
    head=f'Opgave {n} · {e["title"]}'+(' — vervolg' if first else '')
    h=f'<h3 id="ans{n}{"cont" if first else ""}">{head}</h3>'
    for i in range(first,last):
        answer,why=e['answers'][i]
        h+='<div class="answer-item">'+p(f'**{chr(97+i)}.** '+answer)
        if why:h+=p('**Waarom:** '+why,'why')
        h+='</div>'
    if e['criteria']:
        h+=box('Beoordelingscriteria','<ul>'+''.join('<li>'+MD.renderInline(c)+'</li>' for c in e['criteria'])+'</ul>','box small')
    if diagram and n in FIGS:h+=fig(*FIGS[n])
    return h
add('Antwoorden','Zo gebruik je dit antwoordboek','<p class="kicker">BOEK 1 · TWEEDE EDITIE · HOOFDSTUK 1</p><h1>Antwoorden<br>Economisch denken en rekenen</h1>'+p('Dit antwoordboek hoort bij het leerlinghoofdstuk van 40 pagina’s. Het bevat de antwoorden op **38 opgaven met 100 deelvragen**. De antwoorden bij de denkertjes geven één verdedigbaar voorbeeld; andere goed onderbouwde antwoorden zijn mogelijk.')+table(['Paragraaf','Opgaven','Pagina in dit antwoordboek'],[['1.1.1 Schaarste, keuzes en alternatieve kosten','1–9','2'],['1.1.2 Verhoudingen, percentages en indexcijfers','10–21','5'],['1.1.3 Tabellen, grafieken en formules','22–33','10'],['1.1.4 Gemengde opgaven','34–38','17']])+box('Vergelijk je werkwijze','Kijk niet alleen naar het laatste getal. Vergelijk de gekozen bron, de basis van de vergelijking, de berekening en de eenheid. De toelichting bij “Waarom” legt uit wat de rekenstap betekent.','box')+box('Afronden','Rond geldbedragen zo nodig af op centen. Rond percentages en indexcijfers zo nodig af op twee decimalen. Gebruik ongeronde tussenuitkomsten. “−20%” en “een daling met 20%” drukken dezelfde verandering uit.','box')+p('Bij een grafiek is een andere nette schaal toegestaan wanneer alle punten, eenheden en vereiste aflezingen kloppen. De antwoordfiguren zijn niet bedoeld om zonder nadenken over te nemen.')+p('Alle economische situaties en cijfers zijn geconstrueerde lesvoorbeelden; het zijn geen uitspraken over actuele prijzen, tarieven of gebeurtenissen.','note'))
add('1.1.1','Start en begeleide inoefening', '<h2 id="ant111">1.1.1 · Schaarste en keuzes</h2>'+''.join(item(n) for n in [1,2,3,4]))
add('1.1.1','Zelfstandig en doelopgave',''.join(item(n) for n in [5,6,7]))
add('1.1.1','Denkertje en herhaling',''.join(item(n) for n in [8,9])+box('Veelgemaakte verwarring','Bij € 180 tegenover € 150 zijn de alternatieve kosten van de eerste optie € 150. Het verschil van € 30 is de extra uitkomst. Bij een gratis activiteit kunnen tijd en ruimte nog steeds een andere waardevolle toepassing hebben.','warning'))
add('1.1.2','Start en begeleide inoefening','<h2 id="ant112">1.1.2 · Verhoudingen en veranderingen</h2>'+''.join(item(n) for n in [10,11,12]))
add('1.1.2','Indexen en twee veranderingen',''.join(item(n) for n in [13,14]))
add('1.1.2','Zelfstandige oefening',''.join(item(n) for n in [15,16,17]))
add('1.1.2','Doeloefening',item(18))
add('1.1.2','Denkertje en herhaling',''.join(item(n) for n in [19,20,21]))
add('1.1.3','Start en grafieklezen','<h2 id="ant113">1.1.3 · Tabellen, grafieken en formules</h2>'+''.join(item(n) for n in [22,23,24]))
add('1.1.3','Begeleide inoefening',item(25)+item(26))
add('1.1.3','Zelfstandig tekenen',item(27))
add('1.1.3','Zelfstandig rekenen en meten',item(28)+item(29))
add('1.1.3','Doeloefening · bron A',item(30,last=3))
add('1.1.3','Doeloefening · bron B en C',item(30,first=3,diagram=False)+fig('1.1.3_ans_30_area','A5 · Opgave 30f–g: gebruik de verschillen tussen de asposities.'))
add('1.1.3','Denkertje en herhaling',''.join(item(n) for n in [31,32,33]))
add('1.1.4','Gemengde oefening','<h2 id="ant114">1.1.4 · Gemengde opgaven</h2>'+item(34)+item(35))
add('1.1.4','Doeloefening · keuze en grafiek',item(36,last=4))
add('1.1.4','Doeloefening · indexen en advies',item(36,first=4,diagram=False)+box('Een goed onderbouwd antwoord','Bron A ondersteunt de keuze voor de middag. Bron B ondersteunt het bezoekersadvies bij € 7. Bron C ondersteunt de prijsvergelijking tussen jaren. De gegevens zijn niet onderling uitwisselbaar.','box'))
add('1.1.4','Extra gemengde oefening',item(37)+item(38))
write_pages(ROOT/'Antwoorden.md',AP)
print('Answer pages planned:',len(AP))
