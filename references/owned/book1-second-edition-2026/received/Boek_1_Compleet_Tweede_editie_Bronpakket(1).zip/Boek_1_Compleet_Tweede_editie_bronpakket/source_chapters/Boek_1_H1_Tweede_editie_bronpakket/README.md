# Boek 1 · Hoofdstuk 1 · Tweede editie

**Economisch denken en rekenen** — 4 vwo.

Leerlinghoofdstuk: **40 pagina’s**. Antwoordboek: **20 pagina’s**. Docenteninformatie: **8 pagina’s**.
38 opgaven, 100 deelvragen, vier nieuw uitgewerkte doelopgaven (7, 18, 30, 36).
22 leerlingfiguren en zeven antwoordfiguren. De vier paragraafnummers zijn 1.1.1–1.1.4.

## Afdrukken

De drie definitieve documenten staan in `output/`. Druk af op A4, op ware grootte.
Voor het leerlinghoofdstuk: dubbelzijdig, omslaan over de lange zijde. De bronnen
van doelopgave 36 staan op p. 36 en de vragen op p. 37. De antwoorden blijven
buiten het leerlingboek. De bestanden in `paragrafen/` zijn uitsneden; zij bewaren
de oorspronkelijke paginanummers en zijn geen opnieuw gepagineerde losse boeken.

## Bronnen en inhoud

`sources/book-1-outline-second-edition-v1.md` is de gebruikte nieuwe boekopzet.
`sources/source-register.json` legt de repositorypaden, gelezen bereiken en
teruggegeven blob-SHA’s vast. Beide repositorykaarten waren bereikbaar.
De nieuwe editie volgt de expliciete opdracht van de eigenaar; de
bevroren eerste editie en de live repositories zijn niet gewijzigd.

De boekopzet geeft doelen, briefs en afbakening; de situaties, getallen,
teksten, opgaven, afbeeldingen en antwoorden zijn voor deze hoofdstukuitwerking
gemaakt. Zij vormen geen nieuwe officiële examencasus, actuele dataset of
gepromoveerd repositorytarget. Formele kosten-, opbrengsten-, elasticiteits- en
surplusleer blijft leerstof voor Boek 2. Hier worden de rekenhandelingen voorbereid.

## Bestanden bewerken

- De afzonderlijke paragraafmanuscripten zijn de bewerkbare leerlingbron.
  `chapter-order.json` bepaalt de volgorde. `Voorblad.md` en
  `Hoofdstukoverzicht.md` bevatten de opening en de afsluiting.
- `Antwoorden.md` en `Docenteninformatie.md` zijn afzonderlijke bewerkbare bronnen.
- `print.css` bepaalt de opmaak; `make_assets.py` genereert SVG en PNG in `_assets/`.
- Het samengestelde `1.1 … – hoofdstuk.md` wordt opnieuw opgebouwd uit de losse delen.
- `author_*.py` reconstrueren de geleverde teksten en de vraagregistratie.
  **Deze scripts overschrijven handmatige wijzigingen in de Markdown.**

`build.py` rendert de bewerkbare manuscripten zonder auteursinhoud te regenereren.

## Reproduceren

De gebruikte Pythonbibliotheekversies staan in `requirements.txt`; de geteste
omgeving in `QA/build_environment.json`. WeasyPrint vereist de bijbehorende
systeemafhankelijkheden voor tekst-/PDFweergave. Lato en DejaVu zijn als
systeemlettertypen gebruikt; **lettertypebestanden worden niet meegeleverd**.
De grafieklabelcontrole gebruikt de Linux-paden onder `/usr/share/fonts/truetype/lato/`.
Gebruik voor exacte layoutherhaling dezelfde lettertypen en bibliotheekversies.

```bash
python -m pip install -r requirements.txt
# Bewerkte manuscripten renderen, controleren en paragraafuitsneden maken:
python build_all.py
# De geleverde auteursversie volledig opnieuw genereren (overschrijft edits):
python build_all.py --regenerate
```

De controles toetsen de geleverde versie: na inhoudelijke toevoegingen moet ook
de vraagregistratie, uitlijningsinformatie en eventueel het verwachte paginatal
worden aangepast. De controle slaagt niet door nieuwe leerstof stilzwijgend te negeren.

## Kwaliteit en begrenzing

`design.md` bewaart het plan vóór uitwerking met een uitvoeringsnotitie.
De definitieve doeldekking en zeven lesroutes staan in de docenteninformatie.
`QA/exercises.json` bevat de 100 vraag-/antwoordkoppelingen; `QA/figures.json`
de gegevens en geometrie van de figuren. `validate.py` controleert rekengevallen,
werkelijke SVGcoördinaten, punt-lijnpassing, oppervlaktes, verwijzingen, kopvolgorde,
antwoorddekking en PDFstructuur. De controle bevat veel elementcontroles;
het aantal is geen maat voor onafhankelijke pedagogische beoordelingen.

`QA/visual_review.md` beschrijft de gerenderde controle. De aangekondigde lestijd
is een ontwerpinschatting, geen gemeten leerlingtempo. Deze productiecontrole
is geen onafhankelijke vakreview, examenvalidatie of bewijs van leereffect.
Er is geen nieuwe audit van het landelijke examenprogramma uitgevoerd.
