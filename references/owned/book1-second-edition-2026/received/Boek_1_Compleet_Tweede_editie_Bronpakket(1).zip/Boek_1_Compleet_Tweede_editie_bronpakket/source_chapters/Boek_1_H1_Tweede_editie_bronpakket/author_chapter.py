from author_common import *
import author_111,author_112,author_113,author_114
for m in [author_111,author_112,author_113,author_114]:m.make()
assert len(PAGES)==40,len(PAGES)
assert sorted(x['number'] for x in EX)==list(range(1,39))
write_all()
print('Authored',len(PAGES),'pages;',len(EX),'exercises;',sum(len(x['questions']) for x in EX),'subquestions')
