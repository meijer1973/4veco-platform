"""Export chapter excerpts with their original page numbers; do not reflow content."""
from pathlib import Path
import json
import fitz
ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'paragrafen'
DEST.mkdir(exist_ok=True)
SPECS = [
    ('1.1.1', 'Schaarste, keuzes en alternatieve kosten', (2, 8), (2, 4)),
    ('1.1.2', 'Verhoudingen, percentages en indexcijfers', (9, 19), (5, 9)),
    ('1.1.3', 'Tabellen, grafieken en formules', (20, 33), (10, 16)),
    ('1.1.4', 'Gemengde opgaven', (34, 38), (17, 20)),
]
files = {'student': 'Boek_1_H1_Economisch_denken_en_rekenen_Tweede_editie.pdf',
         'answers': 'Boek_1_H1_Antwoorden_Tweede_editie.pdf'}
record = []
for ref, title, student, answers in SPECS:
    for kind, (first, last) in [('student', student), ('answers', answers)]:
        source = ROOT / 'output' / files[kind]
        with fitz.open(source) as src:
            if not 1 <= first <= last <= len(src):
                raise ValueError(f'Invalid range for {source.name}: {first}–{last}')
            dst = fitz.open()
            dst.insert_pdf(src, from_page=first - 1, to_page=last - 1)
            # Chapter navigation outside an excerpt is not retained.
            for page in dst:
                for link in page.get_links():
                    if link.get('page', -1) >= len(dst):
                        page.delete_link(link)
            dst.set_metadata({'title': f'{ref} {title} — {"antwoorden" if kind == "answers" else "paragraaf"} — tweede editie',
                              'subject': 'Uitsnede met oorspronkelijke hoofdstukpaginanummers', 'author': ''})
            dst.set_toc([[1, f'{ref} {title}', 1]])
            name = f'{ref} {title} – {"antwoorden" if kind == "answers" else "paragraaf"}.pdf'
            dst.save(DEST / name, garbage=4, deflate=True)
            dst.close()
            record.append({'ref': ref, 'kind': kind, 'source': files[kind], 'pages_in_source': [first, last], 'file': name})
(ROOT / 'QA' / 'paragraph_exports.json').write_text(json.dumps(record, ensure_ascii=False, indent=2))
print(f'Exported {len(record)} paragraph excerpts.')
