# Visuele en redactionele controle

## Werkwijze en werkelijk bekeken uitvoer

De 40 leerlingpagina's, 22 antwoordpagina's en 8 docentpagina's zijn met MuPDF gerenderd en in volledige contactreeksen bekeken. Daarnaast zijn vergrote pagina's gecontroleerd voor de koopbeslissingen, de stapillustratie, de lineaire functie, de drie gelijkgeschaalde optelgrafieken, de nulbijdrage en de gemengde doelopgave. Voor de definitieve versie zijn het gecorrigeerde voorblad en de vernieuwde labels van de optelgrafieken opnieuw bekeken. Poppler is als tweede renderer gebruikt en bekeken op leerlingpagina 25 en antwoordpagina 21.

De pagina's bevatten geen bij deze inspectie aangetroffen afgebroken tekst, onleesbare vervangingssymbolen of overlappende figuurlabels. Bron en vraag blijven naast elkaar op pagina's 36–37. Individuele oefen- en doelpagina's hebben bewust meer open ruimte dan uitlegpagina's; ze zijn geen invulboek en vereisen een schrift.

## Uitgevoerde correcties tijdens de bouw

1. De openingspagina gebruikt ‘Na dit hoofdstuk kun je’, niet het label van een afzonderlijke paragraaf.
2. De samenvatting van §1.2.2 staat bij het uitgewerkte voorbeeld, direct vóór de startopgaven. Daardoor passen de start en eerste begeleide oefening zonder letterverkleining.
3. De kop Begeleide inoefening van §1.2.3 staat bij de eerste begeleide opgave, niet alleen onderaan de voorgaande pagina.
4. De optelgrafiek eindigt waar beide gegeven lineaire regels geldig zijn. Het bovenste ontbrekende deel wordt pas als aparte nulbijdrage-illustratie getoond. De werkelijke eindpunten worden teruggelezen in de validatie.
5. De drie miniassen bij horizontaal optellen hebben dezelfde prijs- en hoeveelheidsschaal en elk een eigen P-label. Een gezamenlijke eenheidsregel blijft zichtbaar onder de grafieken.
6. In het gemengde geval is Sem al in groep A opgenomen. Zijn expliciete betalingsbereidheden passen binnen de bronwaarden; de vraag vraagt expliciet om dubbeltelling te voorkomen.
7. De beginsituaties en de analytische tussenstap van de twee veranderingen zijn afzonderlijk benoemd; geen nieuwe marktprijs of aanboduitkomst wordt uit vraag alleen afgeleid.

## Reikwijdte

Dit is een lokale auteurscontrole op de uitgave. Er wordt geen onafhankelijke specialistische goedkeuring, officiële examencertificering of klassikaal gemeten leerwinst geclaimd. Alle voorbeeldgegevens zijn geconstrueerd. De zeven lesplannen blijven schattingen; docentwaarnemingen bepalen welke steun nodig is.
