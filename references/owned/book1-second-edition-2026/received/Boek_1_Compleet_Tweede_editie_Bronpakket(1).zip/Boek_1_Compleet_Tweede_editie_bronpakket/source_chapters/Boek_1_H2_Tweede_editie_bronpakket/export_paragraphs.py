"""Export complete paragraphs and matching answers; preserve chapter page numbering."""
from pathlib import Path
import json
import fitz
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'paragrafen';DEST.mkdir(exist_ok=True)
ROWS=[('1.2.1','Betalingsbereidheid en individuele vraag',2,13,2,6),
      ('1.2.2','Vraagfactoren',14,23,7,12),
      ('1.2.3','Van individuele naar collectieve vraag',24,33,13,17),
      ('1.2.4','Gemengde opgaven',34,38,18,22)]
report=[]
for ref,title,a,b,c,d in ROWS:
    for typ,source,start,end in [('paragraaf' if ref!='1.2.4' else 'opgaven','Boek_1_H2_Vraag_Tweede_editie.pdf',a,b),('antwoorden','Boek_1_H2_Antwoorden_Tweede_editie.pdf',c,d)]:
        with fitz.open(ROOT/'output'/source) as src, fitz.open() as pdf:
            pdf.insert_pdf(src,from_page=start-1,to_page=end-1)
            pdf.set_metadata({'title':f'{ref} {title} – {typ} · Tweede editie','subject':'Economie · 4 vwo'})
            toc=[[1,f'{ref} {title}',1]]
            for level,t,page in src.get_toc():
                if start<=page<=end and t!=f'{ref} {title}':toc.append([2,t,page-start+1])
            pdf.set_toc(toc)
            f=DEST/f'{ref} {title} – {typ}.pdf';pdf.save(f,garbage=4,deflate=True)
        with fitz.open(f) as pdf, fitz.open(ROOT/'output'/source) as src:
            assert len(pdf)==end-start+1
            assert all(p.get_text()==src[start+i-1].get_text() for i,p in enumerate(pdf))
        report.append({'file':str(f.relative_to(ROOT)),'source':source,'pages_in_source':[start,end],'pages':end-start+1,'exact_text_preserved':True})
(ROOT/'QA/paragraph_exports.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Exported',len(report),'paragraph and answer PDFs.')
