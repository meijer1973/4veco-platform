from author_common import *

def make():
    at('1.2.3',24)
    page('1.2.3','Wat willen de kopers samen?',title('1.2.3','Van individuele<br>naar collectieve vraag')+
    goals(['hoeveelheden van kopers bij dezelfde prijs optellen;','eenvoudige vraagfuncties binnen de gegeven grenzen samenvoegen;','de gezamenlijke vraag tekenen en uitleggen waarom een koper soms nul bijdraagt.'])+
    p('Een verkooppunt vraagt aan twee vaste kopers hoeveel liter sap zij bij verschillende prijzen willen kopen. Bij € 2 wil koper A 4 liter per week en koper B 8 liter. Hoe groot is hun vraag samen?')+
    box('Collectieve vraag','De vraag van **alle kopers op een afgebakende markt samen**, bij verschillende prijzen en gelijkblijvende overige omstandigheden. Je telt hun gevraagde hoeveelheden op **bij dezelfde prijs**.','definition')+
    table(['Prijs P (€ per liter)','q van koper A','q van koper B','Samen Q'],[['0','8','12','20'],['2','4','8','12'],['4','0','4','4']])+
    p('Alle hoeveelheden staan hier in **liter per week**. Voor deze kleine voorbeeldmarkt tellen alleen A en B mee. Bij € 2 is Q = 4 + 8 = **12 liter per week**. De prijs blijft € 2; die tel je niet op.')+
    box('Drie controles vóór het optellen','Gaat het over **hetzelfde product**, **dezelfde periode en eenheid** en **dezelfde prijs**? Tel kopers of groepen bovendien niet dubbel mee.','box')+
    p('Een gemiddelde is iets anders. (4 + 8) / 2 = 6 liter per koper, maar de gezamenlijke vraag is 12 liter. Voor collectieve vraag wil je het totaal, niet het gemiddelde.'))

    at('1.2.3',25)
    page('1.2.3','Horizontaal optellen, daarna formules',p('De drie grafieken laten dezelfde prijs van € 2 zien. Lees in iedere kopersgrafiek de hoeveelheid af. Tel de horizontale hoeveelheden 4 en 8 op. Het nieuwe punt heeft coördinaten **(12; 2)**.')+
    fig('1.2.3_fig_1','Figuur 17 · De prijs- en hoeveelheidsschalen zijn gelijk. De somlijn is alleen getekend zolang beide lineaire rekenregels geldig zijn.')+
    p('Bij deze bron horen q<sub>A</sub> = 8 − 2P (0 ≤ P ≤ 4) en q<sub>B</sub> = 12 − 2P (0 ≤ P ≤ 6). Boven de eigen prijsgrens vraagt die koper niets. Voor prijzen van € 0 tot en met € 4 kun je de twee rekenregels direct optellen.')+
    box('Collectieve vraag · alleen voor 0 ≤ P ≤ 4','Q = q<sub>A</sub> + q<sub>B</sub>\nQ = (8 − 2P) + (12 − 2P)\nQ = 20 − 4P','formula')+
    p('Tel de losse getallen op: 8 + 12 = 20. Tel de P-termen op: −2P − 2P = −4P. **Twee keer 2 liter minder is samen 4 liter minder** bij een euro prijsstijging. De haakjes houden eerst zichtbaar welke regel bij welke koper hoort.')+
    p('Controle bij € 2: Q = 20 − 4 × 2 = **12 liter per week**. Dat is dezelfde uitkomst als in de tabel.'))

    at('1.2.3',26)
    page('1.2.3','Een koper kan afhaken',p('Verhoog de prijs in dezelfde sapmarkt naar € 5. Voor A levert 8 − 2 × 5 de rekenuitkomst −2 op. Maar A vraagt geen negatieve liters: de prijs ligt boven zijn koopgrens van € 4. Zijn bijdrage is **nul**.')+
    p('B vraagt bij € 5 nog 12 − 2 × 5 = **2 liter per week**. Samen vragen zij dus 0 + 2 = **2 liter per week**, niet 20 − 4 × 5 = 0 liter.')+
    fig('1.2.3_fig_2','Figuur 18 · De vorm verandert wanneer A niets meer koopt. De vraag van B verdwijnt daardoor niet.')+
    box('Een formule heeft grenzen','Q = 20 − 4P is geldig voor 0 ≤ P ≤ 4. Daarbuiten mag je die somformule niet doortrekken. Bekijk opnieuw wie nog koopt en tel alleen niet-negatieve hoeveelheden op.','warning')+
    p('Bij € 4 is A’s hoeveelheid al precies nul en is de somformule nog correct. Boven € 4 werkt A’s oorspronkelijke lineaire rekenregel niet meer als aankoopvoorspelling. Boven € 6 vragen beiden niets.')+
    p('Je hoeft hiervoor geen uitgebreide nieuwe formule te maken. **Prijs kiezen → per koper berekenen en koopgrens controleren → geldige hoeveelheden optellen.** Ook een tekening mag niet buiten de opgegeven geldigheid zomaar als rechte lijn worden verlengd.'))

    at('1.2.3',27)
    page('1.2.3','Uitgewerkt voorbeeld · bron en som','## Uitgewerkt voorbeeld\n\n'+
    p('Twee kopers bestellen limonade. Alle hoeveelheden zijn liter per week, P is euro per liter. Voor koper A geldt q<sub>A</sub> = 12 − 3P (0 ≤ P ≤ 4). Voor B geldt q<sub>B</sub> = 8 − P (0 ≤ P ≤ 8). Boven de eigen grens vraagt de koper nul. Andere omstandigheden blijven gelijk.')+
    p('**a. Vul de tabel in.** Reken eerst per koper. Bij € 2 vraagt A: 12 − 3 × 2 = 6 liter. B vraagt: 8 − 2 = 6 liter. Samen: 6 + 6 = 12 liter.')+
    table(['P (€ per liter)','q<sub>A</sub>','q<sub>B</sub>','Q samen'],[['0','12','8','20'],['2','6','6','12'],['3','3','5','8'],['4','0','4','4'],['6','0','2','2']])+
    p('**b. Schrijf de somfunctie zolang beide rekenregels geldig zijn.**\n\nQ = (12 − 3P) + (8 − P) = **20 − 4P**, voor **0 ≤ P ≤ 4**.\nControle bij € 3: Q = 20 − 4 × 3 = **8 liter per week**; gelijk aan de tabel.')+
    p('**c. Bereid de tekening voor.** Je tekent alleen het deel voor 0 ≤ P ≤ 4. De eindpunten zijn **(20; 0)** en **(4; 4)**. Het punt **(12; 2)** ligt ertussen. De lijn hoeft binnen dit interval niet de P-as te bereiken.')+
    p('**d. Bereken de gezamenlijke vraag bij € 6.** A’s prijsgrens is overschreden, dus q<sub>A</sub> = 0. B: q<sub>B</sub> = 8 − 6 = 2. Samen: **2 liter per week**.')+
    p('**e. Waarom niet Q = 20 − 4 × 6?** De −4 uit die berekening bevat een negatieve bijdrage van A. B’s vraag mag niet worden verminderd met liters die A niet koopt.'))

    at('1.2.3',28)
    page('1.2.3','Uitgewerkt voorbeeld · grafiek en start',fig('1.2.3_we_1','Figuur 19 · Alleen het gevraagde prijsinterval is getekend. Een verlenging naar de P-as zou buiten de geldige somfunctie vallen.')+
    box('Samenvatting · 1.2.3','Tel hoeveelheden bij dezelfde prijs op. Houd product, periode en eenheid gelijk. Voeg losse getallen en P-termen samen, met de geldigheid erbij. Boven een koopgrens draagt een koper nul bij, geen negatief aantal. In de gemengde opgaven kies je zelf welke bron en regel je nodig hebt.','box summary')+
    '\n\n## Startopgaven\n\n'+
    ex(23,'Invullen en vergelijken','Gebruik alleen eerder geoefende rekenstappen.',
      ['Bereken q bij P = 4 in q = 8 − 2P, geldig voor 0 ≤ P ≤ 4. q is liter per week.','Een hoeveelheid stijgt van 12 naar 18 liter per week. Bereken de procentuele verandering.'],
      [('q = 8 − 2 × 4 = **0 liter per week**.','De prijs ligt precies op het snijpunt met de prijsas.'),('(18 − 12) / 12 × 100% = **50% stijging**.','De oude hoeveelheid van 12 liter is de basis.')],kind='start')+
    ex(24,'Het totaal is geen gemiddelde','Bij dezelfde prijs vraagt een koper 3 liter melk per week en een tweede 5 liter. Alleen deze twee kopers tellen mee.',
      ['Bereken de collectieve vraag. Wat gaat er mis als je de uitkomst door twee deelt?'],
      [('Q = 3 + 5 = **8 liter per week**. Delen door twee geeft 4 liter per koper: dat is het gemiddelde, niet het totaal.','Collectieve vraag is de som van alle hoeveelheden bij die prijs.')],kind='start')+
    box('Oefenroute',ROUTE,'route')+
    '\n\n## Begeleide inoefening\n\n'+p(SKIP,'note'))

    at('1.2.3',29)
    page('1.2.3','Begeleide inoefening · de som aflezen',ex(25,'Twee kopers van verf','Twee hobbyclubs kopen verf. De volgende grafieken geven hun vraag in liter per week weer. Andere omstandigheden blijven gelijk. Lees de ingevulde hulplijnen.',
      ['Lees voor A en B de hoeveelheid bij € 2 af. Controleer het gezamenlijke punt.','Een leerling telt de twee prijzen op en noteert “12 liter bij € 4”. Leg uit wat daar misgaat.'],
      [('A vraagt **4 liter**, B **8 liter**. Samen 4 + 8 = **12 liter per week**, dus het punt **(12; 2)**.','De prijs is in alle drie grafieken hetzelfde; alleen de hoeveelheden worden opgeteld.'),('De prijs blijft **€ 2 per liter**. Er worden niet twee prijsbedragen voor dezelfde liter bij elkaar opgeteld.','Collectieve vraag is horizontaal optellen bij één prijs, geen optelsom van prijzen.')],kind='guided',extra=fig('1.2.3_ex_25','Figuur 20 · De gezamenlijke grafiek gebruikt dezelfde schalen; het punt bij € 2 is volledig gegeven.'))+
    box('Zeg de som in woorden','“Bij een prijs van € 2 per liter willen de twee kopers samen 12 liter per week kopen.” Daarmee controleer je in één zin de prijs, de eenheid, de periode en het niveau van je uitkomst.','box'))

    at('1.2.3',30)
    page('1.2.3','Begeleide inoefening · afronden en loslaten',ex(26,'Teken de gezamenlijke lijn','Twee gezinnen kopen chocolademelk. q<sub>A</sub> = 8 − 2P (0 ≤ P ≤ 4); q<sub>B</sub> = 16 − 2P (0 ≤ P ≤ 8). P is euro per liter, q liter per week. Boven de eigen koopgrens is q nul. Andere omstandigheden blijven gelijk.',
      ['Vul de tabel in en schrijf de gezamenlijke functie voor 0 ≤ P ≤ 4.','Teken in de figuur de gezamenlijke vraag voor 0 ≤ P ≤ 4. Het punt bij P = 0 is al gegeven.'],
      [('P = 0: **8, 16, 24**. P = 2: **4, 12, 16**. P = 4: **0, 8, 8** liter per week. Q = (8 − 2P) + (16 − 2P) = **24 − 4P**, voor 0 ≤ P ≤ 4.','De afzonderlijke uitkomsten blijven in dit interval niet-negatief.'),('Verbind **(24; 0)** met **(8; 4)** en controleer **(16; 2)**. Teken niet buiten de opgegeven grens door.','Een correct lijnstuk toont alleen het deel waarvoor de samengevoegde rekenregel geldig is.')],kind='guided',extra=table(['P','q<sub>A</sub>','q<sub>B</sub>','Q'],[['0','8','16','24'],['2','…','…','…'],['4','…','…','…']])+fig('1.2.3_ex_26','Figuur 21 · De tabel geeft steun. Nu teken je zelf het geldige deel van de somlijn.'),ansfig='1.2.3_ans_26')+
    ex(27,'Zonder grafiek: wie koopt nog?','Voor setjes kaarten gelden q<sub>A</sub> = 6 − P (0 ≤ P ≤ 6) en q<sub>B</sub> = 10 − P (0 ≤ P ≤ 10), in setjes per maand. P is euro per setje. Boven de eigen koopgrens vraagt die koper niets.',
      ['Bereken bij P = € 8 hoeveel beide kopers samen vragen.'],
      [('A: **0**; zijn koopgrens is € 6. B: 10 − 8 = **2 setjes**. Samen **2 setjes per maand**.','De negatieve rekenuitkomst van A is geen aankoop en wordt niet van B afgetrokken.')],kind='guided'))

    at('1.2.3',31)
    page('1.2.3','Zelfstandig optellen en tekenen','## Zelfstandige oefening\n\n'+
    ex(28,'Vraag naar illustratieprints','Twee kopersgroepen vragen illustratieprints. Q<sub>A</sub> = 12 − 3P (0 ≤ P ≤ 4) en Q<sub>B</sub> = 24 − 3P (0 ≤ P ≤ 8). Q is prints per week; P is euro per print. Boven de eigen koopgrens is de vraag van de groep nul. Andere omstandigheden blijven gelijk.',
      ['Bereken de vraag van iedere groep en de gezamenlijke vraag bij € 2.','Stel de gezamenlijke functie op voor 0 ≤ P ≤ 4. Controleer met a.','Teken zelf de gezamenlijke vraag voor 0 ≤ P ≤ 4. Noteer de eindpunten van dit deel.'],
      [('A: 12 − 3 × 2 = **6 prints**; B: 24 − 3 × 2 = **18 prints**; samen **24 prints per week**.','De twee groepen worden bij dezelfde prijs vergeleken.'),('Q = (12 − 3P) + (24 − 3P) = **36 − 6P**, voor 0 ≤ P ≤ 4. Bij € 2: 36 − 6 × 2 = **24**.','Gelijksoortige termen tel je op; de geldigheid volgt uit de beide afzonderlijke regels.'),('Eindpunten **(36; 0)** en **(12; 4)**. Controlepunt: **(24; 2)**. Q horizontaal, P verticaal, met eenheden.','Het interval eindigt bij € 4, niet pas bij het rekenkundige snijpunt van de verlengde somlijn met de P-as.')],ansfig='1.2.3_ans_28')+
    ex(29,'Geen negatieve bijdragen','Twee kopers vragen knutselpakketten. q<sub>A</sub> = 10 − 2P (0 ≤ P ≤ 5); q<sub>B</sub> = 18 − 2P (0 ≤ P ≤ 9). q is pakketten per maand en P is euro per pakket. Boven de eigen koopgrens vraagt een koper nul.',
      ['Bereken de gezamenlijke vraag bij € 6.','Een leerling gebruikt Q = 28 − 4P en komt op 4 pakketten. Leg uit waarom dit geen geldige gezamenlijke vraag is bij die prijs.'],
      [('A: **0**; B: 18 − 2 × 6 = **6**. Samen **6 pakketten per maand**.','A heeft bij € 6 zijn koopgrens overschreden; B nog niet.'),('De gebruikte somfunctie geldt alleen voor **0 ≤ P ≤ 5**. Bij € 6 bevat zij voor A een bijdrage van −2. Die mag niet van B’s 6 pakketten worden afgetrokken.','Negatieve rekenuitkomsten buiten de grens zijn geen negatieve economische vraag.')]))

    at('1.2.3',32)
    page('1.2.3','Doeloefening','## Doeloefening\n\n'+
    ex(30,'Reserveringen bij een spellenclub','Een spellenclub onderzoekt de vraag van twee afzonderlijke groepen. Q<sub>A</sub> = 18 − 3P, geldig voor 0 ≤ P ≤ 6. Q<sub>B</sub> = 24 − 2P, geldig voor 0 ≤ P ≤ 12. Q is reserveringen per week; P is euro per reservering. Boven de eigen koopgrens vraagt de groep nul. De overige omstandigheden blijven gelijk.',
      ['Neem de tabel over en vul alle lege hoeveelheden in.','Stel de gezamenlijke vraagfunctie op voor 0 ≤ P ≤ 6. Controleer de formule met de tabelwaarde bij € 4.','Teken in je schrift de gezamenlijke vraag voor 0 ≤ P ≤ 6. Noteer de eindpunten en markeer het punt bij € 4.','Bereken de gezamenlijke vraag bij P = € 8.','Een leerling trekt de lijn uit c door en vindt bij € 8 een gezamenlijke vraag van 2 reserveringen. Leg uit waarom dit onjuist is.'],
      [('Bij P = 0: A **18**, B **24**, samen **42**. Bij P = 2: **12, 20, 32**. Bij P = 4: **6, 16, 22**. Bij P = 6: **0, 12, 12** reserveringen per week.','Iedere tabelrij hoort bij één gemeenschappelijke prijs.'),('Q = (18 − 3P) + (24 − 2P) = **42 − 5P**, voor **0 ≤ P ≤ 6**. Bij € 4: Q = 42 − 5 × 4 = **22 reserveringen per week**.','De controle verbindt de opgetelde formule met de afzonderlijke brongegevens.'),('Verbind **(42; 0)** en **(12; 6)**. Markeer **(22; 4)**. Zet Q horizontaal (reserveringen per week) en P verticaal (€ per reservering).','Je tekent alleen het interval waarvoor de somfunctie geldt.'),('A: **0**, omdat € 8 boven zijn grens van € 6 ligt. B: 24 − 2 × 8 = **8**. Samen **8 reserveringen per week**.','De overgebleven vraag van B telt volledig mee.'),('De verlengde somfunctie geeft 42 − 5 × 8 = 2, maar bevat dan een negatieve bijdrage van A: 18 − 3 × 8 = −6. De geldige berekening is **0 + 8 = 8**.','De teken- en formulegrens beschermt tegen het aftrekken van niet-bestaande negatieve reserveringen.')],kind='target',extra=table(['P (€ per reservering)','Q<sub>A</sub>','Q<sub>B</sub>','Q samen'],[['0','…','…','…'],['2','…','…','…'],['4','…','…','…'],['6','…','…','…']]),ansfig='1.2.3_ans_30'))

    at('1.2.3',33)
    page('1.2.3','Denkertje en herhaling','## Denkertje / Bonusopgave\n\n'+
    ex(31,'Meer mogelijke kopers, toch hetzelfde totaal','Een aanbieder bereikt tien extra mogelijke kopers. De prijs blijft € 10. Alle bestaande kopers blijven precies dezelfde hoeveelheid vragen.',
      ['Moet de gezamenlijke gevraagde hoeveelheid bij € 10 nu groter zijn? Geef een tegenvoorbeeld en leg uit welke aanvullende voorwaarde een stijging wél garandeert.'],
      [('**Niet noodzakelijk.** De nieuwe mogelijke kopers kunnen allemaal maximaal € 8 willen betalen. Bij € 10 dragen zij dan nul bij en blijft het totaal gelijk. Het totaal stijgt als minstens één extra koper bij € 10 een **positieve hoeveelheid wil en kan kopen**, terwijl de bestaande vraag gelijk blijft.','Een grotere bereikbare groep is niet hetzelfde als extra positieve vraag bij iedere prijs.')],kind='bonus',criteria=['Het tegenvoorbeeld behoudt de prijs en de vraag van bestaande kopers.','De nulbijdrage van de extra mogelijke kopers wordt uitgelegd.','De voorwaarde voor een werkelijk grotere totale vraag is correct.'])+
    '\n\n## Herhaling / Herhaling en interleaving\n\n'+
    ex(32,'Een daling vergelijken','Een aantal aanmeldingen daalt van 10 naar 8 per week.',
      ['Bereken de procentuele verandering.'],
      [('(8 − 10) / 10 × 100% = **−20%**.','De oude hoeveelheid is de basis; een daling behoudt haar negatieve teken. Herhaal zo nodig §1.1.2.')],kind='review')+
    ex(33,'Afstanden op een plattegrond','Een rechthoek ligt op een plattegrond van x = 2 tot x = 8 en van y = 3 tot y = 6. Beide assen geven posities in meters. Een driehoek beslaat de helft van die rechthoek.',
      ['Bereken de oppervlakte van de rechthoek en de driehoek.'],
      [('Basis = 8 − 2 = **6 m**; hoogte = 6 − 3 = **3 m**. Rechthoek = 6 × 3 = **18 m²**. Driehoek = ½ × 6 × 3 = **9 m²**.','De zijden zijn afstanden tussen asposities, niet de grootste afgelezen getallen. Herhaal zo nodig §1.1.3.')],kind='review')+
    box('Let op de bron','Een tabel, formule en grafiek die bij dezelfde bron horen, moeten dezelfde uitkomsten geven. Zie je een verschil? Controleer eerst de prijs, de eenheid en de geldigheid.','box'))
    for lab,expr,res in [('Voorbeeld aggregaat P2','(8-2*2)+(12-2*2)',12),('Voorbeeld uittreden P5','max(0,8-2*5)+max(0,12-2*5)',2),('WE123 P3','(12-3*3)+(8-3)',8),('WE123 P6','max(0,12-3*6)+max(0,8-6)',2),('Doel30 P0','18+24',42),('Doel30 P2','(18-3*2)+(24-2*2)',32),('Doel30 P4','(18-3*4)+(24-2*4)',22),('Doel30 P6','max(0,18-3*6)+(24-2*6)',12),('Doel30 P8','max(0,18-3*8)+(24-2*8)',8),('Ind28 P2','36-6*2',24),('Ind29 P6','max(0,10-2*6)+max(0,18-2*6)',6),('Opgave33 rechthoek','(8-2)*(6-3)',18)]:ck(lab,expr,res)
