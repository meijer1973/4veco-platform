from author_common import *

def make():
    at('1.2.1',2)
    page('1.2.1','Van een wens naar een koopbeslissing',title('1.2.1','Betalingsbereidheid<br>en individuele vraag')+
    goals(['uitleggen welke eenheden iemand bij een gegeven prijs wil kopen;','met een vraagfunctie de hoeveelheid, de prijs en de snijpunten berekenen;','een lineaire vraaglijn tekenen en uitleggen wat zij wel en niet vertelt.'])+
    p('**Koop je er nog één?** Een portie aardbeien kost € 4. Voor haar eerste portie wil Sara maximaal € 10 betalen. Voor volgende porties heeft zij minder over. Is drie porties kopen dan vreemd?')+
    box('Betalingsbereidheid','Het maximale bedrag dat een koper voor een bepaalde eenheid van een product wil betalen. In dit voorbeeld gaat elke balk over **één extra portie**.','definition')+
    fig('1.2.1_fig_1','Figuur 1 · Sara heeft voor de eerste, tweede, derde en vierde portie respectievelijk € 10, € 7, € 4 en € 2 over.')+
    p('Sara koopt de eerste drie porties: telkens is haar betalingsbereidheid minstens € 4. Voor de vierde portie wil zij minder betalen dan de prijs.')+
    box('Afspraak bij gelijkheid','In de voorbeelden met losse eenheden koopt iemand ook als de prijs precies gelijk is aan de betalingsbereidheid. Er is voldoende budget en het product is verkrijgbaar, tenzij de opgave iets anders zegt.','box small'))

    at('1.2.1',3)
    page('1.2.1','Losse eenheden en het voordeel van kopen',p('Dezelfde koopbeslissingen kun je als een trapvorm laten zien. Elke trede hoort bij de betalingsbereidheid voor één extra portie. Bij € 4 passen drie porties bij Sara’s keuze.')+
    fig('1.2.1_fig_2','Figuur 2 · Dit is een hulpmiddel om losse beslissingen te begrijpen. Je hoeft deze trapvorm niet zelfstandig te construeren.')+
    p('Bij € 8 koopt Sara alleen de eerste portie. Bij € 6 koopt zij er twee. **De prijs verandert; haar betalingsbereidheden blijven hier gelijk.**')+
    box('Eerste kennismaking · Consumentensurplus','Sara heeft voor de eerste portie € 10 over, maar betaalt € 4. Haar voordeel bij die aankoop is 10 − 4 = **€ 6**. Bij drie porties zijn de voordelen € 6, € 3 en € 0; samen **€ 9**. Dit heet consumentensurplus. Het is geen bedrag dat zij uitgekeerd krijgt.','box')+
    p('Deze kennismaking helpt je de koopbeslissing te begrijpen. In Boek 2 leer je consumentensurplus verder berekenen en in een markt interpreteren. In de doelopgaven van dit hoofdstuk hoef je geen surplusoppervlakte te bepalen.')+
    box('Niet elk verband is een rechte lijn','Vier afzonderlijke porties geven een trapvorm. Een vloeiende lijn past bijvoorbeeld bij deelbare hoeveelheden of bij een benadering. Een rechte lijn is een extra vereenvoudiging. Veel kopers samen leveren niet vanzelf een precies rechte lijn op.','box'))

    at('1.2.1',4)
    page('1.2.1','Een vraagfunctie met betekenis',p('**Een andere situatie.** Ravi koopt vers sap. We gebruiken voor hem een lineair model. q is de hoeveelheid sap in liter per maand; P is de prijs in euro per liter.')+
    box('Individuele vraag','Het verband tussen de prijs en de hoeveelheid die **één koper** wil en kan kopen, terwijl alle andere omstandigheden gelijk blijven. Die afspraak heet **ceteris paribus**.','definition')+
    box('Vraagfunctie van Ravi','q = 12 − 2P\n\nGeldig voor 0 ≤ P ≤ 6; dus 0 ≤ q ≤ 12.','formula')+
    p('De schrijfwijze 2P betekent 2 × P. Bij P = € 2 geldt: q = 12 − 2 × 2 = **8 liter per maand**. Elke euro prijsstijging verlaagt q in dit model met 2 liter per maand.')+
    table(['P (€ per liter)','0','2','4','6'],[['q (liter per maand)','12','8','4','0']])+
    fig('1.2.1_fig_3','Figuur 3 · Q of q staat horizontaal, P verticaal. Bij dit individuele model schrijven we q. De coördinaten zijn (q; P).')+
    p('Bij q = 0 ligt het snijpunt op de P-as. Bij P = 0 ligt het snijpunt op de q-as. De twee punten zijn genoeg om een rechte lijn vast te leggen.'))

    at('1.2.1',5)
    page('1.2.1','Van hoeveelheid terug naar prijs',p('De formule kan ook dezelfde relatie met **P links** weergeven. Begin bij q = 12 − 2P. Tel aan beide kanten 2P op: q + 2P = 12. Trek q af: 2P = 12 − q. Deel door 2:')+
    box('Dezelfde relatie, anders geschreven','P = 6 − 0,5q\n\nGeldig voor 0 ≤ q ≤ 12.','formula')+
    p('Bij q = 6 liter is P = 6 − 0,5 × 6 = **€ 3 per liter**. Controle: 12 − 2 × 3 = 6 liter. Je hebt geen nieuw gedrag beschreven; je leest hetzelfde verband in de andere richting.')+
    fig('1.2.1_fig_4','Figuur 4 · Bij A geldt q = 8 en P = € 2; bij B q = 4 en P = € 4. De lijn en de tabel beschrijven hetzelfde model.')+
    p('**Snijpunten controleren:** bij P = 0 is q = 12. Bij q = 0 los je op: 0 = 12 − 2P → 2P = 12 → P = 6. Boven € 6 heeft Ravi volgens deze koopgrens geen vraag. Gebruik daar niet een negatieve uitkomst als aankoop.')+
    box('Vraag is nog geen verkoop','De functie zegt hoeveel Ravi bij een prijs wil en kan kopen. Zij vertelt niet welke prijs werkelijk wordt gevraagd, hoeveel verkopers leveren of hoeveel uiteindelijk wordt verkocht. Daarvoor is meer informatie nodig.','warning'))

    at('1.2.1',6)
    page('1.2.1','Uitgewerkt voorbeeld · kiezen en rekenen','## Uitgewerkt voorbeeld\n\n'+
    p('**Bron A — Stickers.** Evi’s betalingsbereidheid voor vier extra stickers is € 9, € 6, € 4 en € 1. Elke sticker kost € 4. Zij heeft genoeg geld; bij gelijkheid koopt zij ook.')+
    p('**a. Welke stickers koopt Evi?** Vergelijk per sticker: 9 ≥ 4, 6 ≥ 4 en 4 = 4. De vierde heeft een waarde lager dan € 4. Evi koopt dus **3 stickers**. De waarde van de eerste sticker is niet de waarde van alle stickers samen.')+
    p('**Bron B — Een afzonderlijk sapmodel.** Voor Bo geldt q = 12 − 2P. q is liter per maand en P is euro per liter; 0 ≤ P ≤ 6. Andere omstandigheden blijven gelijk. Dit model is geen omzetting van Evi’s stickertabel.')+
    p('**b. Hoeveel bij € 2 en bij € 4?**\n\nBij € 2: q = 12 − 2 × 2 = **8 liter per maand**.\nBij € 4: q = 12 − 2 × 4 = **4 liter per maand**.')+
    p('**c. Welke prijs hoort bij 6 liter?**\n\n6 = 12 − 2P\n6 + 2P = 12 — tel aan beide kanten 2P op.\n2P = 6 — trek aan beide kanten 6 af.\nP = **€ 3 per liter** — deel door 2.\nControle: 12 − 2 × 3 = 6 liter.')+
    p('**d. Waar liggen de snijpunten?**\n\nP = 0 geeft q = 12 → **(12; 0)**.\nq = 0 geeft 2P = 12, dus P = 6 → **(0; 6)**.')+
    box('Wat blijft gelijk?','Het inkomen, de voorkeuren en de overige omstandigheden van Bo veranderen niet. Alleen de prijs van sap wordt in deze vergelijking gevarieerd.','box'))

    at('1.2.1',7)
    page('1.2.1','Uitgewerkt voorbeeld · tekenen en interpreteren',p('**e. Teken de vraaglijn.** Kies q van 0 tot 12 horizontaal en P van 0 tot 6 verticaal. Zet de snijpunten neer en verbind ze. Controleer met A = (8; 2), B = (4; 4) en C = (6; 3).')+
    fig('1.2.1_we_1','Figuur 5 · De prijs bij 6 liter lees je op dezelfde lijn af als de hoeveelheid bij € 3.')+
    p('**f. Wat betekent de prijsstijging van € 2 naar € 4?** Bo’s gevraagde hoeveelheid daalt van 8 naar 4 liter per maand. Bij een hogere prijs kiest hij minder sap, onder de genoemde gelijkblijvende omstandigheden. Dit is een voorspelling over zijn vraag, niet zelfstandig bewijs van de feitelijke verkoop.')+
    box('Samenvatting · 1.2.1','Vergelijk betalingsbereidheid met de prijs. Gebruik een vraagfunctie alleen binnen de genoemde grenzen en houd andere omstandigheden gelijk. Reken terug door aan beide kanten hetzelfde te doen. Teken q horizontaal en P verticaal; controleer je snijpunten. In de volgende paragraaf veranderen ook andere vraagfactoren.','box summary')+
    p('**Bij je eigen antwoord:** schrijf steeds wie de koper is, om welk product het gaat en op welke periode de hoeveelheid betrekking heeft. “8” alleen is nog geen volledig antwoord.'))

    at('1.2.1',8)
    page('1.2.1','Starten en de grafiek lezen','## Startopgaven\n\n'+
    ex(1,'Een bekende rekenregel','Voor materiaalhuur geldt T = 5 + 2n. T is het bedrag in euro; n is een heel aantal materialen van 0 tot en met 20.',
      ['Bereken T als n = 4.','Bereken n als T = € 17 en controleer je antwoord.'],
      [('T = 5 + 2 × 4 = **€ 13**.','Je vermenigvuldigt het bedrag per materiaal eerst met het aantal.'),('17 = 5 + 2n → 12 = 2n → n = **6 materialen**. Controle: 5 + 2 × 6 = € 17.','Aan beide kanten 5 aftrekken en vervolgens door 2 delen houdt de vergelijking gelijk.')],kind='start')+
    ex(2,'Een aankoop en een punt','Omar wil voor een eerste poster maximaal € 8 betalen. De prijs is € 6. Hij heeft genoeg geld. In een andere vraaggrafiek staat q horizontaal en P verticaal.',
      ['Koopt Omar de poster volgens de koopregel? Licht toe.','Welk punt hoort bij 4 producten en € 3 per product?'],
      [('**Ja**, want zijn betalingsbereidheid van € 8 is hoger dan de prijs van € 6.','Het gaat om de waarde van die ene poster voor Omar.'),('**(4; 3)**.','Eerst de horizontale hoeveelheid, daarna de verticale prijs.')],kind='start')+
    box('Oefenroute',ROUTE,'route')+
    '\n\n## Begeleide inoefening\n\n'+p(SKIP,'note')+
    p('De volgende opgaven bouwen de hulp af: eerst lezen, dan afmaken, daarna zelf rekenen.'))

    at('1.2.1',9)
    page('1.2.1','Begeleide inoefening · herkennen en afmaken',ex(3,'De ingevulde hulplijnen','Lina’s vraag naar tijdschriften is q = 12 − 2P, met q per maand en P in euro per tijdschrift. Het model geldt voor 0 ≤ P ≤ 6; de overige omstandigheden blijven gelijk.',
      ['Lees q bij P = € 2 af. Noem de eenheid.','Lees P bij q = 4 af en controleer met de formule.','Kun je uit de vraaglijn alleen vaststellen dat er ook echt vier tijdschriften worden verkocht? Leg uit.'],
      [('Bij € 2 is q = **8 tijdschriften per maand**.','De horizontale hulplijn vertrekt bij de prijs; de verticale hulplijn geeft het bijbehorende aantal.'),('P = **€ 4 per tijdschrift**. Controle: q = 12 − 2 × 4 = 4 tijdschriften per maand.','P en q zijn twee coördinaten van hetzelfde punt op de lijn.'),('**Nee.** De lijn beschrijft Lina’s gevraagde hoeveelheid bij mogelijke prijzen; feitelijke beschikbaarheid en verkoop staan niet vast.','Vraag is een koopplan onder voorwaarden, niet op zichzelf een waargenomen transactie.')],kind='guided',extra=fig('1.2.1_ex_3','Figuur 6 · De antwoorden zijn grafisch zichtbaar; controleer dat je de hulplijnen goed leest.')))

    at('1.2.1',10)
    page('1.2.1','Begeleide inoefening · minder hulp',ex(4,'Maak de vraaglijn af','Voor Mats geldt q = 8 − P. q is het aantal bezoeken aan een expositieruimte per maand; P is euro per bezoek. Gebruik 0 ≤ P ≤ 8. Andere omstandigheden blijven gelijk.',
      ['Vul de twee ontbrekende hoeveelheden in de tabel in.','Teken de rechte vraaglijn door de gegeven snijpunten. Markeer de punten bij P = € 2 en P = € 5.','Welke prijs hoort bij q = 3?'],
      [('Bij P = 2: q = 8 − 2 = **6 bezoeken**. Bij P = 5: q = 8 − 5 = **3 bezoeken** per maand.','Je vult de prijs in dezelfde rekenregel in.'),('De lijn loopt door **(0; 8)** en **(8; 0)**. De punten zijn **(6; 2)** en **(3; 5)**.','Alle getekende punten voldoen aan q = 8 − P.'),('3 = 8 − P → P = **€ 5 per bezoek**. Controle: 8 − 5 = 3.','De prijs hoort bij de gekozen hoeveelheid op dezelfde lijn.')],kind='guided',extra=table(['P (€ per bezoek)','0','2','5','8'],[['q (bezoeken per maand)','8','…','…','0']])+fig('1.2.1_ex_4','Figuur 7 · De twee snijpunten staan er al. De lijn en de twee andere punten teken je zelf.'),ansfig='1.2.1_ans_4')+
    ex(5,'Zonder tekening','Voor Lila’s pakjes kaarten geldt q = 15 − 3P, voor 0 ≤ P ≤ 5. q is pakjes per maand en P is euro per pakje. Een ander pakje heeft voor haar een gegeven betalingsbereidheid van € 4.',
      ['Bereken de prijs waarbij zij volgens de functie 6 pakjes vraagt.','Dat andere pakje kost € 4. Koopt ze het volgens onze afspraak bij gelijkheid?'],
      [('6 = 15 − 3P → 6 + 3P = 15 → 3P = 9 → P = **€ 3 per pakje**. Controle: 15 − 3 × 3 = 6.','Je rekent terug naar de prijs en controleert daarna de oorspronkelijke functie.'),('**Ja.** Bij gelijkheid veronderstellen we dat zij koopt, als er geen extra beperking is.','De afspraak maakt een anders onbesliste koopkeuze eenduidig.')],kind='guided'))

    at('1.2.1',11)
    page('1.2.1','Zelfstandig de methode toepassen','## Zelfstandige oefening\n\n'+
    ex(6,'Sap voor Joris','Joris’ vraag naar appelsap wordt benaderd door q = 18 − 3P, met q in liter per week en P in euro per liter. Gebruik 0 ≤ P ≤ 6 en houd de overige omstandigheden gelijk.',
      ['Bereken q bij P = € 2 en bij P = € 4.','Bereken de prijs die hoort bij q = 9. Controleer je antwoord.','Bepaal beide snijpunten en teken zelf de vraaglijn. Markeer de punten uit a.','Leg uit waarom de functie niet betekent dat Joris zeker 18 liter gaat kopen.'],
      [('Bij € 2: 18 − 3 × 2 = **12 liter per week**. Bij € 4: 18 − 3 × 4 = **6 liter per week**.','Bij de hogere prijs is volgens het model minder sap aantrekkelijk.'),('9 = 18 − 3P → 3P = 9 → P = **€ 3 per liter**. Controle: 18 − 3 × 3 = 9 liter.','Terugrekenen en invullen beschrijven dezelfde combinatie.'),('Snijpunten **(18; 0)** en **(0; 6)**; getekende punten **(12; 2)** en **(6; 4)**.','Op de q-as is P nul; op de P-as is q nul.'),('18 liter is de gevraagde hoeveelheid **bij P = 0** in dit model. De werkelijke prijs en verkoop zijn niet gegeven.','Het getal is een voorwaardelijke modeluitkomst, geen gegarandeerde aankoop.')],ansfig='1.2.1_ans_6')+
    ex(7,'Een bezoek meer of minder','Noor wil voor haar eerste vier museumbezoeken per maand maximaal € 18, € 12, € 8 en € 4 per bezoek betalen. Zij heeft voldoende budget en toegang. Bij gelijkheid koopt ze ook.',
      ['Hoeveel bezoeken wil Noor kopen bij € 9 per bezoek? Licht toe.','Hoeveel wil zij kopen bij € 12 en bij € 6?','Is in b haar betalingsbereidheid veranderd? Leg uit.'],
      [('**2 bezoeken per maand**: € 18 en € 12 zijn minstens € 9; € 8 niet.','Vergelijk de waarde van ieder extra bezoek met de prijs.'),('Bij € 12: **2 bezoeken**; bij € 6: **3 bezoeken per maand**.','Het tweede bezoek wordt bij gelijkheid gekocht; bij € 6 past ook het derde bezoek.'),('**Nee.** De bron houdt de betalingsbereidheden gelijk en verandert alleen de prijs.','Een andere koophoeveelheid hoeft geen andere voorkeur te betekenen.')]))

    # Target may move to next page during final layout plan; record actual starting page explicitly.
    at('1.2.1',12)
    page('1.2.1','Doeloefening','## Doeloefening\n\n'+
    ex(8,'Fotoprints en een sapmodel','**Bron A.** Iris wil voor vier extra fotoprints maximaal € 12, € 9, € 5 en € 2 betalen. Elke print kost € 5. Zij heeft voldoende budget; bij gelijkheid koopt zij ook.\n\n**Bron B — een andere situatie.** Voor Amir geldt q = 20 − 4P. q is sap in liter per maand, P euro per liter. De functie geldt voor 0 ≤ P ≤ 5. Alle overige omstandigheden blijven gelijk.',
      ['Hoeveel fotoprints koopt Iris volgens bron A? Leg uit.','Bereken met bron B de gevraagde hoeveelheid bij P = € 2 en bij P = € 3.','Bereken de prijs die hoort bij q = 6 liter per maand. Controleer je antwoord.','Bereken beide snijpunten van de vraaglijn uit bron B.','Teken die vraaglijn in je schrift en markeer de twee punten uit b. Vermeld variabelen, eenheden en een bruikbare schaal.','Leg uit wat de prijsstijging van € 2 naar € 3 voor Amirs vraag betekent. Kun je daarmee ook zijn feitelijke aankoop vaststellen?'],
      [('**3 fotoprints**. De waarden € 12, € 9 en € 5 zijn minstens de prijs van € 5; de vierde waarde van € 2 is lager.','De gelijkheidsafspraak bepaalt dat Iris ook de derde print koopt.'),('Bij € 2: q = 20 − 4 × 2 = **12 liter per maand**. Bij € 3: q = 20 − 4 × 3 = **8 liter per maand**.','Je verandert alleen de eigen prijs in één en dezelfde vraagfunctie.'),('6 = 20 − 4P → 6 + 4P = 20 → 4P = 14 → P = **€ 3,50 per liter**. Controle: 20 − 4 × 3,50 = 6 liter.','De uitkomst blijft binnen de geldige prijsgrenzen.'),('P = 0 → q = 20: **(20; 0)**. q = 0 → 4P = 20 → P = 5: **(0; 5)**.','Een snijpunt met een as heeft nul als de andere coördinaat.'),('Teken q horizontaal (liter per maand), P verticaal (€ per liter). Verbind **(20; 0)** met **(0; 5)**; markeer **(12; 2)** en **(8; 3)**.','Een controlepunt uit de functie moet exact op de getekende lijn liggen.'),('De gevraagde hoeveelheid daalt **met 4 liter, van 12 naar 8 liter per maand**, ceteris paribus. De feitelijke aankoop is niet bepaald: beschikbaarheid en de werkelijk geldende prijs ontbreken.','Een vraagrelatie beschrijft het gedrag bij veronderstelde prijzen; zij bevat geen aanbodinformatie.')],kind='target',ansfig='1.2.1_ans_8'))

    at('1.2.1',13)
    page('1.2.1','Denkertje en herhaling','## Denkertje / Bonusopgave\n\n'+
    ex(9,'Hetzelfde aantal, dezelfde vraag?','Twee leerlingen kopen ieder twee drankjes bij een prijs van € 3. Een onderzoeker zegt: “Hun individuele vraag is dus precies hetzelfde.”',
      ['Beoordeel de uitspraak. Geef twee verschillende rijtjes betalingsbereidheden die bij € 3 tot twee aankopen leiden, maar bij een andere prijs tot verschillende aantallen.'],
      [('Bijvoorbeeld leerling A: **€ 6, € 4, € 2**; leerling B: **€ 5, € 3, € 1**. Bij € 3 kopen beiden twee drankjes. Bij € 4 koopt A twee en B één. De uitspraak is dus onjuist.','Eén overeenkomstig punt bewijst niet dat de hele vraagrelatie gelijk is.')],kind='bonus',criteria=['Beide rijtjes geven precies twee aankopen bij € 3, met dezelfde gelijkheidsafspraak.','Een andere prijs laat een verschil zien.','De conclusie onderscheidt één waarneming van een volledig verband.'])+
    '\n\n## Herhaling / Herhaling en interleaving\n\n'+
    ex(10,'Verhoudingen blijven nodig','Een groep koopt 6 identieke folders voor in totaal € 18. Een week later stijgt de prijs per folder van € 3 naar € 3,60.',
      ['Bereken het bedrag per folder bij de eerste aankoop.','Bereken de procentuele prijsverandering.'],
      [('€ 18 / 6 = **€ 3 per folder**.','Je deelt het totaal door het aantal identieke eenheden.'),('(3,60 − 3) / 3 × 100% = **20% stijging**.','De oude prijs van € 3 is de vergelijkingsbasis. Herhaal zo nodig §1.1.2.')],kind='review')+
    ex(11,'Een zaterdagmiddag','Bram heeft drie uur beschikbaar. Hij kan óf helpen bij een verhuizing voor € 36 in totaal, óf flyers bezorgen voor € 27 in totaal. Beide opties duren drie uur. Hij kiest de verhuizing; zijn doel is de hoogste geldelijke opbrengst.',
      ['Wat zijn de geldelijk uitgedrukte alternatieve kosten van zijn keuze? Leg uit waarom het antwoord niet € 9 is.'],
      [('**€ 27**, de opbrengst van het beste alternatief dat hij opgeeft. € 9 is alleen het verschil tussen de twee opbrengsten.','Alternatieve kosten meten wat de beschikbare tijd elders zou opleveren. Herhaal zo nodig §1.1.1.')],kind='review')+
    box('Klaar voor de volgende stap','Tot nu toe varieerde je de eigen prijs terwijl de overige omstandigheden gelijk bleven. Hierna onderzoek je wat er verandert als ook inkomen, voorkeuren of andere prijzen veranderen.','box'))
    for lab,expr,res in [('Ravi q bij2','12-2*2',8),('Ravi inverse bij6','(12-6)/2',3),('Sara preview','(10-4)+(7-4)',9),('Doel8 q2','20-4*2',12),('Doel8 q3','20-4*3',8),('Doel8 inverse','(20-6)/4',3.5),('Doel8 cutoff','20/4',5),('Opgave6 q2','18-3*2',12),('Opgave6 q4','18-3*4',6),('Opgave5 inverse','(15-6)/3',3),('Opgave10 percentage','(3.6-3)/3*100',20)]:ck(lab,expr,res)
