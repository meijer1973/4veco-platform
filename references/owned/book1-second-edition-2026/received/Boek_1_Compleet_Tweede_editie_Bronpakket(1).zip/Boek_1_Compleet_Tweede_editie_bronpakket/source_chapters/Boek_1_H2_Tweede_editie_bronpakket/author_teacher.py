from author_common import *
TP=[]
def add(t,b):TP.append({'section':'Docenteninformatie','title':t,'body':b})

add('Doel, gebruik en editie','<p class="kicker">DOCENTENINFORMATIE · BOEK 1 · TWEEDE EDITIE</p><h1>Hoofdstuk 1.2 · Vraag</h1>'+p('Deze editie bouwt voort op het nieuwe hoofdstuk 1.1 uit dezelfde reeks. De inhoud volgt de door de gebruiker gekozen **Book 1 second-edition outline v1**. De leerlingtekst is nieuw geschreven; de gedrukte eerste editie en het live doelopgavenregister zijn niet gewijzigd.')+
table(['Onderdeel','Omvang / vindplaats'],[['Leerlinghoofdstuk','40 pagina’s; uitleg en alle oefeningen inbegrepen.'],['Antwoordboek','22 pagina’s; 38 opgaven met 90 deelvragen.'],['Paragrafen','1.2.1 p. 2–13; 1.2.2 p. 14–23; 1.2.3 p. 24–33; 1.2.4 p. 34–38.'],['Overzicht en begrippen','p. 39–40.'],['Doeloefeningen','8 (p. 12), 19 (p. 22), 30 (p. 32) en 37 (bronnen p. 36, vragen p. 37).'],['Visuele laag','22 instructiefiguren en 11 antwoordfiguren; vectoren in de PDF.']])+
box('Onderwijsdoel','Leerlingen verbinden de betekenis van vraag met tabel-, functie- en grafiekwerk. Het nieuwe economische inzicht wordt niet verstopt in herhaling van rekenen. Dezelfde procedure keert terug in verschillende contexten.','box')+
p('Elke theorieparagraaf heeft de volgorde **Uitgewerkt voorbeeld → Startopgaven → Begeleide inoefening → Zelfstandige oefening → Doeloefening → Denkertje / Bonusopgave → Herhaling / Herhaling en interleaving**. De compacte samenvatting staat na het uitgewerkte voorbeeld. De docent mag het voorkennisdeel van Startopgaven aan het begin van de les inzetten zonder de gedrukte volgorde te veranderen.')+
p('De uitwerking is volledig op papier bruikbaar. Begeleide inoefening is een optionele route met hetzelfde doel. Denkertjes en het grootste deel van de slotherhaling vallen buiten de kernles. Bij de zeven lesplannen op p. 6–7 staat een concrete selectie; maak niet alle gedrukte opgaven verplicht in één les.')+
box('Wat dit hoofdstuk niet doet','Geen aanbod- of evenwichtsberekeningen; geen elasticiteitsformules; geen zelfstandig te berekenen CS-driehoek; geen formele stukgewijze vraagfunctie of volledige analyse van knikken. De eerste kennismaking met consumentensurplus en de trapillustratie blijven begrensde uitleg.','box')+
p('Aantallen lessen en minuten zijn ontwerpschattingen. Er zijn geen leerlingmetingen uitgevoerd en er wordt geen beheersing door een klas geclaimd.','note'))

add('1.2.1 · doelen en voorbereiding','<h1>1.2.1 · Betalingsbereidheid</h1>'+p('De paragraaf heeft twee samenhangende stappen: afzonderlijke koopbeslissingen en een lineaire vraagfunctie. De grafiekvaardigheid is eerder onderwezen; betalingsbereidheid en de economische lezing van de functie zijn nieuw.')+
table(['Doel / handeling','Doelopgave 8','Uitleg / voorbeeld','Oefenbewijs'],[
['Per extra eenheid vergelijken; regel bij gelijkheid','a','p. 2–3; voorbeeld bron A op p. 6','Start 2a; begeleid 5b; zelfstandig 7.'],
['Hoeveelheid bij prijs berekenen','b','p. 4; voorbeeld 6b','Begeleid 3; zelfstandig 6a.'],
['Van hoeveelheid naar prijs terugrekenen en controleren','c','p. 5; voorbeeld 6c','Start 1b; begeleid 4c, 5a; zelfstandig 6b.'],
['Snijpunten bepalen','d','p. 4–5; voorbeeld 6d','Begeleid 4; zelfstandig 6c.'],
['Zelf een lineaire vraaggrafiek tekenen','e','p. 4–5 en 7','3 leest; 4 maakt af; 5 is tekst; 6c tekent zelfstandig.'],
['Vraagreactie en grenzen van de conclusie','f','p. 5; voorbeeld 7f','3c en 6d; 7c houdt betalingsbereidheid gelijk.']])+
box('De expliciete brug met 1.1','Herhaal invullen en terugrekenen kort met opgave 1. Verbind het daarna met q en P. Laat de leerling niet alleen “naar de andere kant” zeggen: de voorbeeldberekening toont dezelfde bewerking aan beide kanten. Verander de procedure niet in het antwoordmodel.','box')+
p('**Gelijkheid.** Bij losse eenheden geldt expliciet: prijs gelijk aan betalingsbereidheid → de koper koopt, bij voldoende budget en beschikbaarheid. Het lineaire model is een aparte context. Het wordt niet gepresenteerd als een exact vloeiend equivalent van dezelfde vier discrete gegevens.')+
p('**Voorbeeld vóór productie.** Opgave 3 geeft een volledig ingevulde vraaggrafiek; opgave 4 geeft twee snijpunten en assen. Opgave 5 gebruikt alleen tekst. Bij 6 en 8 krijgt de leerling geen voorgedrukte antwoordgrafiek.')+
p('**Preview.** Figuur 2 is een didactische trap, geen apart einddoel. De € 9 voordeel in het Sara-voorbeeld is een eerste kennismaking, niet een formele surplusroutine. Boek 2 blijft verantwoordelijk voor die economische en grafische verdieping.')+
p('De doelopgave vervangt voor deze nieuwe editie het oude onafhankelijke vereiste van trapfunctieconstructie door een lineaire vraaglijn. Dit is een zichtbare editie-keuze uit de outline, geen uitspraak dat het live register al is aangepast.','note'))

add('1.2.2 · twee oorzaken onderscheiden','<h1>1.2.2 · Vraagfactoren</h1>'+p('Het kernonderscheid is oorzaakgestuurd. Laat leerlingen telkens eerst het onderzochte product en de periode noemen. De prijs van een ander product is niet dezelfde grootheid als de eigen prijs.')+
table(['Doel / handeling','Doelopgave 19','Uitleg / voorbeeld','Oefenbewijs'],[
['Eigen prijs → beweging; Q berekenen','a','p. 14; voorbeeld 17a','12–13; 15a; 18a.'],
['Specifieke vraagfactor en richting','b','p. 15–16; voorbeeld 17b','14–17; inclusief complement en brongegeven inkomensgedrag.'],
['Nieuwe lijn en punten toevoegen','c','figuren 8–9; voorbeeld figuur 12','15 met beginlijn; 18 met uitsluitend beginlijn.'],
['Afzonderlijke effecten combineren','d','voorbeeld 17c','16 tegenovergestelde effecten zonder groottes; 18 versterkende effecten met getallen.'],
['Plausibele fout weerleggen','e','voorbeeld 17d','16d en de bronclassificatie in 17.']])+
p('**Zelfde schalen.** Figuren 8 en 9 gebruiken dezelfde schaal en dezelfde oorspronkelijke ijscoupefunctie. Het ene effect verplaatst het punt op V₀, het andere voegt V₁ toe. Geen van de punten wordt evenwicht genoemd: er is nog geen aanbodmodel.')+
p('**B als denkstap.** Bij twee gelijktijdige veranderingen is punt B de tegenfeitelijke tussenstap “alleen de eigen prijs”. De bron zegt niet dat die tussensituatie werkelijk is waargenomen. Daarna wordt de veranderde vraagfunctie bij de nieuwe prijs gebruikt.')+
box('Twee typen samengestelde verandering','Opgave 16 geeft geen effectgroottes: de richting van het netto-effect kan onbekend blijven. Opgaven 18 en 19 leveren wél genoeg cijfers om te rekenen. Leerlingen mogen niet leren dat “twee veranderingen” altijd onbeslisbaar is, of dat alleen de pijlen altijd volstaan.','box')+
p('**Inkomen.** De bron geeft het productgedrag. Er wordt geen automatische richting voor alle producten geleerd en geen Ei-classificatie gevraagd. **Verwachtingen** staan slechts in één duidelijk huidig-versus-toekomstig voorbeeld; de kernopgaven bouwen er geen extra model omheen.')+
p('De volledig gemarkeerde figuur bij 14 wordt opgevolgd door een beginlijn bij 15, tekst bij 16 en een beginlijn zonder hints bij 18–19. Omdat de doeltaak het aanvullen van een gegeven grafiek vraagt, blijft die beginrepresentatie beschikbaar.','note'))

add('1.2.3 · som, interval en nulbijdrage','<h1>1.2.3 · Collectieve vraag</h1>'+p('De extra algebra is beperkt: aantallen optellen en gelijksoortige termen verzamelen. Het economische uitgangspunt — dezelfde prijs, periode, eenheid en geen dubbeltelling — staat vóór de somfunctie.')+
table(['Doel / handeling','Doelopgave 30','Uitleg / voorbeeld','Oefenbewijs'],[
['Tabel aanvullen bij gelijke prijzen','a','p. 24; voorbeeld 27a','24–26; 28a.'],
['Twee functies optellen en geldigheid noemen','b','p. 25; voorbeeld 27b','26a; 28b.'],
['Gecombineerde lijn binnen interval tekenen','c','figuur 17; voorbeeld 27c en figuur 19','25 leest; 26 maakt af; 28c tekent zelfstandig.'],
['Bij hoge prijs alleen niet-negatieve vraag tellen','d','p. 26; voorbeeld 27d','27; 29a.'],
['Ongeldige extrapolatie uitleggen','e','figuur 18; voorbeeld 27e','29b; bonus 31 toetst een andere kant van de nulbijdrage.']])+
box('Niet alsnog een hoofdstuk stukgewijze functies','De leerling leert één bruikbare somfunctie met een ernaast vermeld prijsinterval. Buiten dat interval rekent hij opnieuw per koper. De grafische verandering van vorm wordt getoond, maar er is geen verplichte formele knikterminologie, bewijs van intervallen of samengestelde formule met accolades.','box')+
p('**De lijn hoeft geen prijsas te raken.** Opgaven 28 en 30 vragen een lijnstuk tot een gegeven maximale prijs. Blind doorverbinden naar de rekenkundige P-asafsnede van een te ver doorgetrokken somfunctie is juist een fout. De voorbeelden behandelen dit vóór het zelfstandig tekenen.')+
p('**Geen negatieve vraag.** Bij € 8 in de doelopgave draagt A nul bij. B vraagt nog 8 reserveringen. De ruwe som 42 − 5 × 8 = 2 telt −6 voor A mee en is dus ongeldig.')+
p('**Eenduidige bronnen.** Tabellen, grafieken en functies zijn nieuw en onderling afgestemd. Het eerder gesignaleerde Anna/Ben-probleem uit het oude register wordt niet overgenomen. De oorspronkelijke registeropgave is hier niet stilzwijgend als gerepareerde bron hergebruikt.')+
p('De drie panelen van figuur 17 hebben identieke prijs- en hoeveelheidsschalen. De gezamenlijke lijn in die figuur is beperkt tot de gemeenschappelijke geldigheid van beide lineaire regels. Figuur 18 toont vervolgens de nulbijdrage afzonderlijk.','note'))

add('Consolidatie en aansluiting op Boek 2','<h1>1.2.4 · Selecteren en combineren</h1>'+p('De gemengde paragraaf introduceert geen nieuwe theorie. Opgaven 34–36 halen koopbeslissingen, percentages, optellen, terugrekenen, tekenen en het individuele/collectieve onderscheid terug. Doeloefening 37 vraagt een bronkeuze en een samenhangende conclusie.')+
table(['Doelopgave 37','Wat de leerling combineert'],[['a–b','Twee groepsfuncties samenvoegen, hoeveelheid bij prijs en prijs bij hoeveelheid; geldigheid.'],['c–d','De eigen prijs en de prijs van een substituut onderscheiden; nieuw lijnstuk en drie punten aangeven.'],['e','Twee even grote tegengestelde effecten herkennen: het totaal blijft gelijk, de effecten zijn niet nul.'],['f','Een individuele koopbeslissing bij gelijkheid; geen dubbeltelling van een koper die al in groep A zit.']])+
p('Bron A beschrijft de oorspronkelijke groepsvraag. Bron B geeft de veranderde omstandigheden en hun grootte. Bron C illustreert een koper die al is meegeteld. De bron geeft geen aanbod; “gevraagd” mag niet ongemerkt worden vervangen door “verkocht”.')+
table(['Latere paragraaf','Wat dit hoofdstuk aanlevert','Wat daar nieuw blijft'],[
['2.2.1 Prijselasticiteit','Eigen-prijsreactie; signed percentageherhaling in 10, 12, 23, 32 en 34.','De elasticiteitsratio, classificatie en interpretatie.'],
['2.2.3 Inkomens- en kruislingse elasticiteit','Inkomen en de benoemde relatie tot een ander goed.','Ei, Ek en hun classificaties; functies met meerdere variabelen.'],
['2.3.1 Consumentensurplus','Betalingsbereidheid, vraaglijn, snijpunten en prijs aflezen.','Formele economische oppervlakte en surplusberekening.'],
['1.3 en later marktwerk','Bronnen, eenheden, geldige functies, lijnverschuivingen.','Aanbod, evenwicht en de samenhang tussen kopers en verkopers.']])+
box('Herhaling is geen nieuw einddoel','Opgave 33 gebruikt de oppervlakte van een plattegrond uit §1.1.3. Zij introduceert geen vraag-surplusdriehoek. Opgave 11 haalt alternatieve kosten op zonder winsttheorie.','box')+
p('Bronselectie wordt in het antwoordmodel zichtbaar gemaakt. Een correct getal zonder juiste periode, vergelijking of economische oorzaak telt niet als een volledige verklaring.'))

add('Kernlessen 1–4 · concrete tijdsbegroting','<h1>Lesplanning · eerste vier lessen</h1>'+p('Onderstaande route spreidt de drie theorieparagrafen over zes lessen en eindigt met één consolidatieles. Elk blok omvat **55 minuten inclusief uitleg en feedback**. Dit zijn schattingen, geen gemeten lestijden. Een doeloefening mag over de twee bijbehorende lessen worden verdeeld.')+
table(['Les','Concrete selectie en volgorde','Minuten'],[
['1 · 1.2.1 koopkeuze en q bij P','Opening 2; start 1a en 2a 4; uitleg p. 2–4 10; voorbeeld 6a–b 6; zelfstandig 7 10 en 6a 6; doel 8a–b 10; afronding 5; overgangen 2.','55'],
['2 · 1.2.1 terugrekenen en tekenen','Start 1b en 2b 5; uitleg p. 5 10; voorbeeld 6c–d en 7e–f 10; zelfstandig 6b–d 12; doel 8c–f 14; feedback 4.','55'],
['3 · 1.2.2 afzonderlijke factoren','Start 12 5; uitleg p. 14–16 14; voorbeeld 17a–b 7; zelfstandig 17 8 en 18a 7; doel 19a–b 10; afronding 4.','55'],
['4 · 1.2.2 twee veranderingen','Start 13 3; gerichte uitleg over afzonderlijk/samen 8; voorbeeld 17c–d met terugkoppeling naar de figuur 8; zelfstandig 18b–c 14; doel 19c–e 15; feedback en afsluiting 7.','55']])+
box('Begeleide inoefening blijft optioneel','Bij terugrekenen of tekenen vastgelopen? Gebruik opgaven 3–5 voordat de leerling de overeenkomstige zelfstandige handeling uitvoert. Bij vraagfactoren kan 14–16 de steunroute vormen. Deze route is **geen extra verplicht pakket boven op de 55 minuten**. Gebruik extra lestijd of verplaats aanvullende oefening, zonder het doel of de zelfstandige eindhandeling te schrappen.','box')+
p('In les 1 is de hulp rond betalingsbereidheid meestal een uitleg in gewone taal. In les 2 is die vaak procedureel: wat is gegeven, welke grootheid zoek je en welke bewerking behoudt de gelijkheid? Reageer op het soort fout, niet alleen op het verkeerde getal.')+
p('Het uitgewerkte voorbeeld blijft in het boek vóór de startopgaven staan. De docent kan de eerder aangeleerde rekenhandeling uit Startopgaven vooraf ophalen. Dat verandert niet het onafhankelijke karakter van de doeltaak.','note'))

add('Kernlessen 5–7 en gerichte ondersteuning','<h1>Lesplanning · afronden en behouden</h1>'+table(['Les','Concrete selectie en volgorde','Minuten'],[
['5 · 1.2.3 optellen','Start 23a en 24 5; uitleg p. 24–25 12; voorbeeld 27a–c en figuur 19 9; zelfstandig 28a–b 8; doel 30a–b 10; verwoorden van de gemeenschappelijke prijs 4; feedback 7.','55'],
['6 · 1.2.3 grens en grafiek','Start 23b 3; uitleg p. 26 8; voorbeeld 27c–e en figuur 19 10; zelfstandig 28c en 29 13; doel 30c–e 15; feedback 6.','55'],
['7 · gemengde opgaven','Gereedschappen actief ophalen 5; keuze uit 34–35 8; 36 12; doel 37 23; feedback op bronnen en redenering 7.','55']])+
p('Kies naargelang de groep extra ruimte voor herhaling of begeleiding: **7–9 lessen** is een bruikbare eerste planningsmarge. Leerlingen hoeven de optionele blokken niet allemaal af te ronden om aan de doeloefening te beginnen. Bij onvoldoende voorbereiding is aanvullende begeleiding zinvoller dan het doel verlagen.')+
table(['Waargenomen fout','Gerichte reactie'],[
['q en P omgewisseld in een punt','Laat de leerling eerst de twee aslabels aanwijzen; keer terug naar 3 of 4.'],
['Alleen eindgetal bij terugrekenen','Laat invullen, bewerking aan beide kanten en controle apart zien; 5a.'],
['Elke stijging heet verschuiving','Vergelijk figuren 8 en 9; laat eerst de veranderde factor benoemen.'],
['Prijs ander goed heet eigen prijs','Laat beide productnamen onderstrepen; gebruik 16d.'],
['Elke inkomensstijging geeft meer vraag','Laat het specifieke brongegeven in 17 aanwijzen; geen automatische categorie aannemen.'],
['Negatieve vraag van A van B aftrekken','Laat per koper de prijsgrens controleren; 27 en 29.'],
['Somlijn altijd tot P-as tekenen','Vraag waar de bron stopt: vergelijk figuur 19 en doel 30.'],
['Extra koper dubbel optellen','Laat vaststellen in welke bron/groep de koper al zit; 37f.']])+
p('Bonus 9 vraagt een tegenvoorbeeld, 20 een alternatieve verklaring en onderzoeksvergelijking, 31 een noodzakelijke voorwaarde en 38 herstel van bronredeneringen. Zij zijn niet bedoeld als meer van dezelfde rekenroutine. Slotopgaven 10–11, 21–22 en 32–33 ondersteunen gespreide herhaling.','note'))

add('Bronnen, kwaliteitscontrole en afdrukken','<h1>Bronnen en controle</h1>'+p('**S1 · Hoofdrichting.** `book-1-outline-second-edition-v1.md`, lokale versie uit deze conversatie, planning 8 september 2026. De vier rolbeschrijvingen, grenzen en doelbrieven bepalen deze uitwerking. De volledige outline zit in het bronpakket.')+
p('**S2 · Aantoonbare eerdere uitleg.** Het bronpakket en de PDF van Boek 1, hoofdstuk 1, tweede editie: verhoudingen/procenten, eenheden, tabel- en grafiekwerk, invullen en terugrekenen. Relevante Markdown-bronnen zijn ter referentie opgenomen; de eerdere bestanden zijn niet gewijzigd.')+
p('**S3 · Live repository-richtlijnen.** Op 8 september 2026 gelezen via de GitHub-connector: beide `RESEARCH_AGENT_MAP.md`-bestanden; `skills/econ-exercise-builder.md`; `skills/econ-textbook-paragraph.md`; `skills/econ-didactiek.md`; `skills/economic-graph.md`. De opgehaalde blob-identiteiten staan in `sources/source-register.json`. De richtlijnen zijn toegepast op de expliciet gevraagde nieuwe editie; de eerste editie blijft bevroren.')+
box('Nieuw geschreven, niet geleend als feit','De doelopgaven 8, 19, 30 en 37 en alle rekengevallen zijn door de auteur geconstrueerd binnen S1. Er wordt geen bestaande registeropgave als onveranderd hergebruik gepresenteerd, geen targetstatus gepromoveerd en geen nieuwe nationale-examenvalidatie geclaimd.','box')+
p('**Controleerbare bouw.** Het pakket bevat bewerkbare pagina-manuscripten, auteursbestanden, figuurgenerator, PDF-renderer, opgave/antwoordregistratie en validatiescript. De figuren zijn berekend, niet door een beeldgenerator getekend. Een schone regeneratie en de lokale controle-uitkomsten staan in `QA/`.')+
p('De controle omvat volledigheid van opgaven en antwoorden, de vier doeloefeningen, de zeven koppen per theorieparagraaf, numerieke rekengevallen, teruggelezen SVG-geometrie, assets en één-op-één paginering. Daarnaast worden gerenderde pagina’s op leesbaarheid en onbedoelde splitsingen bekeken. Automatische controles vervangen geen beoordeling van leerlingwerk.')+
box('Afdrukken en doorbouwen','A4, ware grootte, dubbelzijdig over de lange zijde. De bronnen en vragen van opgave 37 staan op **tegenoverliggende pagina’s 36–37**. Bij latere bundeling moet dit even/oneven-paar behouden blijven en moeten verwijzingen opnieuw worden bijgewerkt. Antwoorden en docententekst blijven buiten het leerlinghoofdstuk.','box')+
p('De mate van begrip en de uiteindelijke lestijd vragen beoordeling in de klas. Eventuele verdere verbeteringen kunnen als een nieuwe versie worden vastgelegd zonder de oude printeditie te overschrijven.','note'))
write_pages(ROOT/'Docenteninformatie.md',TP)
print('Teacher:',len(TP),'planned pages')
