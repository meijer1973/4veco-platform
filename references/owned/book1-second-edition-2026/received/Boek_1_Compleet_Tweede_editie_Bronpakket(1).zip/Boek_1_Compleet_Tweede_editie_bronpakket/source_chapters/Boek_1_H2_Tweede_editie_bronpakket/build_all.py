"""Build from authored Python sources, then validate PDFs and export paragraphs.
Use --manuscripts to retain direct edits to the generated Markdown manuscripts.
"""
from pathlib import Path
import argparse, subprocess, sys
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--manuscripts',action='store_true',help='Render current Markdown without regenerating text or diagrams.')
args=parser.parse_args()
steps=[] if args.manuscripts else ['make_assets.py','author_chapter.py','author_answers.py','author_teacher.py']
steps += ['build.py','validate.py','export_paragraphs.py']
for step in steps:
    print(f'\n=== {step} ===',flush=True)
    subprocess.run([sys.executable,str(ROOT/step)],cwd=ROOT,check=True)
print('\nBuild and local validation complete. PDFs: output/. Paragraphs: paragrafen/.')
