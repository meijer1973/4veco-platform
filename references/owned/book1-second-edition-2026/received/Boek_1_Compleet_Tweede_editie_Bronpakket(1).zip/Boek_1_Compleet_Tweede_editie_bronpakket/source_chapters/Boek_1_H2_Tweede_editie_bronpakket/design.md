# Ontwerpbesluiten — Boek 1, tweede editie, hoofdstuk 1.2 Vraag

## Opdracht en afbakening
Basis: de door de gebruiker gekozen `book-1-outline-second-edition-v1.md`, met vier paragrafen 1.2.1–1.2.4. Het gedrukte eerste boek wordt niet gewijzigd. Dit is nieuwe leerlingtekst, met nieuw geschreven doelen, doeloefeningen, contexten en rekengetallen binnen de ontwerpbrief. De bijlagen met Boek 3/4 bepalen niet de hoofdstukindeling van Boek 1. De nieuwe tekst is geen citaat of stilzwijgende reparatie van een oude registeropgave.

Leerlijn: kopen per eenheid → vraag als verband → oorzaken van veranderingen → optellen bij dezelfde prijs → bronnen combineren. Hoofdstuk 1.1 is de bron voor eenheden, procenten, invullen, terugrekenen en tekenen. Nieuwe economische betekenis wordt expliciet uitgelegd. Aanbod, evenwicht, elasticiteitsformules, formele surplusoppervlakten en formele stukgewijze functies blijven buiten de verplichte route.

## Achterwaarts ontwerp vóór uitwerking
| Doel/waarneembare handeling | Doelopgave | Uitgewerkt voorbeeld | Start | Begeleid | Zelfstandig |
|---|---|---|---|---|---|
| Betalingsbereidheid vergelijken met een gegeven prijs, incl. afspraak bij gelijkheid | 8a | 1.2.1 bron A | 2 | 5 | 7 |
| Hoeveelheid berekenen, terugrekenen naar prijs en eenheden controleren | 8b–c | 1.2.1 bron B | 1–2 | 3–5 | 6–7 |
| Snijpunten bepalen en een lineaire vraaglijn tekenen | 8d–e | 1.2.1 bron B en antwoordgrafiek | 2 | 3: gelezen; 4: afgemaakt; 5: redeneren | 6 |
| Prijsreactie onder gelijkblijvende omstandigheden onderscheiden van feitelijke verkoop | 8f | 1.2.1 interpretatie | 2 | 3 | 6–7 |
| Eigen prijs → beweging; niet-prijsfactor → verschuiving; specifieke oorzaak benoemen | 19a–b,e | 1.2.2 | 12–13 | 14–16 | 17–18 |
| Bestaande vraaglijn aanvullen en twee veranderingen afzonderlijk en samen verklaren | 19c–d | 1.2.2 | 13 | 15–16 | 18 |
| Vraaghoeveelheden optellen bij dezelfde prijs; gelijksoortige termen verzamelen | 30a–b | 1.2.3 | 23–24 | 25–27 | 28–29 |
| Collectieve vraag grafisch weergeven binnen het aangegeven prijsinterval | 30c | 1.2.3 | 24 | 25 lezen; 26 aanvullen; 27 tekst | 28 |
| Uitgevallen groep draagt nul bij; gecombineerde formule niet onbegrensd extrapoleren | 30d–e | 1.2.3 | 24 | 27 | 29 |
| Zelf bronnen selecteren, functie gebruiken en grafische handeling verbinden met conclusie | 37a–f | Geen nieuwe theorie in 1.2.4 | voorgaande paragrafen | voorgaande paragrafen | 34–36 |

De definitieve paginanummers en de exacte vragen worden in de doelopgavenregistratie vastgelegd. De werkzaamheden worden door de gebruiker opgedragen; er wordt geen `reviewed_final`-status in het live register geclaimd.

## Fading en visuele precisie
- 1.2.1: ingevulde vraaggrafiek → assen en twee punten → tekst zonder grafiek → zelfstandig tekenen.
- 1.2.2: ingevulde beweging/verschuiving → oorspronkelijke lijn zonder antwoordmarkeringen → gecombineerde verandering in woorden → zelfstandig aanvullen van dezelfde representatiesoort.
- 1.2.3: ingevulde som bij dezelfde prijs → assen met één beginpunt → tekstuele nulbijdrage → zelfstandig tekenen van de gecombineerde lijn binnen het toegestane interval.
- Trapvorm en consumentensurplus zijn uitgelegd als begrensde kennismaking. Geen zelfstandige trapfunctieconstructie of CS-driehoek in de doelopgave.
- Punten, lijnstukken en hulplijnen komen uit dezelfde numerieke modellen. Validatie leest de uiteindelijke SVG-coördinaten terug. Geen generatief getekende economische grafieken.

## Paginaruimte
1: voorblad. 2–13: 1.2.1. 14–23: 1.2.2. 24–33: 1.2.3. 34–38: 1.2.4. 39–40: overzicht en begrippen. Samen 40 pagina's inclusief alle uitleg en oefeningen. Antwoorden en docenteninformatie zijn apart. Geen antwoordruimtevulling om het paginabudget te halen.

## Tijd en differentiatie
Uitgewerkte planning: zeven kernlessen van 55 minuten: twee voor 1.2.1, twee voor 1.2.2, twee voor 1.2.3 en één voor 1.2.4. Bij extra ondersteuningsbehoefte 7–9 lessen. Niet alle gedrukte opgaven zijn verplicht in één les. Per les wordt in de docentengids een concrete selectie met volledige tijdsbegroting aangegeven. Geen claim van empirisch gemeten timing of beheersing.
