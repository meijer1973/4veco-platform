from author_common import *
import author_121,author_122,author_123,author_124

at('1.2',1)
page('1.2','Inhoud · Vraag','<p class="kicker">BOEK 1 · TWEEDE EDITIE · HOOFDSTUK 2</p><h1 class="cover-title">Vraag</h1>'+p('Van één koopbeslissing naar de vraag van alle kopers.','lead')+
'<div class="contents">'+''.join(f'<a href="#p{ref.replace(".","")}"><b>{ref} · {t}<span>{n}</span></b><span>{sub}</span></a>' for ref,t,n,sub in [
('1.2.1','Betalingsbereidheid en individuele vraag',2,'Wie wil wat kopen, en bij welke prijs?'),
('1.2.2','Vraagfactoren: bewegen of verschuiven?',14,'De eigen prijs en andere oorzaken uit elkaar houden.'),
('1.2.3','Van individuele naar collectieve vraag',24,'Hoeveelheden optellen bij dezelfde prijs.'),
('1.2.4','Gemengde opgaven: vraag',34,'Bronnen, berekeningen en grafieken combineren.')])+'</div>'+
goals(['koopbeslissingen uitleggen met betalingsbereidheid;','met een vraagfunctie rekenen en een lijn met correcte snijpunten tekenen;','een eigen-prijsreactie onderscheiden van een verandering van andere vraagfactoren;','collectieve vraag bepalen, met nulbijdragen bij een te hoge prijs;','een berekening of grafiek verbinden met een precieze bronconclusie.'], heading='Na dit hoofdstuk kun je')+
'<h2>Waarom koopt niet iedereen evenveel?</h2>'+p('Een lagere prijs kan je overhalen nog iets te kopen. Maar ook je inkomen, plannen en de prijs van een alternatief spelen mee. In dit hoofdstuk maak je die koopbeslissingen zichtbaar. De reken- en tekenstappen uit hoofdstuk 1.1 krijgen zo een nieuwe economische betekenis.')+
box('Werken met dit hoofdstuk','Lees eerst de uitleg en het uitgewerkte voorbeeld. Maak daarna de startopgaven. De begeleide inoefening geeft extra hulp; zelfstandige oefening bereidt voor op de doeloefening. De denkertjes zijn extra. Gebruik een schrift, rekenmachine, potlood en liniaal.','box')+
p('Alle situaties en cijfers zijn geconstrueerde lesvoorbeelden. Het zijn geen uitspraken over actuele prijzen of werkelijk gemeten gedrag. Antwoorden staan in het afzonderlijke antwoordboek.','school-note'))

for m in [author_121,author_122,author_123,author_124]:m.make()
# Editorial pagination: keep the summary with its worked example; keep a guided
# heading with the first guided exercise. No text is removed.
b=PAGES[17]['body']; cut=b.index('</div>')+len('</div>')
PAGES[16]['body']+='\n'+b[:cut]
PAGES[17]['body']=b[cut:].lstrip()
heading='\n\n## Begeleide inoefening\n\n'+p(SKIP,'note')
assert PAGES[27]['body'].endswith(heading)
PAGES[27]['body']=PAGES[27]['body'][:-len(heading)]
PAGES[28]['body']=heading.strip()+'\n\n'+PAGES[28]['body']


at('Overzicht',39)
page('Overzicht','Overzicht · begrippen verbinden','<h1 id="overzicht">Het hoofdstuk in samenhang</h1>'+
table(['Je vraag','De aanpak','Controle'],[
['Welke losse eenheden wil iemand kopen?','Vergelijk per eenheid betalingsbereidheid met de prijs.','Gebruik de afspraak bij gelijkheid en de bronvoorwaarden.'],
['Hoeveel bij deze prijs?','Vul P in de geldige vraagfunctie in.','Eenheid, periode en niet-negatieve hoeveelheid.'],
['Welke prijs bij dit aantal?','Vul q of Q in; voer aan beide kanten dezelfde bewerking uit.','Controleer de oorspronkelijke formule.'],
['Hoe teken ik de lijn?','Bereken snijpunten of eindpunten van het gevraagde interval.','q/Q horizontaal, P verticaal; controlepunt op de lijn.'],
['Beweegt het punt of verschuift de lijn?','Benoem eerst welk product en welke factor veranderen.','Eigen prijs ≠ prijs van een ander goed.'],
['Wat gebeurt er bij twee veranderingen?','Onderzoek elk effect afzonderlijk; combineer daarna.','Zonder groottes kan een netto-effect onzeker blijven.'],
['Wat willen de kopers samen?','Tel hoeveelheden bij dezelfde prijs op.','Gelijke eenheid en periode; geen dubbeltelling.']])+
box('Een eigen-prijsreactie','De prijs van het onderzochte product verandert. Je beweegt langs de bestaande vraaglijn, terwijl andere omstandigheden gelijk blijven.','box')+
box('Een andere vraagfactor','De vraaglijn kan verschuiven door inkomen, behoeften/voorkeuren, de prijs van substituten of complementen, het aantal kopers of een gespecificeerde verwachting. Vergelijk bij dezelfde eigen prijs.','box')+
box('Formulevoorbeeld · controle op de grenzen','q<sub>A</sub> = 8 − 2P en q<sub>B</sub> = 12 − 2P geven samen Q = 20 − 4P **alleen voor 0 ≤ P ≤ 4**. Bij P = 5 tel je opnieuw: 0 + 2 = 2 liter per week.','formula')+
p('**Vooruitblik.** Je kunt nu berekenen wat kopers willen bij een prijs. Hoofdstuk 1.3 onderzoekt ook de aanbieders. Boek 2 bouwt verder op procentuele veranderingen, vraagfuncties en betalingsbereidheid.'))

at('Overzicht',40)
terms=[
('Behoeften en voorkeuren','Wat mensen willen en hoe zij producten waarderen. Een verandering kan de vraaglijn verschuiven.'),
('Betalingsbereidheid','Het maximale bedrag dat een koper voor een bepaalde eenheid wil betalen.'),
('Beweging langs de vraaglijn','Een andere gevraagde hoeveelheid door een verandering van de eigen prijs, ceteris paribus.'),
('Ceteris paribus','Alle overige omstandigheden blijven gelijk. Zo onderzoek je één verband.'),
('Collectieve vraag','De gezamenlijke vraag van alle kopers op een afgebakende markt, bij verschillende prijzen.'),
('Complementen','Goederen die in de beschreven situatie samen worden gebruikt.'),
('Consumentensurplus','Voordeel van een aankoop: betalingsbereidheid minus betaalde prijs. Hier alleen een eerste kennismaking; verdere behandeling in Boek 2.'),
('Geldigheid van een formule','De prijzen of hoeveelheden waarvoor de gegeven rekenregel als model mag worden gebruikt.'),
('Gevraagde hoeveelheid','Hoeveel iemand of een groep bij één prijs wil en kan kopen, binnen de bronvoorwaarden.'),
('Individuele vraag','Het prijs–hoeveelheidsverband voor één koper, bij gelijkblijvende overige omstandigheden.'),
('Koopgrens in het voorbeeld','De hoogste prijs waarbij het gegeven model nog een niet-negatieve hoeveelheid oplevert. Boven die grens draagt de koper nul bij.'),
('Lineair vraagmodel','Een vereenvoudigd vraagverband met een rechte lijn. Het geldt niet automatisch voor elk echt product.'),
('Snijpunt met een as','Een punt waar de lijn een as raakt of kruist. Op de prijsas is de hoeveelheid nul; op de hoeveelheidas de prijs.'),
('Substituten','Goederen die elkaar in het gebruik van de koper kunnen vervangen.'),
('Verschuiving van de vraaglijn','Meer of minder gevraagde hoeveelheid bij dezelfde prijs door een andere vraagfactor.'),
('Vraagfunctie','Een rekenregel voor het prijs–hoeveelheidsverband, met een expliciete eenheid, periode en geldigheid.')]
page('Overzicht','Begrippen','<h1 id="begrippen">Begrippen</h1>'+p('De definities horen bij de modellen en voorwaarden in dit hoofdstuk. q is een individuele hoeveelheid; Q een hoeveelheid voor een groep of alle kopers.')+'<div class="glossary-columns">'+''.join(f'<div class="term"><p><b>{t}</b><br>{d}</p></div>' for t,d in terms)+'</div>'+p('Bewaar steeds het onderscheid tussen een koopplan en feitelijke verkoop. Vraag alleen bepaalt nog geen aanbod of marktevenwicht.','note'))

assert len(PAGES)==40,len(PAGES)
assert sorted(e['number'] for e in EX)==list(range(1,39))
write_all()
print('Student:',len(PAGES),'pages;',len(EX),'exercises;',sum(len(e['questions']) for e in EX),'subquestions')
