# Boek 1 — tweede editie — Hoofdstuk 1.2 Vraag

## Uitgaven

- `output/Boek_1_H2_Vraag_Tweede_editie.pdf`: 40 leerlingpagina's.
- `output/Boek_1_H2_Antwoorden_Tweede_editie.pdf`: 22 antwoordpagina's.
- `output/Boek_1_H2_Docenteninformatie_Tweede_editie.pdf`: 8 docentpagina's.
- `paragrafen/`: vier losse leerlingparagrafen plus hun antwoorden; de paginanummers van het hoofdstuk blijven behouden.

De leerlinguitgave bevat 38 genummerde opgaven met 90 deelvragen, drie uitgewerkte voorbeelden, vier nieuw geschreven doeloefeningen en 22 instructieve figuren. Het antwoordboek bevat 11 aanvullende antwoordfiguren. Eén deelvraag kan verschillende berekeningen of tabelrijen omvatten; de telling is geen maat voor moeilijkheid of lestijd.

## Bron en status

De inhoud volgt `sources/book-1-outline-second-edition-v1.md`, door de gebruiker gekozen voor de tweede editie. De eerste editie blijft ongewijzigd. De huidige repositoryvaardigheden zijn geraadpleegd voor de werkwijze; `sources/source-register.json` bewaart bronidentiteit, geraadpleegde delen en blob-/bestandshashes. De contexten, getallen en doelopgaven zijn nieuw geschreven uitwerkingen van de ontwerpbrief, geen citaten of als officieel beoordeeld gepresenteerde registeropgaven.

De schriftelijke leerlingroute is volledig op papier. Er worden geen actuele prijzen, wettelijke tarieven, empirische gedragsschattingen of officiële examenvragen geclaimd. Een kleine kennismaking met consumentensurplus en de trapvorm ondersteunt het begrip; formele surplusrekening en zelfstandige trapfunctieconstructie zijn geen doeleisen.

## Bewerken en bouwen

Benodigd: Python 3, de pakketten uit `requirements.txt`, WeasyPrint-systeembibliotheken en lokaal geïnstalleerde Lato/DejaVu Sans-lettertypen. Lettertypebestanden worden niet meegeleverd. Voor exact dezelfde paginering zijn dezelfde renderer- en fontversies nodig.

```bash
python -m pip install -r requirements.txt
python build_all.py
```

De standaardroute genereert de figuren, de paginamanuscripten, antwoorden en docentengids opnieuw vanuit `author_*.py`; daarna worden PDF's gebouwd, lokaal gecontroleerd en per paragraaf geëxporteerd.

- **Inhoud wijzigen:** bewerk `author_121.py` t/m `author_124.py`; vragen en hun antwoorden staan bij elkaar. `author_chapter.py` voegt het voorblad en overzicht toe. `author_teacher.py` bevat de concrete lesplanning.
- **Visuals wijzigen:** bewerk de modellen of instructies in `make_assets.py`. `validate.py` leest vervolgens de werkelijke SVG-eindpunten, markeringen en hulplijnen terug.
- **Vormgeving wijzigen:** bewerk `print.css` en zo nodig de logisch gescheiden pagina's. Verwijder geen noodzakelijke tussenstappen om een pagina passend te maken.
- **Rechtstreeks Markdown wijzigen:** de leesbare `.md`-bestanden zijn ook bewerkbaar. Gebruik daarna `python build_all.py --manuscripts` om die bewerkingen niet door de auteurscripts te overschrijven. Pas bij inhoudelijke wijzigingen ook de vraag-/antwoordregistratie en relevante controles aan. De voorkeur voor volledig reproduceerbare wijzigingen is de eerste route.

`build.py` bundelt de Markdown-bestanden uit `chapter-order.json`, behoudt de logische pagina's en bouwt selecteerbare tekst en vectorfiguren. Er vindt geen bewerking van de GitHub-repositories plaats.

## Controles en grenzen

- `QA/validation.json`: numerieke controles, onafhankelijke doelopgavecontroles, SVG-geometrie, tekstbehoud van vragen/antwoorden, kopvolgorde, pagina's en navigatie.
- `QA/visual-review.md`: wat daadwerkelijk is bekeken en welke redactionele correcties zijn uitgevoerd.
- `QA/rebuild.json`: vergelijking met een afzonderlijke herbouw uit de auteursbronnen, inclusief paginering, tekst en rasterbeeld.
- `QA/paragraph_exports.json`: herkomst en tekstbehoud van de losse exports.
- `QA/exercises.json`: alle 38 opgaven met vraag, antwoord, waarom, bronpagina en eventuele figuur.
- `design.md`: didactische afbakening en achterwaartse doelafstemming.

Deze controles vervangen geen beoordeling van leerlingen of klassikale beproeving. De docentengids bevat zeven 55-minutenroutes; 7–9 lessen is een eerste planningsinschatting met ruimte voor extra begeleiding. Niet alle optionele opgaven worden aan de kernles toegevoegd.

## Afdrukken en later bundelen

A4, werkelijke grootte, dubbelzijdig, omslaan aan de lange zijde. De bronnen en vragen van doelopgave 37 staan op tegenoverliggende pagina's 36–37. Houd bij later bundelen het even/oneven karakter van deze spread in stand. Antwoorden en docentengids blijven buiten het leerlingboek. Het voorblad en de PDF-bladwijzers geven toegang tot de vier paragrafen.
