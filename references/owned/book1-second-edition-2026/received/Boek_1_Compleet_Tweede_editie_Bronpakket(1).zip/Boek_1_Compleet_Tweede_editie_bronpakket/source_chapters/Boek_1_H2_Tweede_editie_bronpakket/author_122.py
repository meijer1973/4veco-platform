from author_common import *

def make():
    at('1.2.2',14)
    page('1.2.2','Een ander aantal: wat is de oorzaak?',title('1.2.2','Vraagfactoren:<br>bewegen of verschuiven?')+
    goals(['een verandering door de eigen prijs onderscheiden van een andere vraagfactor;','de specifieke oorzaak, richting en grafische verandering uitleggen;','twee veranderingen eerst afzonderlijk en daarna samen analyseren.'])+
    p('Een ijssalon merkt dat kopers meer ijscoupes willen. Komt dat door een lagere prijs, of door warmer weer? Dezelfde richting van de hoeveelheid kan twee verschillende oorzaken hebben.')+
    p('We kijken nu naar de vraag van **een groep kopers**. Die hoeveelheid noemen we Q; q blijft de hoeveelheid van één koper. Hoe je kopers optelt, leer je in §1.2.3.')+
    fig('1.2.2_fig_1','Figuur 8 · Alleen de eigen prijs verandert: bij € 5 vragen de kopers 60 coupes; bij € 10 nog 40 coupes per week.')+
    box('Beweging langs de vraaglijn','De **prijs van het product zelf** verandert; de overige omstandigheden blijven gelijk. Je gaat naar een ander punt op dezelfde vraaglijn. Hier: van A naar B op V₀.','definition')+
    p('Bij deze lijn hoort Q = 80 − 4P, voor 0 ≤ P ≤ 20. Een hogere prijs van de ijscoupe verandert de hoeveelheid, **niet de lijn zelf**.'))

    at('1.2.2',15)
    page('1.2.2','Verschuiven: vergelijken bij dezelfde prijs',p('Begin nu opnieuw bij de ijssalon, maar houd P op € 10. Door warmer weer willen kopers **bij elke onderzochte prijs 20 coupes meer** per week. Dit is informatie uit ons model, geen algemene wet over de grootte van een weerseffect.')+
    fig('1.2.2_fig_2','Figuur 9 · De assen en schalen zijn gelijk aan figuur 8. Bij € 10 verandert de vraag van 40 naar 60 coupes per week.')+
    box('Verschuiving van de vraaglijn','Een **andere vraagfactor dan de eigen prijs** verandert. Bij dezelfde prijs vragen kopers meer of minder. Meer vraag: naar rechts. Minder vraag: naar links.','definition')+
    p('Oud: Q = 80 − 4P. Nieuw: Q = 100 − 4P, voor 0 ≤ P ≤ 25. De oorspronkelijke vergelijking blijft alleen de oude omstandigheden beschrijven. Voor een zuivere vergelijking kies je een prijs die in beide modellen past.')+
    table(['Wat kan de vraaglijn verschuiven?','Waar kijk je naar?'],[
      ['Inkomen','Willen kopers bij dezelfde prijs meer of minder van dit product?'],
      ['Behoeften en voorkeuren','Bijvoorbeeld weer of een nieuwe waardering van het product.'],
      ['Prijs van een ander goed','Vervangt dat goed ons product of gebruiken kopers ze samen?'],
      ['Aantal kopers','Alleen de vraag van de groep/markt verandert hierdoor.'],
      ['Verwachtingen','Wat zegt de bron over kopen nu in plaats van later?']])+
    box('Niet “de prijs wordt hoger, dus de lijn stijgt”','Een beweging naar een hoger punt op de lijn is geen verschuiving van de hele lijn. Controleer de oorzaak, niet alleen de richting van het getekende pijltje.','warning'))

    at('1.2.2',16)
    page('1.2.2','Andere goederen, inkomen en verwachtingen',p('**Substituten** zijn goederen die elkaar voor de koper kunnen vervangen. **Complementen** worden juist samen gebruikt. De relatie hangt af van het gebruik in de beschreven situatie.')+
    fig('1.2.2_fig_3','Figuur 10 · De bron neemt aan dat sommige kopers thee door koffie vervangen. Alle overige omstandigheden blijven gelijk.')+
    fig('1.2.2_fig_4','Figuur 11 · De bron neemt aan dat printers en bijpassende inkt samen worden gebruikt.')+
    p('**Inkomen.** Bij meer inkomen willen kopers in een bron bijvoorbeeld vaker naar een concert: de vraag verschuift naar rechts. Een andere bron kan vertellen dat zij juist minder goedkope kant-en-klaarmaaltijden kiezen en vaker uit eten gaan. Dan verschuift de vraag naar die maaltijden naar links. Lees het gegeven gedrag; inkomenstoename betekent niet voor elk product meer vraag.')+
    p('**Aantal kopers.** Meer mensen die bij een gegeven prijs willen kopen vergroten de vraag van de groep. Dat hoeft de vraag van één bestaande koper niet te veranderen.')+
    p('**Verwachtingen.** Verwachten klanten volgende week een korting en stellen zij volgens de bron hun aankoop uit? Dan kan de vraag **nu** afnemen, hoewel de huidige prijs gelijk blijft. Verander de periode niet ongemerkt in je antwoord.')+
    box('Benoem de precieze oorzaak','“Koffie wordt aantrekkelijker” is nog geen volledige oorzaak. Bij een hogere theeprijs is de factor **de prijs van een substituut**, niet een veranderde voorkeur voor koffie.','warning'))

    at('1.2.2',17)
    page('1.2.2','Uitgewerkt voorbeeld · twee veranderingen','## Uitgewerkt voorbeeld\n\n'+
    p('Een lunchkraam gebruikt Q = 60 − 3P voor wraps, geldig voor 0 ≤ P ≤ 20. Q is wraps per middag; P is euro per wrap. De prijs stijgt van € 6 naar € 8. Tegelijk worden broodjes bij een andere kraam duurder. De bron beschouwt broodjes als substituut. Daardoor vragen kopers bij elke onderzochte prijs 12 wraps extra. De overige omstandigheden blijven gelijk.')+
    p('**a. Alleen de eigen prijs:** oud Q = 60 − 3 × 6 = **42**. Bij € 8 op de oude lijn: Q = 60 − 3 × 8 = **36 wraps per middag**. Dat is een beweging van A naar B langs V₀.')+
    p('**b. Alleen de broodjesprijs:** de factor is de prijs van een substituut. De vraag naar wraps verschuift naar rechts. Bij € 8 gaat Q van 36 naar **48**. De nieuwe lijn is Q = 72 − 3P, geldig voor 0 ≤ P ≤ 24.')+
    fig('1.2.2_we_1','Figuur 12 · A is de oude situatie. B is de denkstap “alleen de eigen prijs”. C is de situatie met beide veranderingen.')+
    p('**c. Beide samen:** het eigen-prijseffect is −6 en het substituuteffect +12 wraps per middag. Ze werken tegen elkaar in. Samen: 42 − 6 + 12 = **48 wraps**, dus 6 meer dan eerst.')+
    p('**d. De onjuiste uitleg:** “De hogere wrapprijs heeft de vraaglijn naar rechts verschoven.” Dat klopt niet. Die prijsstijging gaf juist een beweging met minder vraag. De hogere broodjesprijs veroorzaakt de verschuiving.'))

    at('1.2.2',18)
    page('1.2.2','Starten en een verschuiving herkennen',box('Samenvatting · 1.2.2','Kies eerst het product en de periode. De eigen prijs geeft een beweging langs de lijn; een andere vraagfactor kan de lijn verschuiven. Benoem bij een ander product de relatie. Bekijk twee veranderingen apart voordat je hun effecten combineert. Zonder getallen is het netto-effect soms niet te bepalen. Hierna tel je de vraag van kopers op.','box summary')+
    '\n\n## Startopgaven\n\n'+
    ex(12,'Rekenen met een bekende basis','Gebruik de rekenstappen uit het vorige hoofdstuk en §1.2.1.',
      ['Een aantal daalt van 24 naar 18. Bereken de procentuele verandering.','Bereken Q bij P = € 6 in Q = 24 − 2P. Q is stuks per week; de formule geldt voor 0 ≤ P ≤ 12.'],
      [('(18 − 24) / 24 × 100% = **−25%**.','Je vergelijkt de afname met de oude hoeveelheid 24.'),('Q = 24 − 2 × 6 = **12 stuks per week**.','Alleen de gegeven prijs wordt ingevuld.')],kind='start')+
    ex(13,'Wat verandert er?','Je onderzoekt de vraag naar een rugzak. De prijs van deze rugzak daalt; alle andere omstandigheden blijven gelijk.',
      ['Is dit een beweging langs of een verschuiving van de vraaglijn? Noem ook de richting van de hoeveelheid.'],
      [('Een **beweging langs** de bestaande vraaglijn, naar een grotere gevraagde hoeveelheid.','De eigen prijs verandert; de andere vraagfactoren niet.')],kind='start')+
    box('Oefenroute',ROUTE,'route')+
    '\n\n## Begeleide inoefening\n\n'+p(SKIP,'note')+
    ex(14,'Een beter gewaardeerde helm','Na nieuwe informatie waarderen kopers fietshelmen meer. De prijs blijft € 6. Bekijk de ingevulde grafiek.',
      ['Lees Q vóór en na de verandering af. Welke factor en welke richting horen hierbij?'],
      [('Q gaat van **24 naar 40 helmen per week**. De factor is behoeften/voorkeuren; de lijn verschuift **naar rechts**.','Bij dezelfde prijs willen de kopers meer helmen; dat is geen eigen-prijsbeweging.')],kind='guided',extra=fig('1.2.2_ex_14','Figuur 13 · De oorzaak en beide hulplijnen zijn gegeven. Lees eerst wat er staat.')))

    at('1.2.2',19)
    page('1.2.2','Begeleide inoefening · zelf markeren',ex(15,'Twee losse veranderingen bij de wasstraat','De beginlijn is Q = 120 − 10P, voor 0 ≤ P ≤ 12. Q is wasbeurten per dag; P is euro per wasbeurt. Bij beide veranderingen hieronder begin je opnieuw bij deze lijn en P = € 6.',
      ['De eigen prijs stijgt naar € 8; de overige omstandigheden blijven gelijk. Bereken beide hoeveelheden en teken de beweging met een pijl.','De prijs bij een concurrerende wasstraat daalt. Volgens de bron is die dienst een substituut. Bij elke prijs worden bij onze wasstraat 20 wasbeurten minder gevraagd. Teken V₁ voor Q = 100 − 10P, voor 0 ≤ P ≤ 10, en markeer de hoeveelheid bij € 6. Gebruik bijvoorbeeld de snijpunten.','Leg uit waarom de twee pijlen niet hetzelfde soort verandering laten zien.'],
      [('Bij € 6: 120 − 10 × 6 = **60 wasbeurten**. Bij € 8: 120 − 10 × 8 = **40 wasbeurten per dag**. Pijl van (60; 6) naar (40; 8) op V₀.','Alleen de prijs van de eigen dienst verandert.'),('V₁ loopt door **(100; 0)** en **(0; 10)**. Bij € 6: Q = 100 − 10 × 6 = **40 wasbeurten per dag**; markeer (40; 6).','De lagere prijs van het substituut vermindert de vraag bij dezelfde eigen prijs.'),('In a beweeg je **langs V₀**. In b verschuift de lijn **naar links** door de prijs van een substituut.','Een andere hoeveelheid kan door verschillende oorzaken ontstaan. De gevallen zijn los van elkaar, niet opgeteld.')],kind='guided',extra=fig('1.2.2_ex_15','Figuur 14 · Alleen de beginlijn is gegeven. De antwoordmarkeringen en nieuwe lijn voeg je zelf toe.'),ansfig='1.2.2_ans_15')+
    box('Controle van je tekening','De lijn in a blijft precies liggen. In b vergelijk je eerst beide hoeveelheden bij € 6. Noem bij je pijl ook de oorzaak; een richting alleen is niet voldoende.','box'))

    at('1.2.2',20)
    page('1.2.2','Eerst afzonderlijk, dan samen',ex(16,'Een spel en de bijbehorende console','De prijs van een nieuw spel daalt. Tegelijk stijgt de prijs van de console die nodig is om het spel te spelen. Volgens de bron gebruiken klanten beide samen; verder verandert er niets. De grootte van de effecten is niet gegeven.',
      ['Bekijk eerst alleen de spelprijs. Wat gebeurt er met de vraaggrafiek voor het spel?','Bekijk daarna alleen de consoleprijs. Benoem de vraagfactor en de richting.','Versterken de twee effecten elkaar? Kun je de uiteindelijke hoeveelheid bepalen?','Een leerling zegt: “De duurdere console betekent dat de spelprijs stijgt.” Leg uit waarom die redenering onjuist is.'],
      [('Een **beweging langs** de vraaglijn naar een grotere gevraagde hoeveelheid.','Het spel is het onderzochte product; zijn eigen prijs daalt.'),('De console is een **complement**. Zijn hogere prijs kan de vraag naar het spel **naar links verschuiven**, zoals de bron beschrijft.','Het gaat om de prijs van een ander, samen gebruikt goed.'),('De effecten **werken tegen elkaar in**. Zonder de grootte van beide effecten is ook de richting van de totale hoeveelheidsverandering niet zeker.','Een positieve en een negatieve bijdrage kun je niet op richting alleen bij elkaar optellen.'),('De consoleprijs en spelprijs zijn verschillende prijzen. De bron zegt juist dat het spel goedkoper wordt.','Benoem steeds de eigenaar van de veranderde prijs; anders wissel je ongemerkt van product.')],kind='guided')+
    '\n\n## Zelfstandige oefening\n\n'+
    ex(17,'De oorzaak precies benoemen','Onderzoek steeds de vraag naar het product in de eerste kolom. De overige omstandigheden blijven gelijk. Neem de tabel over en vul de laatste drie kolommen in.',
      ['Classificeer alle vier situaties. Gebruik de specifieke factor, niet alleen “er verandert iets”.'],
      [('1. Rugzak: **beweging langs; Q stijgt; eigen prijs**. 2. Havermelk: **verschuiving rechts; prijs substituut koemelk**. 3. Simpele afhaalmaaltijd: **verschuiving links; inkomen**. 4. Schriften bij de school: **verschuiving rechts; aantal kopers**.','Je gebruikt het productgedrag dat de bron noemt. Vooral bij inkomen is “meer inkomen → meer van alles” geen geldige algemene regel.')],extra=table(['Product en verandering','Beweging of verschuiving?','Richting Q bij vergelijking','Specifieke factor'],[
      ['Rugzak: de eigen prijs daalt.','…','…','…'],
      ['Havermelk: koemelk wordt duurder; kopers vervangen koemelk door havermelk.','…','…','…'],
      ['Simpele afhaalmaaltijd: kopers verdienen meer en kiezen volgens de bron vaker een restaurant.','…','…','…'],
      ['Schriften: er komen meer leerlingen bij de school.','…','…','…']])) )

    at('1.2.2',21)
    page('1.2.2','Zelfstandig tekenen en combineren',ex(18,'Meer danslessen','Voor danslessen geldt eerst Q = 60 − 3P, voor 0 ≤ P ≤ 20. Q is lessen per week; P is euro per les. De prijs daalt van € 10 naar € 8. Tegelijk stijgt het inkomen van de kopers. Volgens de bron willen zij daardoor bij elke onderzochte prijs 12 lessen extra. De overige omstandigheden blijven gelijk.',
      ['Bereken de oude hoeveelheid en de hoeveelheid na alleen de eigen prijsdaling. Benoem het soort grafische verandering.','Voeg de nieuwe vraaglijn en de oude en uiteindelijke punten aan de figuur toe. Noteer de coördinaten bij de punten.','Bereken de uiteindelijke hoeveelheid. Leg uit of de twee effecten elkaar versterken of tegenwerken.'],
      [('Oud: 60 − 3 × 10 = **30 lessen per week**. Alleen prijs: 60 − 3 × 8 = **36 lessen per week**. Dit is een beweging langs V₀.','Je houdt voor het eerste effect de oorspronkelijke vraagfunctie vast.'),('Nieuwe lijn: **Q = 72 − 3P** (0 ≤ P ≤ 24). Oud A = **(30; 10)**; alleen prijs B = **(36; 8)**; uiteindelijk C = **(48; 8)**.','Het inkomen verhoogt volgens de bron Q bij elke prijs met 12; daarom verschuift de lijn naar rechts.'),('Uiteindelijk: 72 − 3 × 8 = **48 lessen per week**. De prijsdaling geeft +6 en de inkomensverandering +12: de effecten **versterken elkaar**.','De stijging van 30 naar 48 heeft twee apart benoemde oorzaken.')],extra=fig('1.2.2_ex_18','Figuur 15 · Je krijgt alleen de oorspronkelijke vraaglijn, net als bij de doeloefening.'),ansfig='1.2.2_ans_18')+
    box('Een conclusie met bewijs','Een volledig antwoord noemt een verandering, een getal of grafische aanwijzing en de economische oorzaak. Alleen “meer vraag” mist de vergelijking met de oude situatie.','box'))

    at('1.2.2',22)
    page('1.2.2','Doeloefening','## Doeloefening\n\n'+
    ex(19,'Filmhuis Lumi','Voor filmbezoeken geldt eerst Q = 100 − 5P, voor 0 ≤ P ≤ 20. Q is bezoeken per week; P is euro per bezoek. Lumi verhoogt de prijs van € 8 naar € 10. Tegelijk worden kaartjes van een nabijgelegen bioscoop duurder. Volgens de bron zijn die bezoeken substituten. Hierdoor worden bij Lumi bij elke onderzochte prijs 20 bezoeken extra gevraagd. Verder blijven de omstandigheden gelijk.',
      ['Bereken Q vóór de veranderingen en na alleen de eigen prijsstijging. Benoem de grafische verandering.','Welke specifieke factor veroorzaakt de andere verandering? Benoem de richting van de verschuiving.','Teken de nieuwe vraaglijn in de figuur. Markeer A (oud), B (alleen de eigen prijsstijging) en C (beide veranderingen). Noteer hun coördinaten.','Bereken de uiteindelijke hoeveelheid en de verandering ten opzichte van het begin. Werken de twee effecten elkaar tegen of versterken ze elkaar?','Beoordeel: “De hogere prijs van Lumi verschuift zijn vraaglijn naar rechts.” Gebruik je uitkomsten.'],
      [('Oud: 100 − 5 × 8 = **60 bezoeken per week**. Alleen de eigen prijs: 100 − 5 × 10 = **50 bezoeken per week**. Beweging langs V₀ naar minder bezoeken.','De eigen prijsstijging wordt eerst los bekeken.'),('De factor is de **prijs van een substituut**: de andere bioscoop wordt duurder. De vraag naar Lumi verschuift **naar rechts**.','Het product waarvan de prijs verandert is niet Lumi’s eigen filmbezoek.'),('Nieuwe lijn: **Q = 120 − 5P**, voor 0 ≤ P ≤ 24. A = **(60; 8)**; B = **(50; 10)**; C = **(70; 10)**.','Alleen C bevat beide veranderingen; B is een analytische tussenstap.'),('Q nieuw = 120 − 5 × 10 = **70 bezoeken per week**. Verandering: 70 − 60 = **10 bezoeken meer**. De effecten werken elkaar tegen: −10 + 20 = +10.','De bron geeft de omvang van beide effecten; daarom kan hier wel een netto-uitkomst worden berekend.'),('**Onjuist.** Lumi’s eigen prijsstijging verplaatst het punt op V₀ van 60 naar 50 bezoeken. De prijs van het substituut veroorzaakt de verschuiving naar V₁.','De uiteindelijke stijging naar 70 bewijst niet dat een hogere eigen prijs de vraaglijn naar rechts verschuift.')],kind='target',extra=fig('1.2.2_ex_19','Figuur 16 · Voeg de nieuwe lijn en de gevraagde punten zelf toe.'),ansfig='1.2.2_ans_19'))

    at('1.2.2',23)
    page('1.2.2','Denkertje en herhaling','## Denkertje / Bonusopgave\n\n'+
    ex(20,'Een onderzoek met te weinig informatie','Een winkel ziet dat een bordspel duurder is geworden en dat meer mensen het willen kopen. Er staat niets over inkomen, andere spellen of voorkeuren.',
      ['Een medewerker zegt dat de vraaglijn daarom stijgend moet zijn. Geef een andere mogelijke verklaring. Leg uit welke extra informatie nodig is om de eigen-prijsreactie te onderzoeken.'],
      [('De belangstelling kan tegelijk zijn toegenomen, bijvoorbeeld door nieuwe positieve ervaringen die kopers met het spel delen. Een vraagverschuiving naar rechts kan de negatieve eigen-prijsreactie overtreffen. Om het eigen-prijseffect te onderzoeken moet je de prijs vergelijken bij **gelijkblijvende overige omstandigheden** of het effect van de andere veranderingen afzonderlijk vaststellen.','Twee gelijktijdig geobserveerde veranderingen bewijzen niet het verband dat zou gelden onder ceteris paribus.')],kind='bonus',criteria=['Een plausibele niet-prijsfactor wordt genoemd als mogelijkheid, niet als bewezen feit.','Eigen-prijsreactie en vraagverschuiving blijven onderscheiden.','De benodigde vergelijking houdt andere omstandigheden gelijk.'])+
    '\n\n## Herhaling / Herhaling en interleaving\n\n'+
    ex(21,'Indexen vergelijken','De prijsindex van sportmateriaal gaat van 120 naar 132; beide indexen gebruiken hetzelfde basisjaar.',
      ['Bereken de procentuele verandering. Leg uit waarom het antwoord niet 12% is.'],
      [('(132 − 120) / 120 × 100% = **10% stijging**. Het verschil is **12 indexpunten**, niet 12%.','De oude index 120, niet 100, is de basis voor deze verandering. Herhaal zo nodig §1.1.2.')],kind='review')+
    ex(22,'Een formule teruglezen','Een individuele vraag wordt beschreven door q = 16 − 2P voor 0 ≤ P ≤ 8. q is stuks per maand; P is euro per stuk.',
      ['Bereken P als q = 8 en controleer de oorspronkelijke formule.'],
      [('8 = 16 − 2P → 2P = 8 → P = **€ 4 per stuk**. Controle: 16 − 2 × 4 = 8 stuks per maand.','Een gegeven hoeveelheid kan worden gebruikt om de bijbehorende prijs terug te rekenen. Herhaal zo nodig §1.2.1.')],kind='review')+
    box('Van een verandering naar een totaal','Het aantal kopers kan de vraag van een groep veranderen. In §1.2.3 ontdek je hoe de afzonderlijke koopplannen precies bij elkaar worden opgeteld.','box'))
    for lab,expr,res in [('Lumi oud','100-5*8',60),('Lumi alleenprijs','100-5*10',50),('Lumi nieuw','120-5*10',70),('Lumi nettoverschil','70-60',10),('Wraps oud','60-3*6',42),('Wraps tussen','60-3*8',36),('Wraps nieuw','72-3*8',48),('Dans oud','60-3*10',30),('Dans nieuw','72-3*8',48),('Wasstraat verschoven','100-10*6',40),('Helmen extra','40-24',16),('Index21','(132-120)/120*100',10)]:ck(lab,expr,res)
