"""Render every written answer and its rationale; no answer is inferred from a PDF."""
from author_common import *
import json
E={e['number']:e for e in json.loads((ROOT/'QA/exercises.json').read_text())}
AP=[]
def add(sec,t,b):AP.append({'section':sec,'title':t,'body':b})

def item(n,first=0,last=None,diagram=True):
    e=E[n];last=len(e['answers']) if last is None else last
    head=f'Opgave {n} · {e["title"]}'+(' — vervolg' if first else '')
    h=f'<h3 id="ans{n}{"cont" if first else ""}">{head}</h3>'
    for i in range(first,last):
        a,w=e['answers'][i]
        h+='<div class="answer-item">'+p(f'**{chr(97+i)}.** '+a)
        if w:h+=p('**Waarom:** '+w,'why')
        h+='</div>'
    if e['criteria']:
        h+=box('Beoordelingscriteria','<ul>'+''.join('<li>'+MD.renderInline(c)+'</li>' for c in e['criteria'])+'</ul>','box small')
    if diagram and e['answer_figure']:
        h+=fig(e['answer_figure'],f'Antwoordfiguur · Opgave {n}. De schalen mogen anders zijn, maar de coördinaten en het getekende interval moeten kloppen.')
    return h

add('Antwoorden','Zo gebruik je dit antwoordboek','<p class="kicker">BOEK 1 · TWEEDE EDITIE · HOOFDSTUK 2</p><h1>Antwoorden<br>Vraag</h1>'+p('Dit antwoordboek hoort bij het leerlinghoofdstuk van 40 pagina’s. Het bevat antwoorden op **38 opgaven met 90 deelvragen**. Een denkertje heeft een voorbeeldantwoord en beoordelingscriteria; andere goed onderbouwde oplossingen zijn mogelijk.')+
table(['Paragraaf','Opgaven','Pagina hier'],[['1.2.1 Betalingsbereidheid en individuele vraag','1–11','2'],['1.2.2 Vraagfactoren','12–22','7'],['1.2.3 Collectieve vraag','23–33','13'],['1.2.4 Gemengde opgaven','34–38','18']])+
box('Vergelijk de stappen','Controleer de gekozen bron, de prijs, de hoeveelheid, de periode en de eenheid. Bekijk bij een fout eerst de berekening of uitleg, niet alleen het eindantwoord. “Waarom” verbindt de uitkomst met de economische betekenis.','box')+
box('Afronden','Rond geldbedragen zo nodig af op centen en percentages op twee decimalen. Gebruik ongeronde tussenuitkomsten. Een hoeveelheid blijft in de eenheid van de bron staan. Bij € 3,50 hoort bijvoorbeeld niet 3,5 liter, tenzij dat is berekend.','box')+
box('Grafieken beoordelen','Een andere nette schaal is goed. De assen, eenheden, punten, lijnen en geldigheidsgrenzen moeten kloppen. Bij het aanvullen van een gegeven grafiek behoud je de bestaande schalen. Een lijn buiten het gevraagde interval is niet automatisch een geldige voorspelling.','box')+
p('Alle contexten en getallen zijn geconstrueerde lesvoorbeelden. De antwoorden bewijzen geen werkelijk gedrag van klanten of bedrijven.','note'))
add('1.2.1','Start en eerste begeleide oefening','<h2 id="ant121">1.2.1 · Betalingsbereidheid en vraag</h2>'+item(1)+item(2)+item(3))
add('1.2.1','De lijn afmaken en terugrekenen',item(4)+item(5))
add('1.2.1','Zelfstandig tekenen en kopen',item(6)+item(7))
add('1.2.1','Doeloefening',item(8))
add('1.2.1','Denkertje en herhaling',item(9)+item(10)+item(11))
add('1.2.2','Start en een verschuiving lezen','<h2 id="ant122">1.2.2 · Vraagfactoren</h2>'+item(12)+item(13)+item(14))
add('1.2.2','Begeleide grafische vergelijking',item(15))
add('1.2.2','Twee veranderingen en classificatie',item(16)+item(17))
add('1.2.2','Zelfstandig tekenen',item(18))
add('1.2.2','Doeloefening',item(19))
add('1.2.2','Denkertje en herhaling',item(20)+item(21)+item(22))
add('1.2.3','Start en horizontaal optellen','<h2 id="ant123">1.2.3 · Collectieve vraag</h2>'+item(23)+item(24)+item(25))
add('1.2.3','Geldige som en nulbijdrage',item(26)+item(27))
add('1.2.3','Zelfstandige oefening',item(28)+item(29))
add('1.2.3','Doeloefening',item(30))
add('1.2.3','Denkertje en herhaling',item(31)+item(32)+item(33))
add('1.2.4','Gemengde oefening','<h2 id="ant124">1.2.4 · Gemengde opgaven</h2>'+item(34)+item(35))
add('1.2.4','Een functie in de andere schrijfwijze',item(36))
add('1.2.4','Doeloefening · som en oorzaken',item(37,last=3,diagram=False)+box('Bronnen uit elkaar houden','Bron A bevat de oorspronkelijke groepsfuncties. Bron B beschrijft de twee veranderingen. Bron C is één koper die al bij A is meegeteld. Gebruik de bron die de vraag daadwerkelijk ondersteunt.','box'))
add('1.2.4','Doeloefening · grafiek en conclusie',item(37,first=3))
add('1.2.4','Fouten repareren',item(38)+box('Terug naar de juiste uitleg','Eenheden en perioden: §1.1.2 en §1.2.3. Substituten en complementen: §1.2.2. Het verschil tussen gevraagde hoeveelheid en werkelijk verkocht: §1.2.1.','box'))
write_pages(ROOT/'Antwoorden.md',AP)
print('Answers:',len(AP),'planned pages')
