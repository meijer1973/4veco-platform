"""Export the four sections without reflow; retain printed chapter page numbers."""
from pathlib import Path
import fitz, json, re
R=Path(__file__).resolve().parent;D=R/'paragraphs';D.mkdir(exist_ok=True)
PARTS=[('1.3.1','Aanbod en aanbodfactoren',2,11),('1.3.2','Marktevenwicht',12,23),('1.3.3','Verschuivingen en nieuw evenwicht',24,33),('1.3.4','Gemengde opgaven',34,38)]
def main():
 records=[];ex=json.loads((R/'QA/exercises.json').read_text())
 with fitz.open(R/'output/Boek_1_H3_Aanbod_en_marktevenwicht_Tweede_editie.pdf') as source:
  for ref,name,a,b in PARTS:
   typ='opgaven' if ref=='1.3.4' else 'paragraaf';f=D/f'{ref} {name} – {typ}.pdf'
   doc=fitz.open();doc.insert_pdf(source,from_page=a-1,to_page=b-1);doc.set_toc([[1,f'{ref} {name}',1]])
   doc.set_metadata({'title':f'{ref} {name} – Boek 1, tweede editie','subject':'Afzonderlijke paragraaf; behoudt de hoofdstukpaginanummers','author':''})
   doc.save(f,garbage=4,deflate=True);doc.close()
   src=next(R.glob(ref+' *.md'));content=src.read_text()
   (D/src.name).write_text(content.replace('src="_assets/','src="../_assets/'))
   if ref!='1.3.4':
    start=content.index('## Uitgewerkt voorbeeld');(D/f'{ref} {name} – opgaven.md').write_text((f'# Opgaven {ref} — {name}\n\n'+content[start:]).replace('src="_assets/','src="../_assets/'))
   out=[f'# Antwoorden {ref} — {name}','Rond alleen eindantwoorden af: prijzen op twee decimalen, percentages zo nodig op één decimaal.']
   for e in ex:
    if e['section']!=ref:continue
    out+=[f"## Opgave {e['number']} — {e['title']}"]
    out += [f"**{chr(97+i)}.** {ans}" for i,ans in enumerate(e['answers'])]
    if e['criteria']:out += ['**Beoordelingscriteria**']+['- '+c for c in e['criteria']]
    if e['answer_figure']:out += [f"![Uitwerking opgave {e['number']}](../_assets/{e['answer_figure']}.svg)"]
   (D/f'{ref} {name} – antwoorden.md').write_text('\n\n'.join(out))
   check=fitz.open(f);assert len(check)==b-a+1
   assert all(check[i].get_text()==source[a+i-1].get_text() for i in range(b-a+1))
   records.append({'section':ref,'file':f.relative_to(R).as_posix(),'chapter_pages':[a,b],'pages':b-a+1,'source_text_preserved':True})
 (R/'QA/paragraph_exports.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
 print('Exported',len(records),'paragraph PDFs, with exact text preservation.')
if __name__=='__main__':main()
