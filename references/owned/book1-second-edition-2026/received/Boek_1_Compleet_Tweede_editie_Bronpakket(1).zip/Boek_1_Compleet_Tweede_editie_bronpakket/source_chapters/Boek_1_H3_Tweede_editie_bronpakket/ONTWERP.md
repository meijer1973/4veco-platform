# Ontwerp vóór uitwerking — Boek 1, hoofdstuk 3 (tweede editie)

De gebruiker vraagt productie volgens de tweede-editieopzet uit deze conversatie. De huidige gedrukte eerste editie en de repositoryregistratie worden niet gewijzigd. De vier onderstaande nieuwe doeloefeningen concretiseren de opzet; dit zijn geen overgenomen of extern goedgekeurde registerdoelen.

## Paginaroute
1: voorblad. 2–11: §1.3.1. 12–23: §1.3.2. 24–33: §1.3.3. 34–38: §1.3.4. 39–40: naslag. Antwoorden en docenteninformatie apart.

## Backward design
| Doel | Doeloefening en waarneembare bewerking | Uitgewerkt voorbeeld | Start | Begeleide inoefening | Zelfstandig |
|---|---|---|---|---|---|
| Aanbodfunctie en eenheden | 9a: hoeveelheid op twee prijzen, coefficient betekenis | Basilicumtrays: 4P−12 | 1 substitutie; 2 aanbod versus voorraad | 3 aflezen; 4 tabel | 6 berekenen en terugrekenen |
| Verkoopprijs versus productiemiddelprijs | 9b–e: nieuwe lijn, punten, beide effecten en misvatting | Basilicumtrays: prijsverhoging en duurdere kweekgrond | 2 aanbodplannen | 4 nieuwe lijn; 5 gecombineerde verandering | 7 classificatietabel; 8 tekenen |
| Evenwicht begrijpen, oplossen en controleren | 20a–b: Qv=Qa, P, Q en twee controles | Markt voor herbruikbare flessen | 12 eenvoudige vergelijking; 13 betekenis | 14 compleet beeld; 15 aanvullen | 17 volledig; 18 inverse prijsrelaties |
| Marktgrafiek construeren | 20c: assen, twee lijnen, E en hulplijnen | Zelfde voorbeeld, overeenstemmende formule en grafiek | 13 aflezen/bedoeling | 14 herkenning; 15 vraaglijn als steun | 17 zonder gegeven grafiek |
| Plannen, transacties en prijsdruk | 20d–e: tekort, verkopen onder matchingsregel, druk | Flessen: andere prijs; geen verdere belemmeringen | 13 gewenste versus werkelijke aantallen | 14 aflezen; 16 zonder figuur | 19 vraag- en aanbodoverschot |
| Nieuw evenwicht en juiste oorzaak | 31a–d: uitgangssituatie, nieuwe functie, evenwichten, procenten en pijlen | Verpakkingskosten aardbeien | 23 percentage; 24 oorzaak | 25 volledig; 26 basisgrafiek | 28 rekenketen; 29 tekenen |
| Verschuiving versus reactie op nieuwe prijs | 31e: verwerp oorzaakverwisseling | Pijl van verschuiving en beweging op ongewijzigde vraag | 24 onderscheid | 26 uitleg; 27 twee verschuivingen | 29 en 30 bronkritiek |
| Integratie en Book 2-voorbereiding | 37: twee evenwichten, prijsdruk, grafiek, % en brongebonden claim | Geen nieuwe theorie | 34–36 gemengd | Verwijzing naar eerdere steun, geen nieuw lesblok | 34–36; 38 per-eenheid/verschil/meetkunde |

## Inhoudsgrenzen
Aanbod is nieuw; aanbod als MK niet. Twee-zijdige gelijkheid is nieuw; geen winst/break-even. Tekort is vraagoverschot bij een prijs, niet synoniem voor schaarste. Werkelijke transacties alleen met expliciet beschreven matching, geen extra voorraden of andere belemmeringen. Geen heffing, subsidie of wettelijke prijsgrens. Geen formele elasticiteit, CS/PS/DWL-interpretatie, Pareto-claim of arbeidsmarktmodel. Meetkunde in 38 is een herhaling, geen heimelijke surplusles.

## Lesbelasting
Voorlopig 7 kernlessen: aanbod (2), evenwicht (2), verschuivingen (2), gemengd (1). Niet alle gedrukte opgaven zijn in één les verplicht. Details en werkelijke vraagselecties komen in de docenteninformatie. 7–9 lessen voor eerste gebruik is een ontwerpschatting, geen gemeten effect.
