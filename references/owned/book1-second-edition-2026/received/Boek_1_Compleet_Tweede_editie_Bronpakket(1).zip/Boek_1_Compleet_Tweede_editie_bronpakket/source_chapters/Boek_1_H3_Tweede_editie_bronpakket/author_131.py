from author_common import *
def make():
 s='1.3.1'
 at(s,2)
 page(s,'Wie biedt het product aan?',title(s,'Aanbod en aanbodfactoren')+
 p('**Waarom maakt een atelier bij een hogere prijs meer plantenpotten?** Extra potten vragen klei, een oven en tijd. Een hogere verkoopprijs kan het aantrekkelijk maken om daarvoor meer middelen in te zetten. Maar hoeveel het atelier kan maken, hangt ook af van zijn mogelijkheden.')+
 goals(['aanbod en aangeboden hoeveelheid uitleggen;','rekenen met een aanbodfunctie en de eenheden noemen;','een prijsbeweging onderscheiden van een verschuiving door een aanbodfactor;','aanbodplannen, voorraad en werkelijke verkoop uit elkaar houden.'])+
 fig('1.3.1_fig_1','Figuur 1 · De koopkant ken je uit hoofdstuk 1.2. Nu voegen we de verkoopkant toe.')+
 box('Aanbod','Het verband tussen de prijs van een product en de hoeveelheid die verkopers willen én kunnen aanbieden, terwijl alle andere omstandigheden gelijk blijven. Die afspraak heet **ceteris paribus**.','definition')+
 p('De **aangeboden hoeveelheid** is één hoeveelheid bij één bepaalde prijs, in een afgesproken periode. Een aanbodlijn laat zulke plannen zien bij meerdere prijzen. Het gaat nog niet om het aantal producten dat werkelijk wordt verkocht.'))
 at(s,3)
 page(s,'Van verkoopplan naar lijn',p('Een atelier onderzoekt zijn aanbod van kleine plantenpotten. De techniek, de prijzen van klei en energie en de beschikbare werktijd blijven gelijk. Bij deze vergelijking schrijven we **q** voor de hoeveelheid van dit ene atelier.')+
 table(['P (€ per pot)','4','6','8','10','12'],[['q (potten per week)','0','10','20','30','40']])+
 p('Bij € 8 wil en kan het atelier 20 potten aanbieden. Bij € 10 zijn dat er 30. Zet q horizontaal en P verticaal. De coördinaten zijn dus **(20; 8)** en **(30; 10)**. In dit model verbinden we de tabelpunten met een rechte lijn.')+
 fig('1.3.1_fig_2','Figuur 2 · De stijgende lijn beschrijft dit atelier, niet de vraag naar zijn potten.')+
 box('Dezelfde gegevens in een formule','q = 5P − 20<br/>Geldig voor 4 ≤ P ≤ 12.','formula')+
 p('Bij P = 8: q = 5 × 8 − 20 = **20 potten per week**. Elke euro prijsstijging vergroot hier de aangeboden hoeveelheid met 5 potten. De stap van S naar T is een **beweging langs** dezelfde aanbodlijn.'))
 at(s,4)
 page(s,'Een andere prijs of andere omstandigheden?',p('Nu stijgt de prijs van klei. Vergelijk eerst bij **dezelfde verkoopprijs van € 8**. Het atelier wil en kan dan nog 10 potten aanbieden, in plaats van 20. De nieuwe lijn ligt links van de oude. Bij eenzelfde hoeveelheid is voortaan een hogere prijs nodig.')+
 fig('1.3.1_fig_3','Figuur 3 · Duurdere klei verandert het aanbod bij verschillende verkoopprijzen. Dat is een verschuiving van A₀ naar A₁.')+
 table(['Verandering, overige omstandigheden gelijk','Aanbod bij dezelfde verkoopprijs'],[
 ['Klei of energie wordt duurder.','Minder aanbod: naar links.'],['Een betere techniek maakt produceren gemakkelijker.','Meer aanbod: naar rechts.'],['Er komen meer aanbieders op de markt.','Meer marktaanbod: naar rechts.']])+
 box('Welke prijs verandert?','De prijs van **het product zelf** veroorzaakt een beweging langs de lijn. De prijs van **een productiemiddel** kan de lijn verschuiven. Een pot en de klei voor die pot zijn niet hetzelfde product.','warning')+
 p('De getekende functie is alleen een model binnen de opgegeven prijzen. Onder € 4 biedt het atelier in het eerste model niets aan. Een negatieve formule-uitkomst is daar **geen negatief aanbod**. Aanbodlijnen hoeven niet allemaal dezelfde vorm of beginprijs te hebben.'))
 at(s,5)
 page(s,'Uitgewerkt voorbeeld','## Uitgewerkt voorbeeld\n\n'+
 p('Een kweker levert basilicumtrays. Eerst geldt **q = 4P − 12**, voor 3 ≤ P ≤ 12. q is trays per week; P is euro per tray. De verkoopprijs stijgt van € 6 naar € 8. Tegelijk wordt kweekgrond duurder. Het nieuwe aanbod is **q = 4P − 20**, voor 5 ≤ P ≤ 12. Verder verandert er niets.')+
 p('**1. Eerst alleen de verkoopprijs.** Oud: q = 4 × 6 − 12 = **12**. Bij € 8 en oude omstandigheden: q = 4 × 8 − 12 = **20**. De prijsstijging geeft 8 trays extra: een beweging langs A₀.')+
 p('**2. Daarna alleen de kweekgrond.** Bij de oude prijs van € 6 wordt q = 4 × 6 − 20 = **4**. Duurdere kweekgrond verlaagt hier het aanbod bij elke onderzochte prijs met 8 trays: A verschuift naar links.')+
 fig('1.3.1_we_1','Figuur 4 · R = (12; 6), S = (20; 8), T = (12; 8). De uiteindelijke prijs ligt op de nieuwe aanbodlijn.')+
 p('**3. Combineer.** Nieuwe prijs én nieuwe functie: q = 4 × 8 − 20 = **12 trays per week**. +8 door de prijs en −8 door de kweekgrond heffen elkaar hier op. Dezelfde eindhoeveelheid betekent dus niet dat er niets is veranderd.')+
 p('**4. Controleer de betekenis.** De kweker biedt 12 trays aan. Of hij alle 12 verkoopt, hangt ook af van kopers. Een berekening van aanbod alleen bewijst geen verkoop.'))
 at(s,6)
 PAGES[-1]['body'] += box('Samenvatting §1.3.1','Aanbod beschrijft verkoopplannen bij verschillende prijzen. De eigen verkoopprijs geeft een beweging langs A; productiemiddelen, techniek en het aantal aanbieders kunnen A verschuiven. Vul de juiste prijs in de juiste functie in. In §1.3.2 combineren we aanbod met vraag.','box summary')
 b='## Startopgaven\n\n'
 b+=ex(1,'Een vraagfunctie ophalen','Voor één koper geldt q = 18 − 2P, voor 0 ≤ P ≤ 9. q is stuks per maand; P is euro per stuk.',[
 'Bereken q bij P = € 3.','Bereken P als q = 8. Controleer je antwoord in de functie.'],[
 'q = 18 − 2 × 3 = **12 stuks per maand**. **Waarom:** bij deze prijs hoort dit koopplan in de gegeven vraagfunctie.',
 '8 = 18 − 2P → 2P = 10 → P = **€ 5 per stuk**. Controle: 18 − 2 × 5 = 8. **Waarom:** dezelfde prijs moet de gevraagde hoeveelheid 8 opleveren.'],kind='start')
 b+=ex(2,'Plannen, voorraad en verkoop','Een fietsenmaker heeft 8 binnenbanden op voorraad. Hij wil en kan deze middag bij € 12 per vervanging 5 binnenbanden vervangen. Er komen maar 3 klanten.',[
 'Welke hoeveelheid hoort bij zijn aanbodplan, welke bij zijn voorraad en welke bij zijn werkelijke verkoop?'],[
 'Aanbodplan: **5 vervangingen deze middag**. Voorraad: **8 binnenbanden op dit moment**. Verkoop: **3 vervangingen deze middag**. **Waarom:** kunnen en willen aanbieden is iets anders dan al aanwezige onderdelen of uitgevoerde opdrachten.'],kind='start')
 b+=box('Oefenroute',ROUTE,'route')+'\n\n## Begeleide inoefening\n\n'+p(SKIP,'note')
 b+=ex(3,'Houten lepels','Bekijk het volledig ingevulde aanboddiagram van één maker.',[
 'Lees de hoeveelheden bij € 4 en € 6 af.','Is R → S een beweging of een verschuiving? Licht toe.'],[
 'Bij € 4: **6 lepels per week**. Bij € 6: **12 lepels per week**. **Waarom:** de hulplijnen verbinden iedere prijs met een punt op dezelfde aanbodlijn.',
 '**Een beweging langs A**, naar een grotere aangeboden hoeveelheid. **Waarom:** alleen de verkoopprijs verandert; de lijn blijft liggen.'],kind='guided',extra=fig('1.3.1_ex_3','Figuur 5 · Lees eerst een afgewerkte voorstelling; de hulplijnen zijn al gegeven.'))
 page(s,'Starten en aflezen',b)
 at(s,7)
 b=ex(4,'Kaarsen en duurdere was','Een kaarsenmaker heeft eerst q = 4P − 8, voor 2 ≤ P ≤ 10. Door duurdere was wordt dit q = 4P − 16, voor 4 ≤ P ≤ 10. q is kaarsen per week; P is euro per kaars.',[
 'Neem de tabel over en vul beide hoeveelheden in. Gebruik de oude en de nieuwe functie afzonderlijk.','Voeg A₁ aan de grafiek toe. Markeer bij € 6 een punt op elke lijn en verklaar de richting van de verschuiving.'],[
 'Bij P = 4: oud 4 × 4 − 8 = **8**, nieuw 4 × 4 − 16 = **0**. Bij P = 6: **16** en **8**. Bij P = 8: **24** en **16 kaarsen per week**. **Waarom:** bij elke onderzochte prijs ligt het nieuwe aanbod 8 kaarsen lager.',
 'A₁ loopt door **(0; 4)** en **(24; 10)**; de vergelijkingspunten zijn **(16; 6)** en **(8; 6)**. A verschuift naar links. **Waarom:** duurdere was verlaagt het aanbod bij dezelfde verkoopprijs.'],kind='guided',extra=table(['P (€ per kaars)','q oud (per week)','q nieuw (per week)'],[['4','…','…'],['6','…','…'],['8','…','…']])+fig('1.3.1_ex_4','Figuur 6 · Alleen A₀ is gegeven. Gebruik twee tabelpunten om A₁ te tekenen.'),ansfig='1.3.1_ans_4')
 b+=ex(5,'Twee prijzen bij granola','De verkoopprijs van granola stijgt. Tegelijk wordt de havermout voor granola duurder. Verder verandert er niets; de grootte van beide effecten is onbekend.',[
 'Wat doet alleen de verkoopprijs met de aangeboden hoeveelheid?','Wat doet alleen de havermoutprijs met de aanbodlijn?','Kun je het uiteindelijke aanbod bepalen?','Beoordeel: “Allebei de prijsstijgingen verschuiven de aanbodlijn.”'],[
 'Een **beweging langs A naar meer aangeboden granola**. **Waarom:** een hogere eigen verkoopprijs maakt aanbieden aantrekkelijker, bij gelijke overige omstandigheden.',
 '**A verschuift naar links.** **Waarom:** havermout is een productiemiddel; bij dezelfde granolaprijs wordt produceren minder aantrekkelijk.',
 '**Niet bepalen uit deze informatie.** De effecten werken tegen elkaar in; hun groottes ontbreken. **Waarom:** de positieve en negatieve hoeveelheidseffecten hoeven niet even groot te zijn.',
 '**Onjuist.** Alleen de havermoutprijs verschuift A. De eigen granolaprijs geeft een beweging langs A. **Waarom:** de twee prijzen horen bij verschillende producten.'],kind='guided')
 page(s,'Begeleide inoefening · aanvullen en vergelijken',b)
 at(s,8)
 b='## Zelfstandige oefening\n\n'+ex(6,'Ansichtkaarten','Eén drukker wil en kan q = 10P − 20 ansichtkaarten per week aanbieden, voor 2 ≤ P ≤ 8. P is euro per kaart. De overige omstandigheden blijven gelijk.',[
 'Bereken q bij € 4 en bij € 6. Leg uit wat het getal 10 in de functie betekent.','Bereken de prijs waarbij de drukker 30 kaarten per week aanbiedt. Controleer.'],[
 'Bij € 4: q = 10 × 4 − 20 = **20 kaarten per week**. Bij € 6: **40 kaarten per week**. Het getal 10 betekent **10 extra kaarten per week per euro prijsstijging**. **Waarom:** het beschrijft de reactie langs deze aanbodlijn.',
 '30 = 10P − 20 → 50 = 10P → P = **€ 5 per kaart**. Controle: 10 × 5 − 20 = 30. **Waarom:** de teruggevonden prijs hoort bij het gewenste aanbodplan.'],kind='independent')
 b+=ex(7,'Wat verandert er bij boeketten?','Onderzoek het marktaanbod van boeketten. Vergelijk per rij alleen de genoemde verandering; de overige omstandigheden blijven gelijk. Neem de tabel over en vul de drie antwoordkolommen in.',[
 'Classificeer alle situaties en benoem de specifieke oorzaak.'],[
 'Eigen boeketprijs daalt: **beweging langs A; aangeboden hoeveelheid daalt; eigen verkoopprijs**. Energie goedkoper: **A naar rechts; meer aanbod bij dezelfde boeketprijs; prijs van een productiemiddel**. Extra bloemisten: **A naar rechts; meer marktaanbod; aantal aanbieders**. Machine valt uit: **A naar links; minder aanbod; verminderde productiemogelijkheden**. **Waarom:** alleen de eerste rij verandert de eigen prijs; de andere rijen veranderen de omstandigheden van het aanbod.'],kind='independent',extra=table(['Gebeurtenis','Beweging of verschuiving?','Richting','Specifieke oorzaak'],[
 ['De boeketprijs daalt.','…','…','…'],['Energie wordt goedkoper.','…','…','…'],['Er komen bloemisten bij.','…','…','…'],['Een sorteermachine valt uit; aanbieders kunnen minder verwerken.','…','…','…']]))
 b+=box('Eén verkoper of de hele markt?','Bij één verkoper gebruiken we hier q. Voor het totale marktaanbod gebruiken we Q<sub>a</sub>. Het aanbod van extra verkopers telt mee in Q<sub>a</sub>, maar hoeft het aanbodplan van één bestaande verkoper niet te veranderen.')
 page(s,'Zelfstandig rekenen en oorzaken benoemen',b)
 at(s,9)
 page(s,'Zelfstandig een verschuiving tekenen',ex(8,'Kaas uit de regio','Voor alle kaasmakers samen geldt eerst Q<sub>a</sub> = 8P − 32, voor 4 ≤ P ≤ 16. Energie wordt goedkoper. Daardoor geldt Q<sub>a</sub> = 8P − 16, voor 2 ≤ P ≤ 16. Q<sub>a</sub> is kilo kaas per week; P is euro per kilo. Verder verandert er niets.',[
 'Bereken het oude en nieuwe aanbod bij € 10 per kilo. Hoe groot is de verandering?','Teken de nieuwe lijn in de figuur. Markeer de twee hoeveelheden bij € 10. Leg uit waarom je bij deze vergelijking dezelfde verkoopprijs gebruikt.'],[
 'Oud: 8 × 10 − 32 = **48 kilo per week**. Nieuw: 8 × 10 − 16 = **64 kilo per week**. Verandering: 64 − 48 = **+16 kilo per week**. **Waarom:** lagere energiekosten verhogen het aanbod bij dezelfde kaasprijs.',
 'A₁ loopt door **(0; 2)** en **(112; 16)**. Markeringen: **(48; 10)** en **(64; 10)**. **Waarom:** door de verkoopprijs gelijk te houden, isoleer je de verandering in de omstandigheden. Het is een verschuiving, niet alleen een beweging.'],kind='independent',extra=fig('1.3.1_ex_8','Figuur 7 · De hoeveelheidsas gaat over de gezamenlijke kaasmakers; de nieuwe lijn ontbreekt.'),ansfig='1.3.1_ans_8')+
 box('Verkoop blijft een andere vraag','De berekende 64 kilo is aangeboden kaas. Zonder informatie over kopers kun je niet stellen dat alle kaas wordt verkocht. “Meer aanbod” is dus geen bewijs van “meer werkelijke afzet”.'))
 at(s,10)
 page(s,'Doeloefening','## Doeloefening\n\n'+ex(9,'Atelier Sprint','Eén atelier maakt sporttassen. Eerst geldt q = 4P − 40, voor 10 ≤ P ≤ 30. q is tassen per maand; P is euro per tas. De verkoopprijs stijgt van € 20 naar € 24. Tegelijk wordt stof duurder. Het nieuwe aanbod is q = 4P − 52, voor 13 ≤ P ≤ 30. Verder verandert er niets.',[
 'Bereken q vóór de veranderingen en na alleen de verkoopprijsstijging. Wat betekent de 4 in de functie?','Welke factor verschuift A? Bereken ter vergelijking het nieuwe aanbod bij de oude prijs van € 20.','Teken A₁. Markeer R (oud), S (alleen hogere verkoopprijs) en T (beide veranderingen), met hun coördinaten.','Bereken de uiteindelijke hoeveelheid en de verandering ten opzichte van het begin. Leg uit hoe de effecten samenwerken of tegenwerken.','Beoordeel: “De hogere verkoopprijs verschuift de aanbodlijn naar rechts.”'],[
 'Oud: 4 × 20 − 40 = **40 tassen per maand**. Alleen prijs: 4 × 24 − 40 = **56 tassen per maand**. De 4 is **4 extra tassen per maand per euro prijsstijging**. **Waarom:** dit is de reactie langs A₀.',
 'De **prijs van stof, een productiemiddel**, stijgt. A verschuift naar links. Bij € 20 nieuw: 4 × 20 − 52 = **28 tassen per maand**. **Waarom:** bij dezelfde verkoopprijs is het nieuwe aanbod 12 tassen lager.',
 'A₁: van **(0; 13)** tot **(68; 30)**. R = **(40; 20)**, S = **(56; 24)**, T = **(44; 24)**. **Waarom:** de uiteindelijke prijs moet in de nieuwe functie worden ingevuld; S hoort nog bij de oude omstandigheden.',
 'Uiteindelijk: 4 × 24 − 52 = **44 tassen per maand**. Verandering: 44 − 40 = **+4 tassen per maand**. De effecten werken tegen elkaar: **+16** door de verkoopprijs en **−12** door de stofprijs. **Waarom:** hier is het positieve prijseffect groter dan de afname door duurdere stof.',
 '**Onjuist:** de verkoopprijs veroorzaakt de beweging R → S langs A₀. Duurdere stof verschuift de lijn naar links. **Waarom:** de eigen verkoopprijs en de prijs van een productiemiddel zijn verschillende oorzaken.'],kind='target',extra=fig('1.3.1_ex_9','Figuur 8 · Gebruik de gegeven beginlijn; voeg de nieuwe lijn en alle markeringen zelf toe.'),ansfig='1.3.1_ans_9'))
 at(s,11)
 b='## Denkertje / Bonusopgave\n\n'+ex(10,'De potten staan er al','Een verkoper heeft voor één laatste marktuur al 40 vazen klaargezet. Hij kan in dat uur niets bijmaken of bijkopen. Een klant zegt: “Bij een hogere prijs moet hij altijd meer kunnen aanbieden.”',[
 'Beoordeel de uitspraak. Beschrijf een aanbodvoorstelling die bij deze korte periode kan passen en noem welke informatie over zijn verkoopbereidheid nog ontbreekt.'],[
 'De bestaande voorraad begrenst het aanbod voor dat uur op **40 vazen**. Een hogere prijs kan geen nieuwe vazen tevoorschijn brengen. Bij prijzen waarbij hij alle 40 wil verkopen, past een verticaal deel bij q = 40. Bij lage prijzen kan hij sommige vazen willen bewaren; dat is niet bekend. De gebruikelijke stijgende voorbeeldlijn is dus niet voor elk product en elke periode verplicht.'],kind='bonus',criteria=['Onderscheidt kunnen aanbieden van willen aanbieden.','Benoemt de vaste beschikbaarheid in het laatste uur.','Maakt de voorgestelde lijn afhankelijk van verkoopbereidheid; claimt geen universele verticale aanbodlijn.'])
 b+='\n\n## Herhaling / Herhaling en interleaving\n\n'+ex(11,'Twee korte terugblikken','Gebruik wat je in hoofdstuk 1.1 en 1.2 hebt geleerd.',[
 'Een prijs stijgt van € 8 naar € 10. Bereken de procentuele verandering.','Koper A vraagt bij € 3 twee liter sap per week en koper B vijf liter. B is al in de bron opgenomen. Bereken de collectieve vraag van deze twee kopers.'],[
 '(10 − 8) / 8 × 100% = **25% stijging**. **Waarom:** de oude prijs van € 8 is de vergelijkingsbasis. Herhaal zo nodig §1.1.2.',
 'Q = 2 + 5 = **7 liter per week**. **Waarom:** tel hoeveelheden bij dezelfde prijs op en tel elke koper één keer. Herhaal zo nodig §1.2.3.'],kind='review')
 b+=box('Van plannen naar transacties','Je kent nu beide kanten van de markt. In §1.3.2 zoeken we de prijs waarbij de gezamenlijke koopplannen en verkoopplannen op elkaar aansluiten.')
 page(s,'Denkertje en herhaling',b)
 for lab,e,v in [('potten q bij8','5*8-20',20),('grond gecombineerd','4*8-20',12),('lepels6','3*6-6',12),('kaars6oud','4*6-8',16),('kaars6nieuw','4*6-16',8),('kaasnieuw','8*10-16',64),('Sprint begin','4*20-40',40),('Sprint alleenprijs','4*24-40',56),('Sprint alleenstof','4*20-52',28),('Sprint beide','4*24-52',44)]:ck(lab,e,v)
