from author_common import ROOT,p,box,table,write_pages
from pathlib import Path
import json,hashlib

def make():
 E=json.loads((ROOT/'QA/exercises.json').read_text()); pages=[]
 def pg(t,b):pages.append({'section':'Docenteninformatie','title':t,'body':b})
 pg('Gebruik en afbakening','<p class="kicker">BOEK 1 · HOOFDSTUK 3 · TWEEDE EDITIE</p><h1>Docenteninformatie<br/>Aanbod en marktevenwicht</h1>'+
 p('Deze nieuwe editie volgt **book-1-outline-second-edition-v1.md** uit de conversatie, met de door de gebruiker bevestigde productieopdracht. De eerste editie wordt niet gewijzigd. De oudere registerdoelen worden niet stilzwijgend als doelen van deze nieuwe editie overgenomen.')+
 table(['Onderdeel','Studentpagina’s','Opgaven','Doeloefening'],[['1.3.1 Aanbod en aanbodfactoren','2–11','1–11','9'],['1.3.2 Marktevenwicht','12–23','12–22','20'],['1.3.3 Nieuw evenwicht','24–33','23–33','31'],['1.3.4 Gemengde opgaven','34–38','34–38','37'],['Naslag','39–40','—','—']])+
 box('Omvang en status',f'**40 studentpagina’s**, 38 opgaven en {sum(len(e["questions"]) for e in E)} deelvragen. Drie uitgewerkte voorbeelden en vier nieuw geschreven doeloefeningen. De instructietekst, voorbeelden, bronnen en opgaven zijn voor deze editie geschreven. De doeloefeningen zijn geen automatisch goedgekeurde vervanging van de live repositoryregistratie.')+
 p('De tekst heeft een complete papieren route. Berekeningen en tekeningen komen in het schrift; een rekenmachine en liniaal volstaan. Tijdschattingen en antwoordmodellen staan niet in de studenttekst.')+
 box('Voorkennis die wel en niet wordt verondersteld','Uit 1.1: procenten, indexen, assen en schalen, substitutie, terugrekenen en oppervlakte. Uit 1.2: vraag, ceteris paribus, de eigen prijs versus een vraagfactor en lineaire vraagfuncties. **Nieuw:** aanbodbetekenis, het twee-zijdige evenwicht en het aanpassen van de marktprijs. Kostenstructuren, MK en formele surplusanalyse zijn nog niet geleerd.')+
 p('De lesplanning hieronder bevat zeven kernlessen. Reken bij eerste gebruik op **7–9 lessen** wanneer leerlingen meer steun bij algebra of grafieken nodig hebben. Dit zijn ontwerpschattingen, geen gemeten uitvoerbaarheid of leereffecten.'))
 pg('Doelen en bewijslijn · aanbod', '<h1>Doel–opgavenafstemming</h1><h2>§1.3.1 Aanbod en aanbodfactoren</h2>'+
 table(['Doel / doelhandeling','Expliciete uitleg','Voorbeeld en start','Begeleid','Zelfstandig / doel'],[
 ['Aanbod uitleggen; voorraad en verkoop onderscheiden','p. 2 en 9; actorvergelijking fig. 1','Basilicum, stap 4; start 2','3 aflezen','7 en 8; 9 interpreteert aanbod, niet verkoop'],
 ['Hoeveelheid bij prijs en coefficient verklaren','p. 3; q = 5P − 20','Basilicum, stap 1; start 1','3–4','6; doel 9a'],
 ['Eigen verkoopprijs versus productiemiddelprijs','p. 3–4; vergelijking bij dezelfde P','Basilicum, stappen 1–3','4 nieuwe lijn; 5 twee veranderingen','7–8; doel 9b–e'],
 ['Grafische verschuiving met gegeven beginlijn','Fig. 3 en 4','Voorbeeld toont drie punten','3 compleet → 4 alleen beginlijn → 5 woorden','8 beginlijn → doel 9 beginlijn']])+
 p('De doelen volgen de nieuwe opzet. Een eigen prijsverandering kan aanbod veranderen langs dezelfde lijn; dat is niet hetzelfde als een verandering van de lijn zelf. “Kosten stijgen” wordt hier alleen gebruikt als verklaring bij een gegeven bron, niet als les in vaste en variabele kosten.')+
 box('Lezen vóór produceren','Opgave 3 bevat een ingevulde figuur. Opgave 4 behoudt alleen de oorspronkelijke lijn, waarna de leerling een nieuwe lijn tekent. Opgave 5 vraagt dezelfde onderscheidingen zonder grafiek. Opgave 8 en doel 9 bewaren de beginlijn omdat de doelhandeling een gegeven voorstelling aanvult.')+
 box('Doel 9 · verwachte kernuitkomst','40 → 56 tassen bij alleen de verkoopprijs; 28 bij alleen duurdere stof en de oude prijs; 44 na beide veranderingen. R = (40; 20), S = (56; 24), T = (44; 24). Netto +4. Dit is geen evenwichtsvraag.')+
 p('De bonus over reeds klaargezette vazen is een kritiek op een universele stijgende aanbodlijn. De vraag staat buiten de kernroute; zij mag niet veranderen in een nieuwe verplichte theorie over capaciteit of verticale aanbodfuncties.'))
 pg('Doelen en bewijslijn · evenwicht', '<h1>§1.3.2 Marktevenwicht</h1>'+
 table(['Doel / doelhandeling','Expliciete uitleg','Voorbeeld en start','Begeleid','Zelfstandig / doel'],[
 ['Evenwicht als gelijke plannen','Tabel p. 12; fig. 9–10','Flessen: (30; 10); start 13','14 compleet diagram','17–18; doel 20a–b'],
 ['Gelijkheid met P aan beide kanten','Volledige bewerkingen p. 14','Flessen p. 17; start 12 haalt terugrekenen op','15 vult gelijkheden aan','17–18; doel 20a'],
 ['Q berekenen én controleren','p. 14; aparte tweede substitutie','p. 17','14–15','17–18; doel 20b'],
 ['Zelf een marktgrafiek tekenen','p. 13 en 17; twee punten per lijn','Uitgewerkte figuur 13','14 lezen → 15 alleen V → 16 zonder figuur','17 zonder figuur; doel 20c'],
 ['Overschotten en verkoop onderscheiden','p. 15–16; expliciete transactieregel','Flessen p. 18; start 13','14 en 16','19; doel 20d'],
 ['Prijsdruk en reacties verklaren','p. 15–16, geen verschuiving door eigen prijs','Voorbeeld p. 18','16','17c, 19; doel 20e']])+
 box('Doel 20 · verwachte kernuitkomst','Evenwicht P = € 12 en Q = 30 bekers per week. Bij P = € 10: Qv = 50, Qa = 20, vraagoverschot 30 en volgens de bron verkoop 20. Opwaartse prijsdruk. De onafhankelijke tekening bevat V, A, E en passende assen en hulplijnen.')+
 p('Werkelijke handel wordt niet universeel gelijkgesteld aan min(Qv, Qa). De teksten geven per geval een afspraak: de kleinste kant vindt een handelspartner en er is geen andere beperking. Bij een aanbodoverschot is aanbod niet noodzakelijk reeds geproduceerde voorraad.')+
 box('Algebra is hier nog onderwijs','De eerste twee-zijdige vergelijking wordt niet als beheerst verondersteld. Laat leerlingen hardop zeggen welke bewerking zij aan **beide kanten** uitvoeren. De controle met de tweede functie is inhoudelijk: koop- en verkoopplannen moeten werkelijk bij elkaar passen.'))
 pg('Doelen en bewijslijn · verandering en integratie','<h1>§§1.3.3–1.3.4</h1>'+
 table(['Doel / doelhandeling','Uitleg / voorbeeld','Begeleid','Zelfstandig / doel'],[
 ['Factor en verschuiving','Meer kopers p. 24; materialen p. 26; aardbeien p. 27','25–26; 27 gecontroleerde dubbele verandering','28–30; 31b en 31e'],
 ['Plannen bij oude prijs → druk','p. 25–27','26c','28b; 31b; 37b'],
 ['Oud/nieuw evenwicht en procenten','p. 25–27; start 23–24','26 met twee controles','28–29; 31a–c; 36–37'],
 ['Nieuwe lijn en beweging op andere lijn','Fig. 17–20','25 vol → 26 basis → 27 woorden','29 basis; 31d; 36/37 zelfstandige constructie'],
 ['Bronnen combineren; begrensde claim','Alle voorgaande lessen','Gerichte terugverwijzingen op p. 35','34–36; doel 37a–f'],
 ['Book 2-rekengereedschap','Eerder geleerd in hoofdstuk 1.1','Niet opnieuw als theorie aangeboden','22, 33 en 38']])+
 box('Doel 31 · verwachte kernuitkomst','Oud € 12 / 40 kabels; nieuw € 14 / 50 kabels. Bij oude prijs na de verandering: 60 gevraagd en 40 aangeboden. Q stijgt 25%. V verschuift; de prijsreactie is een beweging op A.')+
 box('Doel 37 · verwachte kernuitkomst','Oud € 10 / 80 tassen; nieuw € 12 / 60 tassen. P +20%, Q −25%. Bij de aparte prijs € 14 na de kostenverandering: vraag 40, aanbod 80, aanbodoverschot 40 en verkoop 40. De vraagfunctie is niet veranderd.')+
 p('Opgave 27 is een begrensde, expliciet aangekondigde vergelijking met twee verschuivingen. Zij vraagt geen matrix van alle combinaties en geen ontbrekende getallen. Opgave 32 is optionele modelkritiek. De dubbele-verschoven situatie wordt niet heimelijk aan doel 31 toegevoegd.')+
 p('In de gemengde paragraaf zijn de driehoek en per-eenheidberekening zuivere herhaling. Er is geen nieuw begrip consumentensurplus, producentensurplus, marginale kosten of welvaartsverlies nodig om 38 te beantwoorden.'))
 lessons=[
 {'les':1,'fase':'Aanbod: actor, functie en hoeveelheid','work':'p. 2–3; voorbeeld p. 5 stap 1; opg. 1–2, 6 en 9a','minutes':[4,12,5,3,12,7,5],'parts':['start 1','uitleg','voorbeeld','overgang/samenvatting','zelfstandig 6 + startcheck 2','doel 9a + interpretatie','feedback']},
 {'les':2,'fase':'Aanbodfactoren en gecombineerde verandering','work':'p. 4–5; 2, 7–8 en volledige 9','minutes':[4,9,6,2,14,14,5],'parts':['start 2','uitleg','voorbeeld','samenvatting','zelfstandig 7–8','doel 9','feedback']},
 {'les':3,'fase':'Evenwicht: tabel, grafiek en algebra','work':'p. 12–14 en 17; 12–13, 17a–b, 20a–c','minutes':[6,13,7,2,12,11,4],'parts':['start 12–13','uitleg','voorbeeld','samenvatting','zelfstandig 17a–b','doel 20a–c','feedback']},
 {'les':4,'fase':'Overschotten, transacties en prijsdruk','work':'p. 15–16 en 18; 12–13, 18–19, 20d–e','minutes':[7,10,5,2,12,10,4,5],'parts':['start 12–13','uitleg','voorbeeld','samenvatting','zelfstandig 18–19','doel 20d–e','terugkoppeling 20a–c','feedback']},
 {'les':5,'fase':'Bron, verschuiving en nieuwe berekening','work':'p. 24–27; 23–24, 28, 31a–c','minutes':[6,14,6,2,10,11,5],'parts':['start 23–24','uitleg','voorbeeld','samenvatting','zelfstandig 28','doel 31a–c','feedback']},
 {'les':6,'fase':'Verschuiving en beweging zichtbaar maken','work':'fig. 18–20; 23–24, 29–30, volledige 31','minutes':[5,7,6,2,14,14,5],'parts':['start 23–24','uitleg/contrast','voorbeeldfiguur','samenvatting','zelfstandig 29–30','doel 31','feedback']},
 {'les':7,'fase':'Gemengde bronnen zelfstandig verwerken','work':'33b, 34b, 35b; bronnen p. 36 en volledige 37','minutes':[3,2,6,4,30,8],'parts':['ophalen 33b','oriëntatie','34b + 35b','bronnen lezen','doel 37','feedback']}
 ]
 for l in lessons:l['total']=sum(l['minutes'])
 (ROOT/'QA/lesson_minutes.json').write_text(json.dumps(lessons,ensure_ascii=False,indent=2))
 pg('Zeven volledige kernlesplannen','<h1>Lesplanning · 55 minuten</h1>'+
 p('De volgorde van de gedrukte koppen blijft intact. De docent kan de voorkennisvraag aan het begin van de les laten maken. Langere paragrafen zijn **twee onderwijsfasen**, niet één les met verzwegen overloop. Een deeldoel in de eerste fase vervangt de volledige doelcontrole niet.')+
 table(['Les en fase','Geselecteerde bladzijden en opgaven','Totale minuten'],[[str(l['les'])+' · '+l['fase'],l['work'],str(l['total'])] for l in lessons])+
 '<div class="small">'+''.join(p('**Les '+str(l['les'])+':** '+' + '.join(str(m)+' '+t for m,t in zip(l['minutes'],l['parts']))+' = **'+str(l['total'])+' minuten**.') for l in lessons)+'</div>'+
 box('Steun kost echte tijd','Begeleide inoefening is niet bovenop een volle kernles gepland. Opgaven 3–5, 14–16 en 25–27 kunnen vooraf, bij een extra instructiemoment of in een extra les worden gebruikt. Laat daarna de relevante zelfstandige handeling en het doel nog steeds uitvoeren. Bij behoefte aan deze route zijn 8–9 lessen realistischer dan alles versnellen.')+
 p('Aanvullend werk: bonus 10, 21 en 32 is optioneel. Herhaling 11, 22, 33 en 38 past als gerichte huiswerkselectie. Opgave 36 levert aanvullende zelfstandige grafiekevidentie; zij is niet ook verplicht binnen les 7.','note'))
 pg('Veelgemaakte fouten en docentinterventies','<h1>Fouten die de les kan blootleggen</h1>'+
 table(['Leerlinguitspraak','Korte docentvraag','Herstel in de tekst'],[
 ['“Aanbod is wat er op de plank ligt.”','Gaat dit getal over een moment, een plan bij een prijs of een verkoop?','p. 2 en 16; opg. 2'],
 ['“Als een prijs stijgt, verschuift A.”','De prijs van welk product: de tas of de stof?','p. 4–5; opg. 5 en 9'],
 ['“50 vraag + 50 aanbod = 100 verkopen.”','Wie koopt de 50 producten die verkocht worden?','p. 13; opg. 13'],
 ['“Qᵥ = 0 geeft de evenwichtsprijs.”','Waar staat aanbod in die vergelijking?','p. 14; opg. 18'],
 ['“Het tekort is het aantal dat wordt verkocht.”','Wat ontbreekt, en wat is er wel beschikbaar?','p. 15 en 18; opg. 19'],
 ['“Het nieuwe evenwicht verschuift beide lijnen.”','Welke omstandigheden veranderen volgens de bron?','p. 25–27; opg. 31'],
 ['“Twee tegengestelde prijsreacties heffen elkaar op.”','Staat ook in de bron dat de effecten even groot zijn?','opg. 27'],
 ['“Evenwicht betekent iedereen tevreden.”','Worden behoeften gemeten, of koopplannen bij één prijs?','p. 16; opg. 21 en 37']])+
 p('Een correcte numerieke uitkomst kan samengaan met een onjuiste verklaring. Controleer daarom minstens één volledige zin: **oorzaak, actor, mechanisme en uitkomst**. Alleen “naar links” is onvoldoende bij een leg-uitvraag.')+
 box('Taal en modelgrenzen','Gebruik “aangeboden hoeveelheid neemt toe” voor een eigen-prijsreactie en “aanbodlijn verschuift naar rechts” voor een factorverandering. Verwar vraagoverschot niet met schaarste, aanbodoverschot niet met reeds geproduceerde voorraad, en evenwicht niet met efficiëntie of eerlijkheid.')+
 p('De voorbeeldlijnen hebben positieve prijsassnijpunten om de eerste algebra overzichtelijk te houden. Dat is een ontwerpkeuze, geen wet dat elke aanbodlijn verplicht dezelfde vorm moet hebben. De opzet is op dat punt leidend boven een te algemene oude grafiekregel.'))
 pg('Handoff naar Boek 2','<h1>Wat Boek 2 mag ophalen</h1>'+
 table(['Book 2-ingang','Zelfstandig zichtbaar in dit hoofdstuk','Nog nieuw in Boek 2'],[
 ['Functie invullen en terugrekenen','6; 9; 20a–b; 33b','Economische betekenis van kostenfuncties en gemiddelde kosten'],
 ['Gelijkheid van twee relaties','17, 18, 20; opnieuw 28, 31, 36, 37','Waarom bij break-even TO = TK wordt gebruikt'],
 ['Totaal versus per eenheid','33a; 38a–b','Vaste/variabele/gemiddelde/marginale kosten'],
 ['Percentagebasis en teken','11a; 22a; 23; 28c; 31c; 37c; 38c','Ev, Ei, Ek en hun interpretatie'],
 ['Vraag, aanbod en marktevenwicht','17, 20, 31 en 37; assnijpunten 33b','Surplusgebieden en hun economische betekenis'],
 ['Driehoeksoppervlakte','22b; 38d, met hoogte 6 − 2','CS, PS, totaal surplus, welvaartsverlies en Pareto-oordelen']])+
 p('Dat een opgave in een boek staat, bewijst nog geen beheersing bij alle leerlingen. Gebruik daadwerkelijk gemaakt werk om de terugblik te kiezen. De antwoorden geven gerichte verwijzingen; een zelfinschatting of afgevinkt leerdoel is geen automatische diagnose.')+
 box('Geen vooraf ingekorte vervolglessen','De naam “surplus” op de slotpagina kondigt alleen Boek 2 aan. De meetkunde-oefening op p. 38 maakt niemand al bekwaam in surplusselectie. Ook de algebra van evenwicht vervangt de nieuwe economische uitleg bij break-even niet.')+
 p('Voor de latere boeken blijven de bestaande paragraafnummers bruikbaar. Het nieuwe hoofdstuk onderwijst het uitgangsmodel voor belastingen, subsidies en prijsrestricties, maar voegt die interventies niet alvast toe aan deze kernroute.')+
 box('Printen en samenstellen','A4 op ware grootte; dubbelzijdig over de lange zijde. Het hoofdstuk telt 40 pagina’s. De gemengde doelbronnen en vragen staan op **36–37** en vormen een linker-/rechterspread. Antwoorden en deze docenteninformatie blijven buiten de studentbundel.'))
 pg('Bronnen, productie en toetsbare controles','<h1>Bronnen en productie</h1>'+
 p('**Inhoudelijke structuur:** de tweede-editieopzet uit deze conversatie, §7 (1.3.1–1.3.4), plus de rekenprogressie en de grens naar Boek 2. Het bronpakket bewaart die opzet ongewijzigd. De tweede-editiemanuscripten van hoofdstuk 1 en 2 zijn gecontroleerd voor werkelijk eerder aangeleerde notatie en vaardigheden.')+
 table(['Repositorybron','Gebruik in deze productie'],[
 ['RESEARCH_AGENT_MAP.md in beide repositories','Navigatie en onderscheid tussen product en bouwlogica. Beide kaarten waren via de connector bereikbaar.'],
 ['skills/econ-exercise-builder.md','Doelgericht ontwerpen, zeven koppen, begeleide route en antwoordconstructie.'],
 ['skills/econ-textbook-paragraph.md','Probleem eerst, concrete uitleg, samenvatting en papierroute.'],
 ['skills/econ-didactiek.md','Geleidelijk minder steun, herkenbare contexten en modelgrenzen.'],
 ['skills/economic-graph.md','Controleerbare coördinaten, assen, eenheden en leesbare figuren.']])+
 p('De genoemde productierichtlijnen sluiten de al gedrukte eerste editie uit van retroactieve aanpassing. Deze opdracht betreft expliciet een **nieuwe editie**. De nieuwe outline stuurt de doelen; de huidige richtlijnen sturen de opbouw van het materiaal. Er is niets in de repositories gewijzigd.')+
 box('Controleerbare oplevering','Het bronpakket bevat vraag–antwoordrecords, de vier doeloefeningen, numerieke modelcontroles, SVG-geometriecontroles, paginakaarten, links en controles op bron-/figuurdekking. De PDF’s zijn tekst- en vectorbestanden, geen scans. De gegenereerde pagina’s worden gerenderd en visueel beoordeeld; de resultaten staan in QA.')+
 p('Er wordt geen onafhankelijke externe review, volledige CE-audit of klasexperiment geclaimd. De checks bewaken de concrete bestandsonderdelen en berekeningen; zij bewijzen geen toekomstige leerwinst. Bereikbare GitHub-bronnen en hun blob-identiteiten zijn vastgelegd in sources/source-register.json.')+
 p('Bewerken: pas de Markdownmanuscripten aan en draai build.py. Volledige regeneratie: build_all.py hermaakt vanuit de author_*.py-bestanden ook de teksten, figuren en metadata. Deze twee werkwijzen zijn bewust gescheiden; een volledige regeneratie overschrijft directe Markdownwijzigingen.','note'))
 write_pages(ROOT/'Docenteninformatie.md',pages)
 print('Teacher:',len(pages),'designed pages; lesson totals',[l['total'] for l in lessons])
if __name__=='__main__':make()
