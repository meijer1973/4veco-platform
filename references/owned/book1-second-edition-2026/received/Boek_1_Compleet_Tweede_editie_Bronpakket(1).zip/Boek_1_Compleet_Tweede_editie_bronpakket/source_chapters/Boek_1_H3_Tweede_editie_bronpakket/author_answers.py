"""Assemble answer pages from the question-linked authored answer records."""
from author_common import ROOT, p, box, fig, table, write_pages
import json

def make():
 data=json.loads((ROOT/'QA/exercises.json').read_text()); E={e['number']:e for e in data};pages=[]
 def answer(n,lo=0,hi=None,showfig=True,cont=False):
  e=E[n];hi=len(e['answers']) if hi is None else hi
  h=f'<h3 id="answer{n}"'+('' if not cont else ' class="continuation"')+f'>Opgave {n} · {e["title"]}'+(' (vervolg)' if cont else '')+'</h3>'
  for i in range(lo,hi):
   a=e['answers'][i]
   # Keep the explanation visible while retaining the exact authored wording.
   h+=f'<div class="answer-item">'+p(f'**{chr(97+i)}.** '+a)+'</div>'
  if showfig and e['answer_figure']:
   h+=fig(e['answer_figure'],f'Antwoordfiguur bij opgave {n} · Assen, lijnen en coördinaten volgen het lesmodel.')
  if e['criteria']:
   h+=box('Beoordelingscriteria','<ul>'+''.join('<li>'+c+'</li>' for c in e['criteria'])+'</ul>','box summary')
  return h
 def pg(title,b,sec='Antwoorden'):
  pages.append({'section':sec,'title':title,'body':b})
 pg('Antwoorden en werkwijze','<p class="kicker">BOEK 1 · HOOFDSTUK 3 · TWEEDE EDITIE</p><h1>Antwoorden<br/>Aanbod en marktevenwicht</h1>'+p('Geef bij iedere uitkomst de juiste eenheid en periode. Reken zo lang mogelijk exact. Rond een percentage zo nodig af op één decimaal en een prijs op twee decimalen. De hoofdgevallen zijn zo gekozen dat evenwichten exact uitkomen.')+
 box('Gebruik de uitwerking','Controleer eerst de gebruikte functie en de beginsituatie, daarna de berekening en de uitleg. Een grafiek mag een andere bruikbare schaal hebben, maar moet dezelfde coördinaten tonen. Andere formuleringen zijn goed als de oorzaak en de economische betekenis kloppen.')+
 table(['Paragraaf','Opgaven'],[['1.3.1 Aanbod','1–11'],['1.3.2 Marktevenwicht','12–22'],['1.3.3 Nieuw evenwicht','23–33'],['1.3.4 Gemengde opgaven','34–38']])+answer(1)+answer(2))
 pg('1.3.1 · Aflezen en een lijn aanvullen',answer(3)+answer(4))
 pg('1.3.1 · Twee prijzen en oorzaken',answer(5)+answer(6)+answer(7))
 pg('1.3.1 · Marktaanbod van kaas',answer(8)+box('Wat deze bron niet vastlegt','De uitkomst 64 kilo is aangeboden hoeveelheid, geen bewezen verkoop. Evenwicht wordt pas onderzocht wanneer ook de koopplannen op de markt bekend zijn.'))
 pg('1.3.1 · Doeloefening Atelier Sprint',answer(9))
 pg('1.3.1–1.3.2 · Begrippen en ophalen',answer(10)+answer(11)+answer(12)+answer(13))
 pg('1.3.2 · Begeleide inoefening',answer(14)+answer(15))
 pg('1.3.2 · Zelfstandig construeren',answer(16)+answer(17))
 pg('1.3.2 · Evenwicht of een assnijpunt?',answer(18)+answer(19)+answer(20,0,2,False))
 pg('1.3.2 · Doeloefening: grafiek en transacties',answer(20,2,5,True,True))
 pg('1.3.2–1.3.3 · Betekenis en startwerk',answer(21)+answer(22)+answer(23)+answer(24)+answer(25))
 pg('1.3.3 · Van bron naar nieuw evenwicht',answer(26))
 pg('1.3.3 · Twee oorzaken en een berekening',answer(27)+answer(28))
 pg('1.3.3 · Zelfstandig tekenen',answer(29)+answer(30))
 pg('1.3.3 · Doeloefening oplaadkabels',answer(31))
 pg('1.3.3 · Verklaren en herhalen',answer(32)+answer(33))
 pg('1.3.4 · Marktplannen combineren',answer(34)+answer(35))
 pg('1.3.4 · Oude en nieuwe functie',answer(36))
 pg('1.3.4 · De linnen tas: berekeningen',answer(37,0,3,False))
 pg('1.3.4 · De linnen tas: grafische onderbouwing',answer(37,3,4,True,True)+box('Coördinaten lezen','De horizontale verschuiving bij € 10 vergelijkt aanbodplannen bij dezelfde prijs. De stap langs V van E₀ naar E₁ laat de reactie van kopers op de hogere prijs zien. De twee pijlen stellen dus verschillende veranderingen voor.'))
 pg('1.3.4 · Conclusies en rekengereedschap',answer(37,4,6,False,True)+answer(38))
 write_pages(ROOT/'Antwoorden.md',pages)
 print('Answers',len(pages),'designed pages')
if __name__=='__main__':make()
