from author_common import *
import author_131,author_132,author_133,author_134

def make():
 at('1.3',1)
 contents='<div class="contents">'
 for ref,t,pg in [('1.3.1','Aanbod en aanbodfactoren',2),('1.3.2','Marktevenwicht: prijs en hoeveelheid',12),('1.3.3','Verschuivingen en nieuw evenwicht',24),('1.3.4','Gemengde opgaven',34)]:
  contents+=f'<a href="#p{ref.replace(".","")}"><b>{ref} <span>{pg}</span></b>{t}</a>'
 contents+='</div>'
 page('1.3','Aanbod en marktevenwicht','<p class="kicker">BOEK 1 · HOOFDSTUK 3 · TWEEDE EDITIE</p><h1 class="cover-title">Aanbod en<br/>marktevenwicht</h1><p class="lead">Hoe vinden de plannen van kopers en verkopers elkaar?</p>'+contents+
 goals(['aanbodplannen lezen, berekenen en verklaren;','vraag en aanbod combineren tot één marktevenwicht;','tekorten, overschotten en werkelijke transacties onderscheiden;','een veranderd evenwicht uit een bron, berekening en grafiek uitleggen;','een economische uitspraak onderbouwen zonder meer te beweren dan de gegevens toelaten.'],'Na dit hoofdstuk kun je')+
 p('Een marktprijs lijkt één getal. Toch zitten daar heel veel keuzes achter. Kopers wegen af hoeveel ze willen kopen; verkopers hoeveel zij willen aanbieden. Je onderzoekt wanneer die plannen passen en wat er gebeurt als een van beide kanten verandert.')+
 box('Zo werk je','Lees de uitleg en het uitgewerkte voorbeeld. Maak daarna de Startopgaven. De Begeleide inoefening biedt extra steun; de Zelfstandige oefening en Doeloefening laten je de methodes zelf gebruiken. Maak berekeningen en tekeningen in je schrift.')+
 p('Alle situaties en getallen in dit hoofdstuk zijn voor het onderwijs gemaakte modellen. Prijzen, aantallen en conclusies gelden onder de voorwaarden van de betreffende bron.','school-note'))
 author_131.make();author_132.make();author_133.make();author_134.make()
 at('Overzicht',39)
 page('Overzicht','Hoofdstukoverzicht','<h1 id="overzicht">Hoofdstukoverzicht</h1>'+
 table(['Vraag','Werkwijze','Controle'],[
 ['Hoeveel wordt aangeboden?','Vul de gegeven P in de juiste aanbodfunctie in.','Past P binnen de opgegeven voorwaarden? Eenheid per periode?'],
 ['Wat is het evenwicht?','Stel Qᵥ = Qₐ, los P op en bereken Q.','Vul P in beide oorspronkelijke functies in.'],
 ['Is er een overschot?','Bereken beide plannen bij dezelfde prijs; neem het positieve verschil.','Qᵥ > Qₐ: vraagoverschot. Qₐ > Qᵥ: aanbodoverschot.'],
 ['Hoeveel wordt werkelijk verkocht?','Gebruik de transactieregel uit de bron.','Kunnen deelnemers elkaar vinden? Andere voorraden of belemmeringen?'],
 ['Waarom verandert het evenwicht?','Bron → factor → lijn → plannen bij oude prijs → druk → nieuw evenwicht.','De andere lijn blijft staan; de prijsreactie geeft een beweging erlangs.']])+
 box('Rekenen met een veranderd evenwicht','Verandering in % = (nieuw − oud) / oud × 100%<br/>Gebruik bij prijsverandering de oude prijs en bij hoeveelheidverandering de oude hoeveelheid.','formula')+
 p('**Bij dezelfde prijs vergelijken maakt een verschuiving zichtbaar.** Na een vraagtoename verandert de uiteindelijke hoeveelheid minder dan de vraagtoename bij de oude prijs: de prijs reageert ook. Houd het tijdelijke verschil en de uiteindelijke verandering dus uit elkaar.')+
 box('Drie waarschuwingen','**Eén aanbodplan is geen marktuitkomst.** Daarvoor is ook vraag nodig.<br/>**Een hoger getal is niet automatisch een verschuiving.** Benoem de oorzaak.<br/>**Evenwicht is geen oordeel over eerlijkheid.** Het betekent dat de plannen bij die prijs aansluiten.','warning')+
 p('Vraag en aanbod kunnen allebei naar rechts verschuiven. In het behandelde model neemt Q dan toe; zonder relatieve groottes weet je niet wat P doet. Er is geen extra verschuiving nodig om een reactie op een veranderde prijs te verklaren.'))
 at('Overzicht',40)
 terms=[
 ('Aanbod','Verkoopplannen bij verschillende prijzen, terwijl overige omstandigheden gelijk blijven.'),
 ('Aangeboden hoeveelheid','Het aantal dat verkopers bij één prijs willen en kunnen aanbieden in de genoemde periode.'),
 ('Aanbodfactor','Omstandigheid achter de aanbodlijn, zoals techniek, productiemiddelprijzen of aantal aanbieders.'),
 ('Aanbodoverschot','Bij een prijs is Qₐ groter dan Qᵥ; het verschil is Qₐ − Qᵥ.'),
 ('Beweging langs een lijn','Een andere hoeveelheid op dezelfde lijn door een verandering van de eigen prijs.'),
 ('Ceteris paribus','Alle andere omstandigheden blijven gelijk tijdens de onderzochte vergelijking.'),
 ('Evenwichtshoeveelheid','De hoeveelheid waarbij de koop- en verkoopplannen bij de evenwichtsprijs overeenkomen.'),
 ('Evenwichtsprijs','De prijs waarbij Qᵥ = Qₐ.'),
 ('Marktaanbod','Het aanbod van alle verkopers in de afgebakende markt samen.'),
 ('Marktevenwicht','Gevraagde en aangeboden hoeveelheid zijn bij dezelfde prijs gelijk.'),
 ('Prijsdruk','Een reden voor de prijs om te stijgen of dalen, zoals niet-passende koop- en verkoopplannen.'),
 ('Productiemiddel','Een middel dat bij het maken van een product wordt gebruikt, zoals klei, energie of een oven.'),
 ('Transactie','Een gerealiseerde aankoop en verkoop van hetzelfde product.'),
 ('Verschuiving van een lijn','Een andere hoeveelheid bij dezelfde prijs, door veranderde omstandigheden achter de lijn.'),
 ('Voorraad','De producten of materialen die op een bepaald moment aanwezig zijn.'),
 ('Vraagoverschot','Bij een prijs is Qᵥ groter dan Qₐ; het tekort is Qᵥ − Qₐ.')]
 page('Overzicht','Begrippen en het vervolg','<h1 id="begrippen">Begrippen en het vervolg</h1><div class="glossary-columns">'+''.join('<div class="term">'+p('**'+t+'**<br/>'+d)+'</div>' for t,d in terms)+'</div>'+
 box('Verder in Boek 2','Je neemt functies, percentages, grafieken en het marktmodel mee. **Kosten en opbrengsten, elasticiteit en surplus** krijgen daar hun eigen uitleg. Dat je de rekenvorm al kent, betekent niet dat de nieuwe economische betekenis al bekend is.')+
 p('Gericht herhalen: rekenen en meetkunde → opgave 38; een vraagfunctie → opgave 33b; evenwicht en controle → opgave 20; een verandering verklaren → opgave 31.','note'))
 write_all()
 print('Student:',len(PAGES),'pages;',len(EX),'exercises;',sum(len(e['questions']) for e in EX),'subquestions')
if __name__=='__main__':make()
