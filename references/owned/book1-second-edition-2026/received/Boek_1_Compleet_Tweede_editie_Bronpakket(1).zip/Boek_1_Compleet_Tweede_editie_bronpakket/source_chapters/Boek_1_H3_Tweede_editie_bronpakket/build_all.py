"""Regenerate authoring manuscripts, diagrams, PDFs, checks and section exports.
WARNING: this overwrites edited Markdown. To retain direct Markdown edits, use build.py.
"""
from pathlib import Path
import subprocess, sys
R=Path(__file__).resolve().parent
for name in ['make_assets.py','author_chapter.py','author_answers.py','author_teacher.py','build.py','validate.py','export_paragraphs.py']:
    subprocess.run([sys.executable,str(R/name)],cwd=R,check=True)
