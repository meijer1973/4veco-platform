# Visuele en inhoudelijke eindcontrole

Datum: 9 september 2026. Omvang: student 40 pagina's; antwoorden 21;
docenteninformatie 8. Dit is een lokale auteurscontrole, geen onafhankelijke
externe review of gemeten leerresultaat.

## Werkwijze

Alle pagina's zijn gerenderd met MuPDF en bekeken in opeenvolgende contactbladen.
De figuren en de aangepaste pagina's zijn tevens op groter formaat bekeken.
De studentpagina's 16 en 38 en antwoordpagina 18 zijn aanvullend gerenderd met
Poppler (`pdftoppm`) en visueel bekeken. Geen OCR gebruikt.

## Verbeteringen naar aanleiding van controle

- De samenvattingen bij §§1.3.1 en 1.3.3 staan nu direct bij het uitgewerkte
  voorbeeld. Daardoor breken de volgende start-/begeleide pagina's niet meer
  onbedoeld over. De canonieke volgorde bleef intact; er is geen kleinere
  hoofdtekst gebruikt om de 40 pagina's te halen.
- De lange figuurtitel bij antwoord 9 is ingekort zonder de betekenis te veranderen.
- Het aanbodoverschot op studentpagina 16 heeft een vrijstaande maatpijl boven
  de betrokken hoeveelheden. De hoeveelheidslabels op pagina 15 en 16 staan
  naast in plaats van op de lijnen.
- De antwoordfiguur voor opgave 20 stopt ook voor de aanbodlijn bij de in de bron
  gegeven bovengrens P = 15; de as blijft tot 16 lopen. Asvenster en modelgrens
  worden dus niet verward.
- De twee aanbodlabels en E₀ bij de tentenfiguur (antwoord 36) zijn verplaatst
  naar vrije ruimte; de berekende lijngeometrie bleef gelijk.

## Inhoudelijk bekeken onderscheidingen

Aanbodplan, voorraad en verkoop blijven onderscheiden. Verkoop buiten evenwicht
is alleen berekend onder de per casus genoemde afsprakenset over het vinden van
een handelspartner en het ontbreken van andere beperkingen. Vraag-/aanbodoverschot
is geen automatisch gegeven over daadwerkelijk geproduceerde voorraad.

De eerste tweezijdige vergelijking wordt met gelijke bewerkingen aan beide kanten
uitgelegd en in beide functies gecontroleerd. Bij een verandering wordt eerst bij
de oude prijs vergeleken. Een autonome verschuiving en de latere prijsreactie
langs een ongewijzigde lijn worden afzonderlijk benoemd. De aparte prijsvergelijking
in bron C van de mixed target behoudt uitdrukkelijk de nieuwe aanbodfunctie.

Alle vier nieuwe targets hebben bijbehorende uitleg en oefening. Onafhankelijk
tekenen wordt gevraagd waar de betreffende bron geen grafiek levert; waar een
beginfiguur is meegeleverd blijft die bron aanwezig en voegt de leerling de
gevraagde lijn en markeringen toe. De extra meetkunde en per-eenheidberekeningen
op p. 38 zijn terugblik op hoofdstuk 1.1, geen nieuwe surplus- of kostentheorie.

## Grenzen

Een correcte berekening, gecontroleerde figuur of foutloze paginering bewijst geen
leerlingbeheersing. De zeven kernlessen en 7–9 lessen voor eerste gebruik zijn
ontwerpinschattingen. Definitieve inzet kan naar de klas en het rooster worden aangepast.
