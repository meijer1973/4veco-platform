from author_common import *
def make():
 s='1.3.3';at(s,24)
 page(s,'Een nieuwe situatie, een nieuw evenwicht',title(s,'Verschuivingen en nieuw evenwicht')+
 p('**Er komen meer kopers voor fietshelmen. Waarom stijgt de prijs, maar worden er toch meer helmen verkocht?** Er verandert niet alleen een punt op een lijn. De koopplannen bij verschillende prijzen veranderen.')+
 goals(['een bronverandering koppelen aan vraag of aanbod;','de nieuwe plannen bij de oude prijs vergelijken;','het nieuwe evenwicht berekenen en met het oude vergelijken;','een verschuiving en een beweging langs de ongewijzigde lijn apart uitleggen.'])+
 box('Beginmarkt en verandering','Q<sub>v,0</sub> = 80 − 4P &nbsp; (0 ≤ P ≤ 20)<br/>Q<sub>a</sub> = 4P − 16 &nbsp; (4 ≤ P ≤ 24)<br/>Nieuwe vraag: Q<sub>v,1</sub> = 96 − 4P &nbsp; (0 ≤ P ≤ 24)','formula')+
 p('Q is helmen per week; P is euro per helm. Alleen het aantal kopers neemt toe. Daardoor is de vraag bij iedere onderzochte prijs **16 helmen groter**. De oude evenwichtsprijs is € 12 en de oude hoeveelheid is 32 helmen.')+
 fig('1.3.3_fig_1','Figuur 17 · Bij € 12 verschuiven de koopplannen van 32 naar 48. Verkopers bieden bij die prijs nog 32 aan.')+
 p('**Begin bij de oorzaak.** Meer kopers verschuift V naar rechts. Dat wordt zichtbaar door beide vraaglijnen eerst bij **dezelfde prijs** te vergelijken.'))
 at(s,25)
 page(s,'De nieuwe prijs is een gevolg',p('**1. Vergelijk bij de oude prijs.** Bij € 12 vragen de kopers nu 96 − 4 × 12 = **48 helmen**. Het aanbod blijft 4 × 12 − 16 = **32 helmen**. Er ontstaat een vraagoverschot van **16 helmen per week**.')+
 p('**2. Verklaar de druk.** Kopers concurreren om het aanbod: de prijs komt onder opwaartse druk. Door de hogere prijs bewegen verkopers **langs de bestaande aanbodlijn** naar een groter aanbod.')+
 p('**3. Los de nieuwe gelijkheid op.**<br/>96 − 4P = 4P − 16 → 112 = 8P → **P = € 14**.<br/>Q<sub>v,1</sub> = 96 − 4 × 14 = **40**; controle: Q<sub>a</sub> = 4 × 14 − 16 = **40 helmen per week**.')+
 fig('1.3.3_fig_2','Figuur 18 · Dezelfde assen en lijnen als in figuur 17. Van E₀ naar E₁ beweeg je langs A; A zelf verschuift niet.')+
 p('**4. Vergelijk.** De prijs stijgt van € 12 naar € 14 en de hoeveelheid van 32 naar 40. Dat de nieuwe prijs hoger is, spreekt de dalende vraaglijn niet tegen: de twee evenwichten liggen op **verschillende vraaglijnen**.')+
 box('Oorzaak en reactie niet omdraaien','Niet: de hogere prijs verschuift V naar rechts. Wel: meer kopers verschuift V naar rechts; de prijs reageert daarop. Meer aanbod door die hogere prijs is een **beweging langs A**.','warning'))
 at(s,26)
 page(s,'Een aanbodverandering kan óók de prijs verhogen',p('**Een afzonderlijk scenario.** Begin opnieuw bij Q<sub>v</sub> = 80 − 4P en Q<sub>a,0</sub> = 4P − 16. De extra kopers uit de vorige situatie zijn er nu niet. Alleen de materialen voor fietshelmen worden duurder. De aanbodfunctie wordt **Q<sub>a,1</sub> = 4P − 32**, voor 8 ≤ P ≤ 24.')+
 p('Bij de oude prijs van € 12 zijn de nieuwe verkoopplannen **16 helmen**, tegenover 32 gevraagde helmen. Het aanbod is dus naar links verschoven. Het vraagoverschot zet de prijs opnieuw onder opwaartse druk.')+
 fig('1.3.3_fig_3','Figuur 19 · Dit scenario begint opnieuw bij E₀. Door de hogere prijs bewegen kopers langs de ongewijzigde vraaglijn.')+
 p('80 − 4P = 4P − 32 → 112 = 8P → **P = € 14**.<br/>Q<sub>v</sub> = 80 − 4 × 14 = **24**; controle: 4 × 14 − 32 = **24 helmen per week**.')+
 table(['Afzonderlijke oorzaak','Prijs','Verhandelde hoeveelheid'],[['Meer kopers, aanbod gelijk','€ 12 → € 14','32 → 40'],['Duurdere materialen, vraag gelijk','€ 12 → € 14','32 → 24']])+
 p('Dezelfde prijsstijging kan dus bij verschillende oorzaken horen. Kijk ook naar de hoeveelheid en naar de bron. **Alleen een prijswaarneming bewijst niet welke lijn verschoof.**'))
 at(s,27)
 page(s,'Uitgewerkt voorbeeld','## Uitgewerkt voorbeeld\n\n'+p('Voor bakjes aardbeien gelden Q<sub>v</sub> = 40 − 2P (0 ≤ P ≤ 20) en Q<sub>a,0</sub> = 2P − 8 (4 ≤ P ≤ 20). Q is bakjes per dag; P is euro per bakje. Alleen de verpakking wordt duurder. Voortaan geldt Q<sub>a,1</sub> = 2P − 16 (8 ≤ P ≤ 20).')+
 p('**1. Oud evenwicht.** 40 − 2P = 2P − 8 → 48 = 4P → **P₀ = € 12**. Q₀ = 40 − 2 × 12 = **16**. Controle: 2 × 12 − 8 = **16 bakjes per dag**.')+
 p('**2. Oorzaak en oude prijs.** De verpakking is een productiemiddel. Bij € 12 daalt het aanbod naar 2 × 12 − 16 = **8**. De vraag blijft 16. Vraagoverschot: **8 bakjes per dag**; opwaartse prijsdruk.')+
 p('**3. Nieuw evenwicht.** 40 − 2P = 2P − 16 → 56 = 4P → **P₁ = € 14**. Q₁ = 40 − 2 × 14 = **12**. Controle: 2 × 14 − 16 = **12 bakjes per dag**.')+
 fig('1.3.3_we_1','Figuur 20 · A verschuift naar links. De hogere prijs geeft een beweging langs V naar minder gevraagde bakjes.')+
 p('**4. Vergelijk en verklaar.** De hoeveelheid verandert met (12 − 16) / 16 × 100% = **−25%**. De prijs stijgt. De oorspronkelijke oorzaak is duurdere verpakking; de prijsreactie verkleint vervolgens de gevraagde hoeveelheid.'))
 at(s,28)
 PAGES[-1]['body'] += box('Samenvatting §1.3.3','Werk steeds vanuit een duidelijke beginsituatie. Benoem de factor en de verschuivende lijn. Vergelijk de plannen bij de oude prijs en verklaar de druk. Bereken het nieuwe evenwicht en controleer. De prijsreactie veroorzaakt een beweging langs de andere lijn. In §1.3.4 kies je de methode zelf.','box summary')
 b='## Startopgaven\n\n'
 b+=ex(23,'Een verandering vergelijken','Een hoeveelheid stijgt van 320 naar 400 stuks per week.',[
 'Bereken de procentuele verandering.'],[
 '(400 − 320) / 320 × 100% = **25% stijging**. **Waarom:** de oude hoeveelheid is de basis; het verschil van 80 is niet zelf een percentage.'],kind='start')
 b+=ex(24,'Welke oorzaak?','Er komen meer kopers van fietsbellen. De techniek, het aantal verkopers en hun omstandigheden blijven gelijk.',[
 'Welke lijn verschuift? Verschuift de andere lijn ook zodra de marktprijs stijgt?'],[
 '**De vraaglijn verschuift naar rechts.** Een hogere marktprijs geeft daarna een **beweging langs de bestaande aanbodlijn**, geen verschuiving. **Waarom:** de omstandigheden van de aanbieders veranderen niet.'],kind='start')
 b+=box('Oefenroute',ROUTE,'route')+'\n\n## Begeleide inoefening\n\n'+p(SKIP,'note')
 b+=ex(25,'Plantenvoeding','Er komen meer kopers. De figuur toont de volledige uitwerking; het aanbod verandert niet.',[
 'Lees de oude en nieuwe prijs en hoeveelheid af.','Leg uit waarom de grotere aangeboden hoeveelheid hier geen verschuiving van A is.'],[
 'Oud: **€ 12 per fles en 24 flessen per week**. Nieuw: **€ 14 per fles en 30 flessen per week**. **Waarom:** de hulplijnen en schaal verbinden beide evenwichten met hun assen.',
 'De prijs stijgt en verkopers reageren **langs dezelfde A**. **Waarom:** meer kopers verandert de vraag, niet de omstandigheden achter het aanbod.'],kind='guided',extra=fig('1.3.3_ex_25','Figuur 21 · Beide evenwichten en de nieuwe vraaglijn zijn hier al gemarkeerd.'))
 page(s,'Starten en een uitgewerkte verandering lezen',b)
 at(s,29)
 page(s,'Begeleide inoefening · een nieuwe aanbodlijn',ex(26,'Duurder papier voor notitieblokken','Begin met Q<sub>v</sub> = 100 − 5P (0 ≤ P ≤ 20) en Q<sub>a,0</sub> = 5P − 20 (4 ≤ P ≤ 20). Door duurdere papierpulp wordt het aanbod Q<sub>a,1</sub> = 5P − 40 (8 ≤ P ≤ 20). Q is notitieblokken per week; P is euro per blok. Er zijn geen andere veranderingen.',[
 'Bereken het oude en nieuwe evenwicht. Controleer beide hoeveelheden. Gebruik per situatie Qᵥ = Qₐ.',
 'Voeg A₁ toe aan de figuur. Markeer E₀ en E₁. Gebruik twee zelf berekende punten voor de nieuwe lijn.',
 'Bereken bij de oude prijs de nieuwe Qₐ en de ongewijzigde Qᵥ. Leg via het verschil uit waarom de prijs verandert.'],[
 'Oud: 100 − 5P = 5P − 20 → 120 = 10P → **P₀ = € 12**, Q₀ = 100 − 60 = **40**; controle 60 − 20 = 40. Nieuw: 100 − 5P = 5P − 40 → 140 = 10P → **P₁ = € 14**, Q₁ = 100 − 70 = **30**; controle 70 − 40 = **30 blokken per week**. **Waarom:** iedere situatie gebruikt haar eigen aanbodfunctie.',
 'A₁ door **(0; 8)** en **(60; 20)**; E₀ = **(40; 12)**, E₁ = **(30; 14)**. **Waarom:** duurdere papierpulp legt het aanbod bij elke relevante prijs lager, dus de nieuwe lijn ligt links van A₀.',
 'Bij € 12 nieuw: Q<sub>a,1</sub> = 5 × 12 − 40 = **20**; Q<sub>v</sub> = 100 − 5 × 12 = **40**. Vraagoverschot = **20 blokken per week**. **Waarom:** kopers concurreren om het kleinere aanbod; de prijs krijgt opwaartse druk.'],kind='guided',extra=fig('1.3.3_ex_26','Figuur 22 · De beginlijnen zijn gegeven; de verandering en uitkomsten teken je zelf.'),ansfig='1.3.3_ans_26')+
 box('Hulp bij de twee pijlen','Een horizontale vergelijking bij de oude prijs toont de verschuiving. De stap van E₀ naar E₁ ligt op de ongewijzigde vraaglijn. Zet bij iedere pijl welke verandering hij laat zien.'))
 at(s,30)
 b=ex(27,'Meer vraag én meer aanbod','Er komen meer kopers van campinglampen. Tegelijk maakt een betere techniek de productie gemakkelijker. De vraag- en aanbodlijn verschuiven allebei naar rechts. De oorspronkelijke lijnen zijn dalend respectievelijk stijgend. De verschuivingen zijn niet becijferd.',[
 'Wat gebeurt er met evenwichtsprijs en -hoeveelheid als je alleen de extra kopers bekijkt?','Wat gebeurt er als je alleen de betere techniek bekijkt?','Welke richting van de uiteindelijke hoeveelheid is bepaald? Is de richting van de prijs ook bepaald?','Een leerling zegt: “De tegengestelde prijsdruk betekent dat de prijs gelijk blijft.” Waarom volgt dat niet?'],[
 'Alleen meer vraag: **prijs omhoog en hoeveelheid omhoog**. **Waarom:** bij de oude prijs ontstaat een vraagoverschot.',
 'Alleen meer aanbod: **prijs omlaag en hoeveelheid omhoog**. **Waarom:** bij de oude prijs ontstaat een aanbodoverschot.',
 'In dit model neemt de evenwichtshoeveelheid **toe**. De prijs kan **stijgen, dalen of gelijk blijven**. **Waarom:** de hoeveelheidseffecten versterken elkaar; de prijsuitkomst hangt af van de groottes van beide verschuivingen.',
 'De drukken hoeven niet even groot te zijn. **Waarom:** zonder relatieve groottes kun je niet besluiten dat ze elkaar precies opheffen.'],kind='guided')
 b+='\n\n## Zelfstandige oefening\n\n'+ex(28,'Reparatiesets','Q<sub>v,0</sub> = 96 − 4P (0 ≤ P ≤ 24) en Q<sub>a</sub> = 4P − 16 (4 ≤ P ≤ 28). Repareren wordt populairder. Alleen de voorkeur verandert: Q<sub>v,1</sub> = 112 − 4P (0 ≤ P ≤ 28). Q is sets per week; P is euro per set.',[
 'Bereken beide evenwichten en controleer de hoeveelheden.','Vergelijk na de verandering de plannen bij de oude prijs. Verklaar de prijsdruk.','Bereken de procentuele verandering van de evenwichtshoeveelheid.'],[
 'Oud: 96 − 4P = 4P − 16 → 112 = 8P → **€ 14**; Q = 96 − 56 = **40**; controle 56 − 16 = 40. Nieuw: 112 − 4P = 4P − 16 → 128 = 8P → **€ 16**; Q = 112 − 64 = **48**; controle 64 − 16 = **48 sets per week**. **Waarom:** de voorkeur verandert de vraagfunctie, het aanbod blijft staan.',
 'Bij € 14 nieuw: Q<sub>v,1</sub> = 112 − 56 = **56**, Q<sub>a</sub> = 56 − 16 = **40**. Vraagoverschot = **16 sets per week**; opwaartse prijsdruk. **Waarom:** de koopplannen zijn toegenomen voordat de prijs reageert.',
 '(48 − 40) / 40 × 100% = **20% stijging**. **Waarom:** je vergelijkt de twee evenwichtshoeveelheden, niet het tijdelijke vraagoverschot.'],kind='independent')
 page(s,'Twee verschuivingen en zelfstandige berekening',b)
 at(s,31)
 b=ex(29,'Houten speelgoed','Q<sub>v</sub> = 120 − 6P (0 ≤ P ≤ 20) en Q<sub>a,0</sub> = 6P − 24 (4 ≤ P ≤ 20). Door goedkoper hout wordt Q<sub>a,1</sub> = 6P − 12 (2 ≤ P ≤ 20). Q is speelgoedsets per maand; P is euro per set. De overige omstandigheden blijven gelijk.',[
 'Bereken beide evenwichten en controleer. Voeg A₁, E₀, E₁ en hun coördinaten aan de figuur toe.','Leg uit waarom de grotere gevraagde hoeveelheid niet bewijst dat de vraaglijn is verschoven.'],[
 'Oud: 120 − 6P = 6P − 24 → 144 = 12P → **P₀ = € 12**, Q₀ = 120 − 72 = **48**, controle 72 − 24 = 48. Nieuw: 120 − 6P = 6P − 12 → 132 = 12P → **P₁ = € 11**, Q₁ = 120 − 66 = **54**, controle 66 − 12 = **54 sets per maand**. A₁ door (0; 2) en (108; 20); E₀ = (48; 12), E₁ = (54; 11). **Waarom:** lagere houtkosten verhogen het aanbod bij dezelfde prijs.',
 'Kopers reageren op de lagere prijs **langs dezelfde V**. **Waarom:** hun omstandigheden zijn gelijk gebleven; alleen de kosten van de aanbieders zijn veranderd.'],kind='independent',extra=fig('1.3.3_ex_29','Figuur 23 · Teken de verandering en benoem daarnaast de beweging op V.'),ansfig='1.3.3_ans_29')
 b+=ex(30,'Wat past bij de waarneming?','De prijs van kampeermatten stijgt en de verkochte hoeveelheid daalt. Volgens een onderzoek is er precies één verandering: óf materiaal werd duurder, óf de voorkeur voor deze matten nam toe. De andere lijn bleef gelijk.',[
 'Welke van de twee verklaringen past in het standaardmodel? Motiveer met prijs én hoeveelheid.'],[
 '**Duurdere materialen.** Dat verschuift A naar links, waardoor P stijgt en Q daalt. Alleen sterkere voorkeur verschuift V naar rechts en zou P én Q doen stijgen. **Waarom:** de richting van Q onderscheidt hier de twee gegeven verklaringen; de conclusie steunt op de expliciete aanname van één verandering.'],kind='independent')
 page(s,'Zelfstandig tekenen en een bron beoordelen',b)
 at(s,32)
 page(s,'Doeloefening','## Doeloefening\n\n'+ex(31,'Meer kopers van oplaadkabels','Een regionale markt heeft Q<sub>v,0</sub> = 100 − 5P (0 ≤ P ≤ 20) en Q<sub>a</sub> = 5P − 20 (4 ≤ P ≤ 24). Q is kabels per week; P is euro per kabel. Er komen meer kopers. Alleen daardoor wordt Q<sub>v,1</sub> = 120 − 5P (0 ≤ P ≤ 24). De omstandigheden van de aanbieders blijven gelijk.',[
 'Bereken het oude evenwicht en controleer met beide functies.','Benoem de specifieke factor. Bereken na de verandering beide plannen bij de oude prijs en verklaar de prijsdruk.','Bereken het nieuwe evenwicht en controleer. Bereken de procentuele verandering van Q.','Voeg V₁ toe. Markeer E₀ en E₁ met coördinaten. Laat met pijlen de verschuiving bij de oude prijs en de beweging langs A zien.','Beoordeel: “De grotere aangeboden hoeveelheid komt door een verschuiving van de aanbodlijn.”'],[
 '100 − 5P = 5P − 20 → 120 = 10P → **P₀ = € 12**. Q<sub>v,0</sub> = 100 − 60 = **40**; Q<sub>a</sub> = 60 − 20 = **40 kabels per week**. **Waarom:** de twee oorspronkelijke plannen zijn gelijk.',
 '**Aantal vragers.** Bij € 12: Q<sub>v,1</sub> = 120 − 60 = **60**, Q<sub>a</sub> = 60 − 20 = **40**. Vraagoverschot: **20 kabels per week**; opwaartse druk. **Waarom:** meer kopers vragen bij dezelfde prijs meer, terwijl de aanbieders hun oorspronkelijke plan behouden.',
 '120 − 5P = 5P − 20 → 140 = 10P → **P₁ = € 14**. Q<sub>v,1</sub> = 120 − 70 = **50**; controle Q<sub>a</sub> = 70 − 20 = **50 kabels per week**. Verandering: (50 − 40) / 40 × 100% = **25% stijging**. **Waarom:** de nieuwe prijs brengt beide plannen weer samen.',
 'V₁ door **(0; 24)** en **(120; 0)**. E₀ = **(40; 12)**; E₁ = **(50; 14)**. Een horizontale pijl bij € 12 loopt van 40 naar 60; de andere pijl loopt van E₀ naar E₁ langs A. **Waarom:** de eerste pijl toont de veranderde vraag, de tweede de prijsreactie van verkopers.',
 '**Onjuist.** A blijft Q<sub>a</sub> = 5P − 20. Alleen P stijgt van € 12 naar € 14; daarom wordt Q<sub>a</sub> groter langs dezelfde lijn. **Waarom:** de aanbodfactoren zijn niet veranderd.'],kind='target',extra=fig('1.3.3_ex_31','Figuur 24 · De oorspronkelijke lijnen zijn gegeven; de nieuwe lijn en uitkomsten ontbreken.'),ansfig='1.3.3_ans_31'))
 at(s,33)
 b='## Denkertje / Bonusopgave\n\n'+ex(32,'Twee verklaringen voor dezelfde richting','In een krant staat dat de prijs én de verkochte hoeveelheid van een product zijn gestegen. Er staat niets over veranderingen in vraagfactoren of aanbodfactoren.',[
 'Beschrijf of schets twee verschillende verklaringen die hierbij kunnen passen. Gebruik in één verklaring één verschuiving en in de andere twee verschuivingen. Leg uit waarom de twee waarnemingen de precieze oorzaak niet bewijzen.'],[
 'Eén mogelijkheid is een **vraagtoename bij onveranderd aanbod**: P en Q stijgen. Een tweede is **meer vraag én minder aanbod**, waarbij de vraagtoename groot genoeg is om de hoeveelheid toch te laten stijgen. Ook meer vraag plus een beperkte aanbodtoename kan passen als de vraagtoename de prijsdruk overheerst. De waarnemingen geven niet aan welke omstandigheden werkelijk veranderden. Er is aanvullende informatie over de oorzaken en hun grootte nodig.'],kind='bonus',criteria=['Geeft twee economisch mogelijke verklaringen voor P omhoog en Q omhoog.','Houdt bij twee verschuivingen rekening met hun relatieve grootte.','Onderscheidt een mogelijke modelverklaring van bewijs van de werkelijke oorzaak.'])
 b+='\n\n## Herhaling / Herhaling en interleaving\n\n'+ex(33,'Formules en eenheden ophalen','Gebruik de methodes uit eerdere paragrafen.',[
 'Een vereniging betaalt € 84 voor 14 gelijke mappen. Bereken het bedrag per map.','Voor één koper geldt q = 20 − 2P, voor 0 ≤ P ≤ 10. q is stuks per maand; P is euro per stuk. Bereken beide snijpunten van de vraaglijn met de assen.'],[
 '€ 84 / 14 = **€ 6 per map**. **Waarom:** je verdeelt het totale bedrag over het aantal gelijke producten. Herhaal zo nodig §1.1.2.',
 'Bij q = 0: 0 = 20 − 2P → P = **€ 10**. Bij P = 0: q = **20 stuks per maand**. Coördinaten: **(0; 10)** en **(20; 0)**. **Waarom:** bij elk assnijpunt is één coördinaat nul. Herhaal zo nodig §1.2.1.'],kind='review')
 b+=fig('1.3.3_fig_4','Figuur 25 · Houd de oorspronkelijke oorzaak en de reactie op de nieuwe prijs apart.')
 page(s,'Denkertje en herhaling',b)
 for lab,e,v in [('helmenoudP','(80+16)/8',12),('helmennieuwP','(96+16)/8',14),('helmennieuwQ','96-4*14',40),('helmenaanbodscenario','80-4*((80+32)/8)',24),('aardbeienPnieuw','(40+16)/4',14),('aardbeienQnieuw','40-2*14',12),('aardbeienprocent','(12-16)/16*100',-25),('plantvoedingQnieuw','72-3*14',30),('notitieblokkenQnieuw','100-5*14',30),('reparatiesQnieuw','112-4*16',48),('reparatiesgroei','(48-40)/40*100',20),('speelgoedprijs','132/12',11),('speelgoedQ','120-6*11',54),('kabelnieuwP','140/10',14),('kabelnieuwQ','120-5*14',50),('kabelgroei','(50-40)/40*100',25)]:ck(lab,e,v)
