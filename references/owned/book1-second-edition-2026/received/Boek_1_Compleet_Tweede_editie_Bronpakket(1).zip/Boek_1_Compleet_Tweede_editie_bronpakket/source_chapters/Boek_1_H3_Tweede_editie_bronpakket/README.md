# Boek 1 — Hoofdstuk 3: Aanbod en marktevenwicht
## Tweede editie · compleet bronpakket

De studenttekst telt **40 pagina's**. Het antwoordboek telt **21 pagina's** en de
lerareninformatie **8 pagina's**. Dit is de nieuw geschreven tweede editie bij de
boekopzet in `sources/`. De gedrukte eerste editie en de repositories zijn niet
gewijzigd. De vier doeloefeningen zijn voor deze editie uit de doelbeschrijvingen
ontwikkeld, niet gepresenteerd als ongewijzigde registeropgaven.

## Inhoud

- `output/`: de drie definitieve PDF's en hun zelfstandige HTML-weergaven.
- `1.3.*.md`, `Voorblad.md`, `Hoofdstukoverzicht.md`: bewerkbare studentmanuscripten.
- `Antwoorden.md` en `Docenteninformatie.md`: bewerkbare afzonderlijke boeken.
- `_assets/`: 37 nauwkeurig berekende SVG-figuren en 37 PNG-versies; 26 in het
  studentenhoofdstuk en 11 in het antwoordboek.
- `paragraphs/`: vier paragraaf-PDF's met behoud van hoofdstukpaginanummers;
  daarnaast paragraaf-, opgaven- en antwoordmanuscripten.
- `ONTWERP.md`: vooraf vastgelegde doel-opgavenstructuur.
- `QA/`: oefeningendekking, modelgegevens, geometriecontroles, paginering,
  lesplanning en bevindingen bij de visuele controle.
- `sources/`: de ongewijzigde boekopzet en herleidbare bronregistratie.

## Bewerken en bouwen

Gebruik Python 3.11 of nieuwer en installeer de bibliotheken in `requirements.txt`.
WeasyPrint/Cairo moeten met hun systeembibliotheken beschikbaar zijn. De lay-out
gebruikt het lokaal geïnstalleerde lettertype **Lato**, met DejaVu Sans als
terugval. Er worden geen lettertypebestanden meegeleverd. Andere lettertypen of
rendererversies kunnen de regelval veranderen; controleer dan de paginering opnieuw.

**Gewone tekstwijziging:** bewerk de afzonderlijke Markdown-bestanden uit
`chapter-order.json`, `Antwoorden.md` of `Docenteninformatie.md`. Draai vervolgens
`python build.py`. De gegenereerde hoofdstuk-Markdown is een bundeling, niet de
primaire tekstbron. De PAGE-markeringen leggen de bedoelde pagina's vast.

**Volledige hergeneratie:** bewerk de `author_*.py`-bestanden en voor figuren
`make_assets.py`. Draai `python build_all.py`. Dit maakt eerst de Markdown opnieuw;
rechtstreekse Markdown-wijzigingen worden dus overschreven. Antwoordmetadata en
controles worden dan ook vernieuwd. Geef inhoudelijke wijzigingen door in de
bijbehorende antwoorden, metadata en tests; oude testuitkomsten zijn geen bewijs
voor een gewijzigd manuscript.

**Controleren:** `python validate.py` controleert de huidige vastgelegde modellen,
SVG-coördinaten, dekking en PDF-structuur. `python export_paragraphs.py` maakt de
vier paragraafuitsneden. Inspecteer bij iedere inhoudelijke of grafische wijziging
ook de gerenderde pagina's. De programmeerbare controles vervangen geen
inhoudelijk of visueel oordeel en zijn geen bewijs van leerlingbeheersing.

## Afdrukken en afbakening

A4, werkelijke grootte, dubbelzijdig, omslaan langs de lange zijde. De bronnen en
vragen van de gemengde doeloefening staan op tegenoverliggende pagina's **36–37**.
Berekeningen en eigen tekeningen maakt de leerling in een schrift. Antwoorden en
lerareninformatie worden niet achter het studenthoofdstuk afgedrukt.

De kernroute kent zeven uitgewerkte lessen. Reken bij eerste gebruik op circa
7–9 lessen, afhankelijk van de benodigde ondersteuning. Dit zijn ontwerpinschattingen,
geen gemeten lestijden. Geen toets of nieuwe economische theorie is aan het einde
verstopt: het laatste rekenwerk haalt bekende technieken op voor Boek 2.

Alle casussen en getallen zijn voor dit lesmodel gemaakt. Er is geen claim van een
nieuwe volledige CE-audit, onafhankelijke externe review of klassenexperiment.
