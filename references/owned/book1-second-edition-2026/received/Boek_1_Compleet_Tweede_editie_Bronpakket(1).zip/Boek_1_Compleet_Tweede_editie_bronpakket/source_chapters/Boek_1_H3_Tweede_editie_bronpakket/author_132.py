from author_common import *
def make():
 s='1.3.2';at(s,12)
 page(s,'Wanneer passen de plannen bij elkaar?',title(s,'Marktevenwicht: prijs en hoeveelheid')+
 p('**Aan het einde van de middag zijn er broodjes over. Was de prijs te hoog?** Je kunt niet alleen naar de verkopers kijken. Ook de plannen van kopers zijn nodig. Hieronder vergelijken we beide plannen bij dezelfde prijs.')+
 goals(['de evenwichtsprijs en evenwichtshoeveelheid uitleggen;','Q<sub>v</sub> = Q<sub>a</sub> oplossen en in beide functies controleren;','het evenwicht in een zelfgetekende marktgrafiek aangeven;','vraag- en aanbodoverschotten berekenen en prijsdruk verklaren;','onder een gegeven transactieregel de werkelijke verkoop bepalen.'])+
 table(['P (€ per broodje)','Qᵥ (per middag)','Qₐ (per middag)'],[['3','90','10'],['5','70','30'],['7','50','50'],['9','30','70'],['11','10','90']])+
 p('Q<sub>v</sub> staat voor de **collectief gevraagde hoeveelheid**; Q<sub>a</sub> voor de **collectief aangeboden hoeveelheid**. Alle broodjes zijn in dit model gelijk. We kijken naar veel kleine kopers en verkopers. Zij kunnen elkaar vinden en de prijs kan zich aanpassen.')+
 box('Marktevenwicht','De situatie waarin de gevraagde en de aangeboden hoeveelheid bij dezelfde prijs aan elkaar gelijk zijn.','definition')+
 p('Bij **€ 7** willen kopers 50 broodjes kopen en verkopers 50 broodjes aanbieden. € 7 is de **evenwichtsprijs**. 50 broodjes per middag is de **evenwichtshoeveelheid**. Dat betekent niet dat iedere koper evenveel koopt.'))
 at(s,13)
 page(s,'Van de tabel naar het snijpunt',p('De vraaglijn uit hoofdstuk 1.2 blijft hetzelfde gereedschap. Zij beschrijft de gevraagde hoeveelheid bij verschillende prijzen, **terwijl de overige omstandigheden gelijk blijven**. Eerst tekenen we alleen deze lijn.')+
 fig('1.3.2_fig_1','Figuur 9 · De koopplannen uit de tabel: bijvoorbeeld (70; 5) en (30; 9).')+
 p('Nu voegen we de aanbodlijn toe. Die houdt de andere omstandigheden eveneens gelijk. Bij eenzelfde hoeveelheid en prijs vallen beide plannen alleen in **E** samen. De hulplijnen verbinden dat punt met beide assen.')+
 fig('1.3.2_fig_2','Figuur 10 · E ligt op V én A. Hier hoort P = € 7 bij Q = 50 broodjes per middag.')+
 box('Niet de hoeveelheden bij elkaar optellen','Bij evenwicht verkopen de aanbieders samen 50 broodjes, die door de vragers worden gekocht. Dat zijn **dezelfde 50 transacties**, niet 50 + 50 = 100.','warning'))
 at(s,14)
 page(s,'Een gelijkheid stap voor stap oplossen',p('Bij ingewikkeldere getallen is aflezen niet nauwkeurig genoeg. Dezelfde broodjesmarkt heeft de volgende functies. P is euro per broodje; beide hoeveelheden zijn broodjes per middag.')+
 box('De twee functies','Q<sub>v</sub> = 120 − 10P &nbsp; (0 ≤ P ≤ 12)<br/>Q<sub>a</sub> = 10P − 20 &nbsp; (2 ≤ P ≤ 12)','formula')+
 p('**1. Stel de plannen gelijk.** In evenwicht geldt Q<sub>v</sub> = Q<sub>a</sub>. Vervang beide hoeveelheden door hun functie. P is in beide functies dezelfde marktprijs.')+
 '<div class="calculation">120 − 10P = 10P − 20<br/>120 = 20P − 20 &nbsp; (+10P aan beide kanten)<br/>140 = 20P &nbsp; (+20 aan beide kanten)<br/>7 = P &nbsp; (beide kanten delen door 20)</div>'+
 p('Aan beide kanten dezelfde bewerking uitvoeren houdt de gelijkheid intact. De tussenstappen verklaren waarom een minteken verandert; getallen springen niet zomaar naar de andere kant.')+
 p('**2. Bereken de hoeveelheid.** Vul P = 7 in de vraagfunctie in:<br/>Q<sub>v</sub> = 120 − 10 × 7 = **50 broodjes per middag**.')+
 p('**3. Controleer met de andere functie.**<br/>Q<sub>a</sub> = 10 × 7 − 20 = **50 broodjes per middag**.')+
 p('**4. Leg de uitkomst uit.** Bij **€ 7 per broodje** zijn beide plannen 50 broodjes per middag. De gevonden prijs past ook binnen de opgegeven prijzen van beide functies.')+
 box('Waarom niet P = 0 of Q = 0 invullen?','Zo vind je een snijpunt met een as. Dat is niet het marktevenwicht. Voor evenwicht moeten **twee plannen bij dezelfde prijs** overeenkomen.','warning'))
 at(s,15)
 page(s,'Een vraagoverschot: niet iedereen kan kopen',p('Stel dat de verkopers aan het begin van de middag **€ 5** vragen. Bij die prijs wordt Q<sub>v</sub> = 70 en Q<sub>a</sub> = 30. Kopers willen samen meer kopen dan verkopers willen en kunnen aanbieden.')+
 box('Vraagoverschot','De gevraagde hoeveelheid is bij een bepaalde prijs groter dan de aangeboden hoeveelheid. Het verschil is het tekort bij die prijs.','definition')+
 fig('1.3.2_fig_3','Figuur 11 · Het tekort is een horizontaal verschil tussen hoeveelheden, geen verschil tussen prijzen.')+
 p('**Tekort:** Q<sub>v</sub> − Q<sub>a</sub> = 70 − 30 = **40 broodjes per middag**.')+
 p('Voor de verkoop maken we een extra afspraak: alle aangeboden broodjes vinden een koper, er zijn geen andere voorraden en er zijn geen verdere belemmeringen. Dan worden **30 broodjes verkocht**. De wens om er 70 te kopen schept niet vanzelf 70 beschikbare broodjes.')+
 p('Als de prijs zich daarna mag aanpassen, ontstaat **opwaartse prijsdruk**. Kopers concurreren om de beperkte hoeveelheid. Bij een hogere prijs daalt de gevraagde hoeveelheid en stijgt de aangeboden hoeveelheid, langs de bestaande lijnen.')+
 box('Tekort is niet hetzelfde als schaarste','Een vraagoverschot hoort bij een bepaalde marktprijs. Schaarste gaat over beperkte middelen tegenover behoeften. Ook bij marktevenwicht blijven tijd en grondstoffen schaars.','warning'))
 at(s,16)
 page(s,'Een aanbodoverschot: niet alles vindt een koper',p('Begin opnieuw bij dezelfde broodjesmarkt, zonder de vorige prijsverandering mee te nemen. Stel nu dat de verkoopprijs aanvankelijk **€ 9** is. Kopers vragen 30 broodjes; verkopers bieden er 70 aan.')+
 box('Aanbodoverschot','De aangeboden hoeveelheid is bij een bepaalde prijs groter dan de gevraagde hoeveelheid.','definition')+
 fig('1.3.2_fig_4','Figuur 12 · Bij € 9 zijn er meer verkoopplannen dan koopplannen. De afstand is 70 − 30 = 40.')+
 p('**Aanbodoverschot:** Q<sub>a</sub> − Q<sub>v</sub> = 70 − 30 = **40 broodjes per middag**. Als alle kopers een verkoper vinden en niets anders de verkoop belemmert, worden **30 broodjes verkocht**.')+
 p('Het overschot hoeft niet al in een krat te liggen. Aanbod beschrijft plannen. Als de 70 broodjes al zijn gemaakt, blijven er 40 onverkocht. Zijn ze nog niet gemaakt, dan zijn het 40 niet-uitgevoerde verkoopplannen.')+
 p('Verkopers concurreren om kopers: er ontstaat **neerwaartse prijsdruk**. Langs V neemt de gevraagde hoeveelheid dan toe; langs A neemt de aangeboden hoeveelheid af. In het model bewegen beide plannen naar elkaar toe.')+
 box('Een model, geen belofte','Bij voldoende uitwisseling en een aanpasbare prijs kan de markt naar evenwicht bewegen. Dat hoeft niet onmiddellijk te gebeuren. Evenwicht zegt bovendien niets over de eerlijkheid van de verdeling.'))
 at(s,17)
 page(s,'Uitgewerkt voorbeeld','## Uitgewerkt voorbeeld\n\n'+p('Op een markt voor herbruikbare drinkflessen gelden **Q<sub>v</sub> = 80 − 5P** (0 ≤ P ≤ 16) en **Q<sub>a</sub> = 5P − 20** (4 ≤ P ≤ 16). Q is flessen per week; P is euro per fles. De overige omstandigheden blijven gelijk.')+
 p('**1. Plannen gelijkstellen en oplossen.**')+
 '<div class="calculation">80 − 5P = 5P − 20<br/>80 = 10P − 20 &nbsp; (+5P)<br/>100 = 10P &nbsp; (+20)<br/>P = 10 &nbsp; (delen door 10)</div>'+
 p('**2. Hoeveelheid en controle.** Q<sub>v</sub> = 80 − 5 × 10 = **30**. Controle: Q<sub>a</sub> = 5 × 10 − 20 = **30 flessen per week**.')+
 p('**3. Tekenen.** Voor V gebruiken we (0; 16) en (80; 0). Voor A gebruiken we (0; 4) en (60; 16). Markeer het snijpunt E = **(30; 10)** en verbind het met beide assen.')+
 fig('1.3.2_we_1','Figuur 13 · De grafiek controleert de berekening. Eén punt E hoort bij dezelfde prijs in beide functies.')+
 p('**4. Betekenis.** Bij **€ 10 per fles** sluiten de plannen voor **30 flessen per week** op elkaar aan. De prijs is niet de maximale betalingsbereidheid; de vraaglijn raakt de prijsas pas bij € 16.'))
 at(s,18)
 b=(p('**Vervolg van het uitgewerkte voorbeeld.** Aan het begin vraagt de markt € 8 per fles. Zolang die prijs geldt, vinden alle aanbieders een koper. Er zijn geen andere voorraden of verdere belemmeringen.')+
 table(['Bij P = € 8','Berekening','Uitkomst'],[['Gevraagd','80 − 5 × 8','40 flessen per week'],['Aangeboden','5 × 8 − 20','20 flessen per week'],['Vraagoverschot','40 − 20','20 flessen per week'],['Verkocht volgens de afspraak','Alle 20 aangeboden flessen vinden een koper.','20 flessen per week']])+
 p('**5. Verklaar de prijsdruk.** Er zijn meer koopplannen dan verkoopplannen. De concurrentie tussen kopers geeft opwaartse druk. Bij stijging richting € 10 neemt Q<sub>v</sub> af en Q<sub>a</sub> toe. Dat zijn bewegingen langs de twee **ongewijzigde** lijnen.')+
 box('Samenvatting §1.3.2','Evenwicht: Q<sub>v</sub> = Q<sub>a</sub>. Los P op, bereken Q en controleer beide functies. Q<sub>v</sub> &gt; Q<sub>a</sub> geeft een vraagoverschot; Q<sub>a</sub> &gt; Q<sub>v</sub> een aanbodoverschot. Werkelijke verkoop vereist ook een transactieregel. In §1.3.3 veranderen de omstandigheden achter een lijn.','box summary')+'\n\n## Startopgaven\n\n')
 b+=ex(12,'Rekenen terughalen','Gebruik de eenvoudige vraagfunctie q = 30 − 3P, voor 0 ≤ P ≤ 10. q is stuks per week; P is euro per stuk.',[
 'Bereken P als q = 12. Controleer.'],[
 '12 = 30 − 3P → 3P = 18 → P = **€ 6 per stuk**. Controle: 30 − 3 × 6 = 12 stuks per week. **Waarom:** terugrekenen en daarna invullen moeten dezelfde combinatie opleveren.'],kind='start')
 b+=ex(13,'Eén markt, dezelfde producten','Bij € 4 worden 60 bidons gevraagd en 60 bidons aangeboden. Kopers en verkopers vinden elkaar; er zijn geen andere belemmeringen.',[
 'Is er evenwicht? Hoeveel bidons worden verkocht: 60 of 120? Leg uit.'],[
 '**Er is evenwicht; er worden 60 bidons verkocht.** **Waarom:** de kopers kopen dezelfde bidons die de verkopers verkopen. Vraag en aanbod tellen hier geen verschillende transacties.'],kind='start')
 b+=box('Oefenroute',ROUTE,'route')
 page(s,'Bij een andere prijs: plannen en verkoop',b)
 at(s,19)
 page(s,'Begeleide inoefening · eerst herkennen','## Begeleide inoefening\n\n'+p(SKIP,'note')+
 ex(14,'Lunchboxen','Op een markt gelden Q<sub>v</sub> = 60 − 5P en Q<sub>a</sub> = 5P − 10. Beide zijn bruikbaar voor 2 ≤ P ≤ 12. Q is lunchboxen per week; P is euro per lunchbox. De volledig uitgewerkte figuur laat E en twee plannen bij € 5 zien.',[
 'Lees de evenwichtsprijs en evenwichtshoeveelheid af. Vul de afgelezen prijs in beide functies in.','Lees bij € 5 beide hoeveelheden af. Bereken het verschil en benoem het overschot. Hoeveel wordt verkocht als alle aangeboden lunchboxen een koper vinden en er geen andere voorraad of belemmering is?'],[
 'E: **P = € 7 per lunchbox**, **Q = 25 lunchboxen per week**. Q<sub>v</sub> = 60 − 5 × 7 = 25; Q<sub>a</sub> = 5 × 7 − 10 = 25. **Waarom:** het snijpunt moet in beide functies dezelfde hoeveelheid geven.',
 'Bij € 5: Q<sub>v</sub> = **35**, Q<sub>a</sub> = **15**. Vraagoverschot: 35 − 15 = **20 lunchboxen per week**. Verkoop: **15 lunchboxen per week**. **Waarom:** onder de gegeven afspraak worden alle 15 aangeboden lunchboxen verkocht, niet de 20 ontbrekende lunchboxen.'],kind='guided',extra=fig('1.3.2_ex_14','Figuur 14 · R ligt op de vraaglijn en S op de aanbodlijn. Beide punten gebruiken dezelfde prijs.'))+
 box('Twee verschillende vragen','“Hoeveel ontbreekt er?” vraagt om een verschil. “Hoeveel wordt verkocht?” vraagt om een aantal transacties. De antwoorden kunnen toevallig gelijk zijn, maar de berekeningen betekenen iets anders.'))
 at(s,20)
 b=ex(15,'De tweede lijn tekenen','Voor posters geldt Q<sub>v</sub> = 90 − 5P (0 ≤ P ≤ 18) en Q<sub>a</sub> = 10P − 30 (3 ≤ P ≤ 18). Q is posters per week; P is euro per poster.',[
 'Maak af: 90 − 5P = 10P − 30 → 90 = …P − 30 → … = …P. Bereken P, Q en de controle.','Teken A met twee zelf berekende punten en markeer E met hulplijnen.','Bereken bij € 6 het vraagoverschot of aanbodoverschot.'],[
 '90 = **15P** − 30 → **120 = 15P** → P = **€ 8**. Q<sub>v</sub> = 90 − 5 × 8 = **50 posters per week**. Controle: 10 × 8 − 30 = 50. **Waarom:** dezelfde bewerking aan beide kanten houdt de gelijkheid in stand.',
 'A bijvoorbeeld door **(0; 3)** en **(150; 18)**. E = **(50; 8)**, met hulplijnen naar 50 en 8. **Waarom:** de aanbodpunten komen uit de aanbodfunctie; E ligt ook op de gegeven vraaglijn.',
 'Q<sub>v</sub> = 90 − 5 × 6 = **60**; Q<sub>a</sub> = 10 × 6 − 30 = **30**. Vraagoverschot = 60 − 30 = **30 posters per week**. **Waarom:** er zijn bij € 6 meer koopplannen dan verkoopplannen.'],kind='guided',extra=fig('1.3.2_ex_15','Figuur 15 · V is gegeven; aanbodlijn, E en hulplijnen ontbreken.'),ansfig='1.3.2_ans_15')
 b+=ex(16,'Zonder grafiek','Bij de opening van een markt vragen kopers 40 sjaals en bieden verkopers er 70 aan, bij dezelfde prijs. Alle kopers vinden een verkoper; niets anders belemmert de verkoop.',[
 'Bereken de verkoop en het overschot. Welke kant gaat de prijsdruk op als verkopers hun prijs kunnen aanpassen?'],[
 'Verkoop: **40 sjaals**. Aanbodoverschot: 70 − 40 = **30 sjaals**. **Neerwaartse prijsdruk. Waarom:** verkopers concurreren om minder koopplannen dan zij samen willen leveren.'],kind='guided')
 page(s,'Begeleide inoefening · aanvullen en loslaten',b)
 at(s,21)
 b='## Zelfstandige oefening\n\n'+ex(17,'Schriftenmarkt','Voor dezelfde soort schriften gelden Q<sub>v</sub> = 140 − 10P (0 ≤ P ≤ 14) en Q<sub>a</sub> = 10P − 20 (2 ≤ P ≤ 14). Q is schriften per week; P is euro per schrift.',[
 'Bereken het evenwicht en controleer met beide functies.','Teken zelf een marktgrafiek met beide lijnen, E, assen, eenheden, een schaal en hulplijnen.','Bereken het overschot bij € 6 en verklaar de prijsdruk.'],[
 '140 − 10P = 10P − 20 → 140 = 20P − 20 → 160 = 20P → P = **€ 8**. Q<sub>v</sub> = 140 − 10 × 8 = **60**; controle Q<sub>a</sub> = 10 × 8 − 20 = **60 schriften per week**. **Waarom:** beide plannen stemmen overeen.',
 'V door **(0; 14)** en **(140; 0)**. A door **(0; 2)** en **(120; 14)**. E = **(60; 8)**. **Waarom:** iedere lijn verbindt prijs en hoeveelheid uit zijn eigen functie; E ligt op beide. Zie de antwoordfiguur.',
 'Bij € 6: Q<sub>v</sub> = 80 en Q<sub>a</sub> = 40. Vraagoverschot = 80 − 40 = **40 schriften per week**. **Opwaartse druk**, doordat kopers om het kleinere aanbod concurreren. **Waarom:** de prijs is onder het berekende evenwicht.'],kind='independent',ansfig='1.3.2_ans_17')
 b+=ex(18,'Fietsmanden','Q<sub>v</sub> = 120 − 4P (0 ≤ P ≤ 30); Q<sub>a</sub> = 6P − 30 (5 ≤ P ≤ 30). Q is manden per maand; P is euro per mand.',[
 'Bereken de evenwichtsprijs en hoeveelheid en controleer.','Een leerling vindt P = € 30 door Qᵥ = 0 te nemen en noemt dit de evenwichtsprijs. Wat heeft die leerling wel gevonden?'],[
 '120 − 4P = 6P − 30 → 150 = 10P → P = **€ 15**. Q<sub>v</sub> = 120 − 4 × 15 = **60**; Q<sub>a</sub> = 6 × 15 − 30 = **60 manden per maand**. **Waarom:** alleen bij € 15 zijn de twee plannen gelijk.',
 'Het **snijpunt van de vraaglijn met de P-as**, waar de gevraagde hoeveelheid nul is. **Waarom:** deze berekening gebruikt geen aanbod en zoekt dus niet naar overeenstemming tussen vraag en aanbod.'],kind='independent')
 b+=ex(19,'Plantbollen','Bij € 4 vragen kopers 90 zakken en bieden verkopers er 50 aan. Bij € 7 zijn dat 30 en 80. De gegevens betreffen dezelfde week. Op elk prijsniveau vinden alle deelnemers aan de kleinste kant een handelspartner; er zijn geen andere beperkingen.',[
 'Bereken per prijs het type overschot, zijn omvang en de werkelijke verkoop.','Leg uit waarom je de gevraagde en aangeboden hoeveelheden niet bij elkaar optelt.'],[
 '€ 4: vraagoverschot **90 − 50 = 40 zakken**, verkoop **50 zakken**. € 7: aanbodoverschot **80 − 30 = 50 zakken**, verkoop **30 zakken**. **Waarom:** het verschil meet de niet-passende plannen, het kleinere aantal meet hier de gerealiseerde transacties.',
 'Elke verkoop is tegelijk één aankoop. **Waarom:** optellen zou dezelfde transactie tweemaal tellen.'],kind='independent')
 page(s,'Zelfstandig oplossen en tekenen',b)
 at(s,22)
 page(s,'Doeloefening','## Doeloefening\n\n'+ex(20,'Een markt voor herbruikbare bekers','Een markt verkoopt één soort herbruikbare beker. Veel kleine kopers en verkopers kunnen elkaar vinden. De overige omstandigheden blijven gelijk. Q<sub>v</sub> = 150 − 10P, voor 0 ≤ P ≤ 15. Q<sub>a</sub> = 5P − 30, voor 6 ≤ P ≤ 15. Q is bekers per week; P is euro per beker.',[
 'Bereken de evenwichtsprijs. Laat je algebraïsche stappen zien.','Bereken de evenwichtshoeveelheid en controleer die met beide functies. Leg de uitkomst uit in een zin met eenheden.','Teken zelf beide lijnen in één marktgrafiek. Geef de assen, eenheden, schaal, E en hulplijnen naar de evenwichtsprijs en -hoeveelheid aan.','Aan het begin geldt nog een prijs van € 10. Bereken Qᵥ, Qₐ en het tekort of overschot bij die prijs. Hoeveel bekers worden verkocht als al het aanbod een koper vindt, er geen andere voorraad is en niets anders de verkoop belemmert?','De prijs kan zich daarna aanpassen. Verklaar de richting van de prijsdruk en de reacties van kopers en verkopers langs de bestaande lijnen.'],[
 '150 − 10P = 5P − 30 → 150 = 15P − 30 (+10P aan beide kanten) → 180 = 15P (+30) → P = **€ 12 per beker** (delen door 15). **Waarom:** de gelijkheid zoekt één prijs voor dezelfde hoeveelheid in beide plannen.',
 'Q<sub>v</sub> = 150 − 10 × 12 = **30 bekers per week**. Controle: Q<sub>a</sub> = 5 × 12 − 30 = **30**. Bij **€ 12 per beker** sluiten beide plannen voor **30 bekers per week** aan. **Waarom:** gelijkheid van de hoeveelheden is precies de evenwichtsvoorwaarde.',
 'V door **(0; 15)** en **(150; 0)**; A door **(0; 6)** en **(45; 15)**. E = **(30; 12)**. Q horizontaal, P verticaal, met juiste eenheden en schalen. **Waarom:** het evenwicht is het gemeenschappelijke punt, niet een snijpunt met een as.',
 'Bij € 10: Q<sub>v</sub> = 150 − 10 × 10 = **50**; Q<sub>a</sub> = 5 × 10 − 30 = **20**. Vraagoverschot: 50 − 20 = **30 bekers per week**. Verkoop volgens de afspraak: **20 bekers per week**. **Waarom:** ontbrekende bekers worden niet verkocht; alle 20 aangeboden bekers wel.',
 '**Opwaartse prijsdruk.** Kopers concurreren om het kleinere aanbod. Als P stijgt, daalt Q<sub>v</sub> langs V en stijgt Q<sub>a</sub> langs A, totdat de plannen aansluiten. **Waarom:** de omstandigheden achter de lijnen veranderen niet; er ontstaan geen verschuivingen.'],kind='target',ansfig='1.3.2_ans_20')+
 box('Werk op papier','Gebruik je schrift voor de berekeningen en de zelfgetekende grafiek. Bewaar de tussenstappen: daarmee kun je een rekenfout van een verkeerde methode onderscheiden.'))
 at(s,23)
 b='## Denkertje / Bonusopgave\n\n'+ex(21,'Iedereen tevreden?','Op een markt is evenwicht bij € 10. Een leerling wil het product wel hebben, maar wil er hoogstens € 7 voor betalen. De leerling koopt niet.',[
 'Spreekt dit het marktevenwicht tegen? Beoordeel ook de uitspraak: “Bij evenwicht zijn alle behoeften vervuld.”'],[
 'Nee. Evenwicht vergelijkt wat mensen **bij € 10 willen en kunnen kopen** met het aanbod bij die prijs. Iemand met een betalingsbereidheid van € 7 draagt bij € 10 geen vraag bij. Dat betekent niet dat die persoon geen behoefte heeft. Evenwicht sluit plannen bij een prijs op elkaar aan, maar vervult niet alle wensen en bewijst geen eerlijke verdeling.'],kind='bonus',criteria=['Maakt de vergelijking expliciet afhankelijk van de prijs.','Onderscheidt behoefte van koopbereidheid bij € 10.','Leidt geen eerlijkheid of algemene tevredenheid af uit Qv = Qa.'])
 b+='\n\n## Herhaling / Herhaling en interleaving\n\n'+ex(22,'Basis en oppervlakte','Twee korte herhalingen uit §1.1.2 en §1.1.3.',[
 'Een index gaat van 96 naar 108. Bereken de relatieve verandering, met de oude index als basis.','Een rechthoek heeft basis 6 cm en hoogte 4 cm. Bereken de oppervlakte van de rechthoek en van een driehoek met dezelfde basis en hoogte.'],[
 '(108 − 96) / 96 × 100% = **12,5% stijging**. **Waarom:** de toename van 12 indexpunten wordt vergeleken met 96, niet met 100.',
 'Rechthoek: 6 × 4 = **24 cm²**. Driehoek: ½ × 6 × 4 = **12 cm²**. **Waarom:** de driehoek heeft de helft van de oppervlakte van de rechthoek met dezelfde basis en hoogte.'],kind='review')
 b+=fig('1.3.2_fig_5','Figuur 16 · Controleer beide functies voordat je de economische conclusie opschrijft.')
 page(s,'Denkertje, herhaling en controle',b)
 for lab,e,v in [('broodjes eqprijs','(120+20)/(10+10)',7),('broodjes eqQ','120-10*7',50),('broodtekort','(120-10*5)-(10*5-20)',40),('flessen eq','(80+20)/10',10),('flessen q','80-5*10',30),('posters eq','(90+30)/15',8),('schriften eq','(140+20)/20',8),('manden eq','150/10',15),('mandenQ','120-4*15',60),('bekers eq','180/15',12),('bekersQ','150-10*12',30),('bekertekort','(150-10*10)-(5*10-30)',30),('index10896','(108-96)/96*100',12.5)]:ck(lab,e,v)
