# Boek 1 — Grondslagen, vraag en aanbod
## Complete tweede editie · 2026

Dit bronpakket bundelt uitsluitend de drie tweede-editiehoofdstukken uit de conversatie. De gedrukte eerste editie en de repositories zijn niet gewijzigd.

## Uitgaven

- `output/Boek_1_Compleet_Tweede_editie.pdf`: 132 pagina’s. Omslag, colofon, voorwoord, inhoud, drie leerlinghoofdstukken, begrippenlijst en formule- en aanpakoverzicht.
- `output/Boek_1_Compleet_Antwoorden_Tweede_editie.pdf`: 66 pagina’s, inclusief een bewust lege laatste pagina voor dubbelzijdig afdrukken. Alle uitwerkingen bij 114 opgaven.
- `output/Boek_1_Compleet_Docenteninformatie_Tweede_editie.pdf`: 26 pagina’s. Twee nieuwe pagina’s met inhoud, paginering en verantwoording, gevolgd door de drie oorspronkelijke handleidingen.

## Bronnen en bewerken

`input/` bevat de oorspronkelijke negen PDF’s en de gekozen omslag (`cover.png`). Hun hashes zijn vastgelegd in `qa/input_hashes.json`.

`source_chapters/` bevat de ongewijzigde uitgepakte bronpakketten van de drie hoofdstukken, inclusief Markdown, SVG/PNG, hoofdstukbouwscripts, losse paragraafexports en de oorspronkelijke controlelogs. Er worden geen lettertypebestanden meegeleverd.

`book_matter/formulas.json` en `book_matter/glossary.json` bevatten de boeknaslag. De begrippen zijn letterlijke hoofdstukformuleringen: 47 termen, 48 definities. De twee formuleringen voor ceteris paribus blijven afzonderlijk herkenbaar. De nieuwe voorwerkpagina’s worden geschreven door `build/build_book.py`; de Markdown-export in `book_matter/` is een afgeleide leesbron.

`Boek 1 Grondslagen, vraag en aanbod – boek.md` is een gecombineerde lees- en bewerkingsbron met genamespaceerde ankers en assetverwijzingen. Deze afgeleide leesbron is niet de uitvoerroute naar het vaste drukwerk. Opnieuw opmaken vanuit Markdown kan pagina’s verschuiven. De huidige printmaster wordt daarom uit de geleverde PDF’s samengesteld. Een inhoudelijke wijziging aan een hoofdstuk vraagt eerst een nieuwe hoofdstukexport en expliciete aanpassing van de invoer en paginametadata.

## Opnieuw opbouwen

Installeer de pakketten uit `requirements.txt` en de Lato-lettertypefamilie lokaal. Zet zo nodig `LATO_FONT_DIR` naar de lokale map met Lato-Regular.ttf, Lato-Bold.ttf, Lato-Heavy.ttf, Lato-Black.ttf en Lato-Italic.ttf. Er worden geen lettertypen met dit pakket gedistribueerd.

Vanuit de pakketmap:

```sh
python build/prepare_inputs.py
python build/build_book.py
python build/export_manuscript.py
python build/validate_book.py
python build/check_rebuild.py
```

De invoeridentiteit wordt tijdens de build gecontroleerd. `prepare_inputs.py` registreert de huidige invoer; vervang de oorspronkelijke bestanden dus alleen bewust. Voor visuele controle:

```sh
python build/render_review.py
```

`pdftoppm` (Poppler) is alleen nodig voor de onafhankelijke aanvullende rendercontrole. De oorspronkelijke hoofdstukbouwscripts hebben hun eigen afhankelijkheden; zij worden bij deze boekbundeling niet uitgevoerd.

## Paginering

| Onderdeel leerlingboek | Pagina’s |
|---|---:|
| Voorwerk, inclusief omslag | 1–4 |
| 1.1 Economisch denken en rekenen | 5–44 |
| 1.2 Vraag | 45–84 |
| 1.3 Aanbod en marktevenwicht | 85–124 |
| Begrippenlijst | 125–128 |
| Formule- en aanpakoverzicht | 129–132 |

Een lokale leerlingpagina wordt een boekpagina door respectievelijk 4, 44 of 84 op te tellen. De gemengde doelopgaven behouden hun tegenoverliggende bron- en vraagpagina’s: 40–41, 80–81 en 120–121. Opgaafnummering start opnieuw per hoofdstuk.

De hoofdstukhandleidingen gebruiken hun oorspronkelijke lokale verwijzingen naar het leerlinghoofdstuk; de omzetting staat voorin de gecombineerde handleiding. De twee inhoudstabellen in de losse antwoordboeken zijn bijgewerkt naar het complete antwoordboek. Dat boek heeft eigen paginanummers.

## Behoud en controle

Alle 207 oorspronkelijke leerling-, antwoord- en docentenpagina’s zijn behouden. Alleen paginering en navigatie veranderen. In hoofdstuk 1.3 veranderen twee verwijzingen van lokale pagina 17 en 27 naar boekpagina 101 en 111. Er is geen inhoudelijke correctie van opgaven, tabellen, grafieken of antwoorden in de hoofdstukken uitgevoerd.

De validator vergelijkt iedere oorspronkelijke pagina visueel op 90 dpi, buiten nauwkeurig geregistreerde navigatierechthoeken. Daarnaast vergelijkt hij woorden en tekstcoördinaten, invoerhashes, bronbestanden, bladwijzers, links, paginatellingen en alle overgenomen begripsdefinities. `qa/validation.json` geeft de feitelijke resultaten. De validatie is een samenstelcontrole, geen nieuwe vakinhoudelijke audit of klassentest. `qa/rebuild.json` registreert de afzonderlijke schone herbouw: tekst- en pixelgelijkheid op alle 224 uitvoerpagina’s. `qa/visual-review.md` beschrijft de visuele inspectie en haar grenzen.

De omslag is exact de gekozen afbeelding. Omdat die een andere verhouding heeft dan A4, is zij volledig en onvervormd op A4 geplaatst, met een smalle achtergrondstrook en een editieaanduiding buiten het beeld. De verkorte omslagtekst “minder vraag” en de niet onderling consistente indexgrafiek/tabel zijn als illustratieve beperkingen in de handleiding vermeld; ze zijn niet stilzwijgend aangepast.

## Afdrukken

A4, ware grootte (100%), dubbelzijdig, omslaan over de lange zijde. De hoofdstukken beginnen rechts. De laatste lege antwoordpagina is bewust toegevoegd. Een drukker die een veelvoud van vier pagina’s of een losse omslag nodig heeft, kan de inslag op deze ongewijzigde leesvolgorde baseren.
