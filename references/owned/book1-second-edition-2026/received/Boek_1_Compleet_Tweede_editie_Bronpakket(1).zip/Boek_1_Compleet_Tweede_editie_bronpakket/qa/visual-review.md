# Visuele samenstelcontrole — Boek 1, tweede editie

Datum: 9 september 2026. Reikwijdte: de bundeling van de geleverde hoofdstukken, niet een nieuwe vakinhoudelijke beoordeling van de hoofdstukken.

## Beoordeelde uitvoer

- Leerlingboek: 132 pagina’s; drie ongewijzigd ingedeelde hoofdstukken van ieder 40 pagina’s.
- Antwoorden: 66 pagina’s, met één bewust lege slotpagina.
- Docenteninformatie: 26 pagina’s.

## Visuele inspectie

De nieuwe en gewijzigde pagina’s zijn gerenderd met PyMuPDF. De contactbladen in `qa/review/` tonen de gecontroleerde omslag, voorwerkpagina’s, hoofdstukopeningen, gewijzigde verwijzingen, begrippenlijst, formuleoverzicht en voorwerk van de antwoord- en docentenbundel. De slotversie van het formuleoverzicht is opnieuw gerenderd na de verduidelijking van de eenheden en toevoeging van het tabelverschil per horizontale eenheid.

Een tweede renderer, Poppler (`pdftoppm`), is gebruikt voor afzonderlijke inspectie van leerlingpagina 4 (inhoud), 129–131 (naslag) en antwoordpagina 23 (bijgewerkte hoofdstukinhoud). Geen afgesneden tekst, overlappende onderdelen of gebroken tekens aangetroffen op deze geïnspecteerde pagina’s. De oorspronkelijke grafieken in de hoofdstukken zijn niet opnieuw getekend.

## Objectieve behoudcontrole

`validation.json`: 1.513 controles geslaagd, geen mislukkingen. Alle 207 oorspronkelijke leerling-, antwoord- en docentenpagina’s zijn vergeleken met de samengestelde uitvoer. Alleen expliciet geregistreerde paginering en navigatie zijn uitgezonderd van de pixelvergelijking; woorden en tekstcoördinaten zijn afzonderlijk vergeleken. Invoerbestanden en uitgepakte hoofdstukbronnen zijn op hash gecontroleerd.

`rebuild.json`: opbouw in een aparte tijdelijke map. Alle 224 uitvoerpagina’s hebben dezelfde geëxtraheerde tekst en exact dezelfde gerenderde RGB-pixels op 72 dpi als de definitieve bestanden, met dezelfde lokale afhankelijkheden en lettertypen.

Deze controles bewijzen samenstelbehoud en reproduceerbaarheid binnen deze omgeving. Ze zijn geen nieuwe toets van economische modellen, examenafstemming of lesduur.

## Druk en navigatie

Leerlinghoofdstukken beginnen op 5, 45 en 85, steeds rechts. De drie gemengde doelopgaven behouden hun tegenoverliggende bron- en vraagpagina’s: 40–41, 80–81 en 120–121. De twaalf paragrafen staan in de aanklikbare inhoud en de PDF-bladwijzers. Alle 114 opgaven hebben een bladwijzer in het antwoordboek.

De lokale leerlingpagina’s in de oorspronkelijke docentenhandleidingen blijven bewust staan. De omzetting naar het complete leerlingboek staat op pagina 2 van de gecombineerde handleiding en in `page_conversion.csv`.

## Bewust niet aangepast

De gekozen omslag is ongewijzigd opgenomen, volledig zichtbaar en zonder vervorming. De verkorte tekst “minder vraag” en de niet onderling consistente indexgrafiek en tabel op die illustratie zijn vermeld in de handleiding. De hoofdstukgrafieken en hoofdstukteksten zijn de instructiebronnen. Geen inhoudelijke fouten of terminologie zijn stilzwijgend gerepareerd tijdens het samenstellen.
