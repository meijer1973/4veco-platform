# Voorwoord

Economisch leren kijken
Je hebt tijd voor één activiteit, maar wilt er twee doen. Een winkel adverteert met een flinke
prijsdaling. Een verkoper houdt producten over. Achter zulke situaties zitten keuzes en getallen. In
dit boek leer je die stap voor stap onderzoeken.
In hoofdstuk 1 leer je economisch denken en nauwkeurig rekenen. Je gebruikt percentages,
indexcijfers, tabellen, grafieken en eenvoudige formules. Hoofdstuk 2 gaat over de keuzes van
kopers en de vraag naar producten. In hoofdstuk 3 komen de verkopers erbij. Je onderzoekt het
marktevenwicht en wat er verandert als koop- of verkoopplannen verschuiven.
Zo gebruik je dit boek
Lees de uitleg en bestudeer het uitgewerkte voorbeeld. Maak daarna de startopgaven. De
begeleide inoefening geeft extra steun. Bij de zelfstandige oefening en de doeloefening pas je de
methode zelf toe.
De kernroute
Startopgaven → Zelfstandige oefening → Doeloefening
Extra hulp nodig? Maak eerst Begeleide inoefening. De denkertjes bieden extra uitdaging; herhalingsopgaven
halen eerder geleerde stof terug.
Elk hoofdstuk eindigt met gemengde opgaven. Daar kies je zelf de passende aanpak. Gebruik een
schrift, ruitjespapier, potlood, liniaal en zo nodig een rekenmachine. Laat je berekening zien,
vermeld de eenheid en leg uit wat je uitkomst betekent.
De antwoorden staan in een afzonderlijk antwoordboek. Zoek met het hoofdstuknummer én het
opgavenummer: de nummering begint in elk hoofdstuk opnieuw. Met de inhoudsopgave en de
naslag achterin vind je de uitleg terug.
Deze basis neem je mee naar Boek 2, waar kosten, opbrengsten, elasticiteit en surplus hun eigen
uitleg krijgen.
