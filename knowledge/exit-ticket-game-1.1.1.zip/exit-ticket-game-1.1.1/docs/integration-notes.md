# Integration notes — Exit Ticket game v3

## Intended repository split

Reusable game code belongs in `4veco-platform`:

- `engines/exit-ticket-engine.js`
- `engines/exit-ticket-ui.js`
- `engines/exit-ticket.css`
- `build-scripts/platform/build-exit-ticket-shells.js`

Paragraph-specific data belongs in the lesson target:

- `4veco-lessen/Boek 1 - Grondslagen, vraag en aanbod/shared/exit-ticket/1.1.1.js`

Generated shells belong in the paragraph root:

- `1.1.1 Schaarste en economisch denken – exit-ticket.html`

## Deploy integration points

The current automated layer already has a pattern for quiz, reasoning, skilltree, newsdetective, and procedure shells. Exit Ticket follows that pattern:

1. Ensure deploy creates or preserves `shared/exit-ticket/`.
2. Copy source engine files from platform `engines/` into target `shared/`:
   - `exit-ticket-engine.js`
   - `exit-ticket-ui.js`
   - `exit-ticket.css`
3. Run `build-scripts/platform/build-exit-ticket-shells.js`.
4. Add an Exit Ticket link/card to paragraph `index.html` through the landing-page generator.
5. Add validator rules only after the team decides whether Exit Ticket is mandatory for every Part B paragraph.

## v3 data schema

The v3 schema uses a variant factory instead of a single fixed `ticket` object. This lets the paragraph retain one target-exercise structure while randomizing context and numbers.

```js
var EXIT_TICKET_DATA = {
  meta: {
    parNr: '1.1.1',
    parName: 'Schaarste en economisch denken',
    adaptiveKey: '4veco:adaptive:1.1.1',
    storageVersion: 'v3',
    domainColors: { primary, primaryDk, primaryLt, accent, navy },
    source: { blueprint, paragraphPlan, paragraphMarkdown }
  },
  createTicketVariant: function (ctx) {
    return {
      title: 'Exit ticket — ...',
      subtitle: '...',
      mastery: {
        passScore: 15,
        phasePassScores: { '1': 10, '2': 5 },
        requireCritical: true
      },
      variant: {
        id: '...',
        signature: '...',
        contextLabel: '...',
        // generated numbers and labels used by the tasks
      },
      scenario: { title, text, table: { headers, rows } },
      selfEvaluation: { title, intro, checks: [] },
      tasks: [
        {
          id: 'chosen_profit',
          phase: 1,
          type: 'calculation',
          points: 3,
          critical: true,
          minimumPoints: 3,
          formula: '10 × €500 = €5.000',
          answer: 5000,
          assessment: {
            calculation: { points: 1, patterns: [], minimumMatches: 3 },
            answer: { points: 1, value: 5000, tolerance: 0 },
            unit: { points: 1, expected: '€', patterns: ['/^(€|eur|euro|euros)$/i'] }
          }
        },
        { id, phase: 1, type: 'choice', answer, options, points, critical },
        { id, phase: 2, type: 'text', rubric: [{ patterns, points }], points, critical, minimumPoints }
      ]
    };
  }
};
```

## Phase behaviour

- **Phase 1** contains calculations and multiple choice only.
- **Phase 2** contains two open regex/rubric questions.
- There is **no teacher-review gate**.
- A failed phase locks the current form; the student starts a new randomized variant.
- A passed final result displays a self-evaluation checklist.

## Calculation-task behaviour

A calculation task is not a single answer box. It has:

1. `calculation`: light regex check. For example, it may require both input numbers and a multiplication or addition marker.
2. `answer`: parsed as a Dutch/European number; `€5.000`, `5000`, and `5.000,00` parse correctly.
3. `unit`: regex-checked separately. For §1.1.1, accepted monetary units are `€`, `eur`, `euro`, and `euros`.

This matches exam-form discipline: the answer can be numerically correct but still fail if the calculation or unit is missing.

## Randomization behaviour

The engine stores an active seed in localStorage and generates the variant from that seed. A new attempt calls `startNewAttempt()`, which tries to avoid the previous variant signature. The data file defines the actual variant surface:

- context family;
- scarce resource;
- alternatives;
- amounts;
- unit profits;
- comparison split.

The target exercise stays invariant even when the surface story changes.

## Adaptive seam

The engine reads the first valid JSON payload it finds under these keys:

- explicit `meta.adaptiveKey`, e.g. `4veco:adaptive:1.1.1`;
- `4veco:adaptive:<parNr>`;
- `4veco_adaptive_payload_<parNr>`;
- `exit_ticket_adaptive_<parNr>`.

The current implementation only supports `focusTaskIds`. It may highlight tasks but cannot hide target-exercise tasks or lower the pass threshold. This keeps the exit ticket valid as mastery evidence.

## Open assessment policy

Open answers are machine-scored by regex/rubric. That is now the intended classroom behaviour for this prototype. The UI should not label the result as “teacher approved,” and the engine does not require or store a teacher decision.

For high-stakes assessment, this remains a training tool rather than formal summative marking.
