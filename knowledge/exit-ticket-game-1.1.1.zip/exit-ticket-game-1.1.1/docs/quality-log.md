# Quality log — Exit Ticket game prototype v3

## Issue 1 — Exit Ticket is not yet a registered companion artifact

- scope: companion / game
- paragraph id: all paragraphs; prototype built for 1.1.1
- evidence path or source URL: platform `BUILD-PARAGRAPH.md` currently lists quiz, reasoning, newsdetective, procedure, and skilltree game data, not exit-ticket data
- affected artifact family: companion / game / validator
- severity: medium
- next action: decide whether Exit Ticket becomes a mandatory Part B artifact; if yes, update `BUILD-PARAGRAPH.md`, deploy, landing-page generator, and `validate-paragraph.js`
- platform handoff required: yes
- proof required to close: deploy creates `– exit-ticket.html`; paragraph landing page links it; complete-mode validator recognises it; Book 1 checks pass

## Issue 2 — Calculation/answer/unit schema needs validator support

- scope: companion / game / validator
- paragraph id: all paragraphs that receive an Exit Ticket
- evidence path or source URL: `platform/engines/exit-ticket-engine.js`, `shared/exit-ticket/1.1.1.js`
- affected artifact family: game / validator
- severity: medium
- next action: add schema checks for `type: 'calculation'`, including `assessment.calculation`, `assessment.answer`, and `assessment.unit`
- platform handoff required: yes
- proof required to close: validator rejects malformed calculation tasks; unit regex and answer values are checked in fixture tests

## Issue 3 — Randomized variants need deterministic QA fixtures

- scope: companion / game / QA
- paragraph id: 1.1.1 prototype, future randomized exit tickets
- evidence path or source URL: `shared/exit-ticket/1.1.1.js` uses `createTicketVariant(ctx)` and seeded randomization
- affected artifact family: game / tests
- severity: medium
- next action: add platform-level fixture tests with fixed seeds so generated contexts, formulas, answer values, and regex patterns can be reviewed deterministically
- platform handoff required: yes
- proof required to close: CI runs fixed-seed snapshots for at least one variant per context family and confirms no duplicate variant signature on retake smoke tests

## Issue 4 — Exit Ticket link is not yet integrated into generated paragraph landing pages

- scope: companion / landing page
- paragraph id: 1.1.1 prototype
- evidence path or source URL: generated shell exists in this package, but platform landing-page generator is not changed in this prototype
- affected artifact family: companion / game
- severity: medium
- next action: update platform landing-page generator after game acceptance
- platform handoff required: yes
- proof required to close: paragraph `index.html` includes Exit Ticket card/link after deploy; link checker passes

## Issue 5 — Self-evaluation is browser-local and not persisted as learning evidence

- scope: companion / game / evidence
- paragraph id: 1.1.1 prototype
- evidence path or source URL: `platform/engines/exit-ticket-ui.js`, `ticket.selfEvaluation`
- affected artifact family: game
- severity: low
- next action: decide whether self-evaluation checkboxes should remain non-persistent or be exported with the result payload
- platform handoff required: yes, if persistence/export is desired
- proof required to close: teacher/team policy documented; UI either clearly labels self-evaluation as non-scored or stores/exports it through the chosen workflow
