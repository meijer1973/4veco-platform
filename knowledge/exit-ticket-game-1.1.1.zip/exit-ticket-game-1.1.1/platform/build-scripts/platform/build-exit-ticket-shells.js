#!/usr/bin/env node
/**
 * build-exit-ticket-shells.js (flat layout)
 *
 * Generates slim HTML shell files for the Exit Ticket game.
 * Reads paragraph data from /shared/exit-ticket/X.Y.Z.js and writes the shell
 * directly to each paragraph root.
 *
 * HOW TO ADAPT:
 * - Keep paragraph content in shared/exit-ticket/X.Y.Z.js.
 * - Add this script to scripts/deploy.js after the shared engine copy step and
 *   after deploy-config has been loaded.
 * - Ensure deploy copies engines/exit-ticket-engine.js, exit-ticket-ui.js and
 *   exit-ticket.css to the book target's shared/ folder.
 *
 * Run:
 *   MODULE_ROOT="../4veco-lessen/Boek 1 - Grondslagen, vraag en aanbod" \
 *   node build-scripts/platform/build-exit-ticket-shells.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { loadConfig } = require('../lib/lib-deploy-config');

const MODULE_ROOT = process.env.MODULE_ROOT
  ? path.resolve(process.env.MODULE_ROOT)
  : path.resolve(__dirname, '../..');

const CONFIG = loadConfig(MODULE_ROOT);
const DATA_DIR = path.join(MODULE_ROOT, 'shared', 'exit-ticket');

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function loadTicketData(filePath) {
  const source = fs.readFileSync(filePath, 'utf8');
  const context = { EXIT_TICKET_DATA: null };
  vm.createContext(context);
  vm.runInContext(source + '\nthis.__result = EXIT_TICKET_DATA;', context, { filename: filePath });
  return context.__result;
}

function generateShell(parNr, parName, data) {
  const title = (data && data.ticket && data.ticket.title) || `${parName} – Exit ticket`;
  const sharedPath = '../../shared';
  return `<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(parName)} – Exit ticket</title>
  <link rel="stylesheet" href="${sharedPath}/exit-ticket.css">
</head>
<body class="exit-ticket-page">
  <main class="et-page-shell">
    <a class="et-back-link" href="index.html">← Overzicht</a>
    <noscript>Deze exit ticket werkt alleen met JavaScript ingeschakeld.</noscript>
    <div id="exit-ticket-app" data-par-nr="${escapeHtml(parNr)}" aria-label="${escapeHtml(title)}"></div>
  </main>
  <script src="${sharedPath}/theme.js"></script>
  <script src="${sharedPath}/exit-ticket/${escapeHtml(parNr)}.js"></script>
  <script src="${sharedPath}/exit-ticket-engine.js"></script>
  <script src="${sharedPath}/exit-ticket-ui.js"></script>
</body>
</html>
`;
}

function main() {
  if (!fs.existsSync(DATA_DIR)) {
    console.log('No exit-ticket data directory — nothing to generate.');
    return;
  }

  const dataFiles = fs.readdirSync(DATA_DIR).filter(f => f.endsWith('.js')).sort();
  console.log(`Found ${dataFiles.length} exit-ticket data file(s)\n`);

  let generated = 0;
  let errors = 0;

  for (const file of dataFiles) {
    const parNr = file.replace(/\.js$/, '');
    const p = CONFIG.paragraphIndex[parNr];
    if (!p) {
      console.warn(` [skip] ${parNr}: not declared in manifest`);
      continue;
    }

    const found = CONFIG.findParagraphFolder(parNr);
    if (!found) {
      console.error(` [error] ${parNr}: paragraph folder not found on disk`);
      errors++;
      continue;
    }

    try {
      const data = loadTicketData(path.join(DATA_DIR, file));
      const html = generateShell(parNr, p.name, data);
      const outPath = path.join(found.fullPath, `${parNr} ${p.name} – exit-ticket.html`);
      fs.writeFileSync(outPath, html, 'utf8');
      console.log(` [write] ${path.relative(MODULE_ROOT, outPath)}`);
      generated++;
    } catch (error) {
      console.error(` [error] ${parNr}: ${error.message}`);
      errors++;
    }
  }

  console.log(`\nDone: ${generated} generated, ${errors} errors`);
}

main();
