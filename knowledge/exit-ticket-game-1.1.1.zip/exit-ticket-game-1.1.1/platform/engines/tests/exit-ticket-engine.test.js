/**
 * Unit tests for ExitTicketEngine v3.
 * Run standalone during prototype review:
 *   node platform/engines/tests/exit-ticket-engine.test.js
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Mock localStorage for Node.js
let store = {};
global.localStorage = {
  getItem(key) { return Object.prototype.hasOwnProperty.call(store, key) ? store[key] : null; },
  setItem(key, value) { store[key] = String(value); },
  removeItem(key) { delete store[key]; },
  clear() { store = {}; }
};

const ExitTicketEngine = require('../exit-ticket-engine');

function loadData() {
  const dataPath = path.resolve(__dirname, '../../../lessen/Boek 1 - Grondslagen, vraag en aanbod/shared/exit-ticket/1.1.1.js');
  const source = fs.readFileSync(dataPath, 'utf8');
  const context = { EXIT_TICKET_DATA: null };
  vm.createContext(context);
  vm.runInContext(source + '\nthis.__result = EXIT_TICKET_DATA;', context, { filename: dataPath });
  return context.__result;
}

function byId(engine, id) {
  const task = engine.getTask(id);
  assert.ok(task, `missing task ${id}`);
  return task;
}

function setCalculation(engine, id, overrides = {}) {
  const task = byId(engine, id);
  engine.setResponse(id, {
    calculation: overrides.calculation != null ? overrides.calculation : task.formula,
    answer: overrides.answer != null ? overrides.answer : String(task.answer),
    unit: overrides.unit != null ? overrides.unit : '€'
  });
}

function setPerfectPhase1(engine) {
  setCalculation(engine, 'chosen_profit');
  setCalculation(engine, 'opportunity_cost');
  setCalculation(engine, 'comparison_profit');
  engine.setResponse('better_choice', 'no');
}

function setPerfectPhase2(engine) {
  const v = engine.getVariantSummary();
  engine.setResponse(
    'scarcity_context',
    `Het schaarse middel is ${v.resourceAmount} ${v.resourceUnitPlural} ${v.resourceLabel}. De alternatieven zijn ${v.optionA} en ${v.optionB}.`
  );
  engine.setResponse(
    'final_judgement',
    `Door schaarste is het middel beperkt. ${v.optionA} heeft de hoogste winst per ${v.resourceUnitSingular}. De ene keuze levert €${v.allAResult} op en de vergelijking levert €${v.comparisonResult} op; het verschil is €${v.difference}. De alternatieve kosten zijn €${v.opportunityCost}.`
  );
}

(function run() {
  localStorage.clear();
  const data = loadData();
  const engine = new ExitTicketEngine(data);

  assert.strictEqual(engine.parNr, '1.1.1');
  assert.strictEqual(engine.getMaxScore(), 15);
  assert.strictEqual(engine.getPassScore(), 15);
  assert.strictEqual(engine.getMaxScore({ phase: 1 }), 10);
  assert.strictEqual(engine.getPassScore({ phase: 1 }), 10);
  assert.strictEqual(engine.getMaxScore({ phase: 2 }), 5);
  assert.strictEqual(engine.getPassScore({ phase: 2 }), 5);
  assert.strictEqual(engine.getTasks({ phase: 1 }).length, 4);
  assert.strictEqual(engine.getTasks({ phase: 2 }).length, 2);
  assert.strictEqual(ExitTicketEngine.parseNumber('€5.000'), 5000);
  assert.strictEqual(ExitTicketEngine.parseNumber('4.400'), 4400);
  assert.strictEqual(ExitTicketEngine.parseNumber('5.000,50'), 5000.5);

  setPerfectPhase1(engine);
  assert.strictEqual(engine.isComplete({ phase: 1 }), true);
  const phase1 = engine.gradePhase(1);
  assert.strictEqual(phase1.score, 10);
  assert.strictEqual(phase1.passed, true);

  setPerfectPhase2(engine);
  assert.strictEqual(engine.isComplete({ phase: 2 }), true);
  const phase2 = engine.gradePhase(2);
  assert.strictEqual(phase2.score, 5);
  assert.strictEqual(phase2.passed, true);

  const perfect = engine.finalize({ '1': phase1, '2': phase2 });
  assert.strictEqual(perfect.score, 15);
  assert.strictEqual(perfect.passed, true);
  assert.strictEqual(perfect.criticalPassed, true);
  assert.match(engine.buildEvidence(perfect), /BEHAALD/);
  assert.doesNotMatch(engine.buildEvidence(perfect), /docent/i);

  const engine2 = new ExitTicketEngine(data);
  assert.strictEqual(engine2.getProgress().best.score, 15, 'best score should persist');

  localStorage.clear();
  const missingUnit = new ExitTicketEngine(data);
  setCalculation(missingUnit, 'chosen_profit', { unit: '' });
  setCalculation(missingUnit, 'opportunity_cost');
  setCalculation(missingUnit, 'comparison_profit');
  missingUnit.setResponse('better_choice', 'no');
  const unitFail = missingUnit.gradePhase(1);
  assert.strictEqual(unitFail.passed, false, 'missing unit should fail phase 1');
  const chosenDetail = unitFail.details.find(d => d.id === 'chosen_profit');
  assert.ok(chosenDetail.subchecks.find(s => s.id === 'unit' && s.correct === false));

  localStorage.clear();
  const weakCalculation = new ExitTicketEngine(data);
  setCalculation(weakCalculation, 'chosen_profit', { calculation: 'ik weet het bedrag', unit: '€' });
  setCalculation(weakCalculation, 'opportunity_cost');
  setCalculation(weakCalculation, 'comparison_profit');
  weakCalculation.setResponse('better_choice', 'no');
  const calcFail = weakCalculation.gradePhase(1);
  assert.strictEqual(calcFail.passed, false, 'calculation box regex should be light but not empty/irrelevant');

  localStorage.clear();
  const weakText = new ExitTicketEngine(data);
  setPerfectPhase1(weakText);
  const p1 = weakText.gradePhase(1);
  weakText.setResponse('scarcity_context', 'Er zijn keuzes.');
  weakText.setResponse('final_judgement', 'Nee, dat is niet beter.');
  const p2 = weakText.gradePhase(2);
  const finalWeak = weakText.finalize({ '1': p1, '2': p2 });
  assert.strictEqual(p2.passed, false);
  assert.strictEqual(finalWeak.passed, false, 'regex failure in open questions should fail the exit ticket');

  localStorage.clear();
  const randomized = new ExitTicketEngine(data);
  const sig1 = randomized.getVariantSummary().signature;
  randomized.startNewAttempt();
  const sig2 = randomized.getVariantSummary().signature;
  assert.notStrictEqual(sig1, sig2, 'new attempt should generate a different variant signature');

  localStorage.clear();
  localStorage.setItem('4veco:adaptive:1.1.1', JSON.stringify({ mode: 'focus', focusTaskIds: ['opportunity_cost'] }));
  const adaptive = new ExitTicketEngine(data);
  const focused = adaptive.getTasks({ phase: 1 }).find(t => t.id === 'opportunity_cost');
  assert.strictEqual(focused.focusedByAdaptivePayload, true);

  console.log('ExitTicketEngine v3 tests passed.');
})();
