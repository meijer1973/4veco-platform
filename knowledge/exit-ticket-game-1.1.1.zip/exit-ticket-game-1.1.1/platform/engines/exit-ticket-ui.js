/**
 * Exit Ticket Game — UI layer.
 * Depends on: theme.js (optional), shared/exit-ticket/X.Y.Z.js, exit-ticket-engine.js.
 */
(function () {
  'use strict';

  var data = window.EXIT_TICKET_DATA;
  if (!data || !window.ExitTicketEngine) return;

  var app = document.getElementById('exit-ticket-app');
  if (!app) return;

  var meta = data.meta || {};
  var parNr = meta.parNr || '0.0.0';
  var chapterKey = parNr.split('.').slice(0, 2).join('.');
  var domainColors = meta.domainColors || (window.DOMAIN_COLORS && window.DOMAIN_COLORS[chapterKey]) || {
    primary: '#17A2B8',
    primaryDk: '#117A8B',
    primaryLt: '#E8F8FB',
    accent: '#F8C471',
    navy: '#1E2761'
  };

  var rootStyle = document.documentElement.style;
  rootStyle.setProperty('--et-primary', domainColors.primary);
  rootStyle.setProperty('--et-primary-dk', domainColors.primaryDk);
  rootStyle.setProperty('--et-primary-lt', domainColors.primaryLt);
  rootStyle.setProperty('--et-accent', domainColors.accent || '#F8C471');
  rootStyle.setProperty('--et-navy', domainColors.navy || '#1E2761');

  var engine = new window.ExitTicketEngine(data);
  var currentPhase = 1;
  var phaseResults = {};
  var finalResult = null;

  function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str == null ? '' : String(str);
    return d.innerHTML.replace(/\n/g, '<br>');
  }

  function formatNumber(value) {
    if (typeof value !== 'number' || !isFinite(value)) return String(value || '');
    return value.toLocaleString('nl-NL', { maximumFractionDigits: 2 });
  }

  function render() {
    var ticket = engine.ticket || {};
    var scenario = ticket.scenario || {};
    var tasks = engine.getTasks({ phase: currentPhase });
    var progress = engine.getProgress();
    var best = progress.best;
    var adaptive = engine.adaptivePayload || {};
    var variant = engine.getVariantSummary ? engine.getVariantSummary() : (ticket.variant || {});

    app.innerHTML = '' +
      '<section class="et-hero">' +
        '<div class="et-hero-main">' +
          '<p class="et-kicker">§' + escapeHtml(parNr) + ' · Exit ticket</p>' +
          '<h1>' + escapeHtml(ticket.title || meta.parName || 'Exit ticket') + '</h1>' +
          '<p class="et-subtitle">' + escapeHtml(ticket.subtitle || meta.subtitle || '') + '</p>' +
          '<div class="et-variant-line">Variant: <strong>' + escapeHtml(variant.contextLabel || 'standaard') + '</strong>' +
            (variant.id ? ' · <code>' + escapeHtml(variant.id) + '</code>' : '') +
          '</div>' +
        '</div>' +
        '<aside class="et-scorebox" aria-live="polite">' +
          '<span>Mastery-eis</span>' +
          '<strong>' + engine.getPassScore() + '/' + engine.getMaxScore() + '</strong>' +
          '<small>' + (best ? 'Beste poging: ' + best.score + '/' + best.maxScore : 'Nog geen volledige poging') + '</small>' +
        '</aside>' +
      '</section>' +

      '<section class="et-panel et-scenario">' +
        '<div>' +
          '<p class="et-label">Target exercise</p>' +
          '<h2>' + escapeHtml(scenario.title || 'Situatie') + '</h2>' +
          '<p>' + escapeHtml(scenario.text || '') + '</p>' +
          renderTable(scenario.table) +
        '</div>' +
      '</section>' +

      (adaptive && adaptive._sourceKey ? '<div class="et-adaptive-note">Adaptieve focus gelezen uit <code>' + escapeHtml(adaptive._sourceKey) + '</code>. Alle target-onderdelen blijven verplicht.</div>' : '') +

      renderPhasePanel(ticket) +

      '<form id="et-form" class="et-form">' +
        tasks.map(renderTask).join('') +
        '<div class="et-actions">' +
          '<button type="submit" class="et-button et-button-primary" id="et-submit">' + (currentPhase === 1 ? 'Controleer fase 1' : 'Controleer open vragen') + '</button>' +
          '<button type="button" class="et-button" id="et-reset">Nieuwe variant</button>' +
          '<button type="button" class="et-button" id="et-copy" disabled>Kopieer resultaat</button>' +
        '</div>' +
      '</form>' +
      '<section id="et-result" class="et-result" aria-live="polite"></section>';

    bindEvents();
  }

  function renderPhasePanel(ticket) {
    var phase1Max = engine.getMaxScore({ phase: 1 });
    var phase1Pass = engine.getPassScore({ phase: 1 });
    var phase2Max = engine.getMaxScore({ phase: 2 });
    var phase2Pass = engine.getPassScore({ phase: 2 });

    if (currentPhase === 1) {
      return '<section class="et-panel et-phase-panel">' +
        '<p class="et-label">Fase 1 · machine-audit</p>' +
        '<h2>Berekeningen en meerkeuze eerst</h2>' +
        '<p>Vul bij elke berekening drie aparte velden in: <strong>berekening</strong>, <strong>antwoord</strong> en <strong>eenheid</strong>. De machine controleert dit strikt. Eis: ' + phase1Pass + '/' + phase1Max + '.</p>' +
      '</section>';
    }

    var phase1 = phaseResults['1'];
    return '<section class="et-panel et-phase-panel et-phase-pass">' +
      '<p class="et-label">Fase 2 · open regex-vragen</p>' +
      '<h2>Fase 1 gehaald</h2>' +
      '<p>Machine-audit fase 1: <strong>' + (phase1 ? phase1.score + '/' + phase1.maxScore : phase1Pass + '/' + phase1Max) + '</strong>. Beantwoord nu twee open vragen. Als de regex-check een kernpunt mist, is de poging niet gehaald en start je opnieuw met een andere variant. Eis: ' + phase2Pass + '/' + phase2Max + '.</p>' +
      (ticket.selfEvaluation ? '<p class="et-muted-line">Na een geslaagde regex-check verschijnt de zelfevaluatie.</p>' : '') +
    '</section>';
  }

  function renderTable(table) {
    if (!table || !Array.isArray(table.headers) || !Array.isArray(table.rows)) return '';
    return '<div class="et-table-wrap"><table class="et-table"><thead><tr>' +
      table.headers.map(function (h) { return '<th>' + escapeHtml(h) + '</th>'; }).join('') +
      '</tr></thead><tbody>' +
      table.rows.map(function (row) {
        return '<tr>' + row.map(function (cell) { return '<td>' + escapeHtml(cell) + '</td>'; }).join('') + '</tr>';
      }).join('') +
      '</tbody></table></div>';
  }

  function renderTask(task, idx) {
    var focusClass = task.focusedByAdaptivePayload ? ' et-task-focus' : '';
    return '<article class="et-task' + focusClass + '" data-task-id="' + escapeHtml(task.id) + '">' +
      '<div class="et-task-head">' +
        '<span class="et-step">Fase ' + escapeHtml(task.phase || currentPhase) + ' · Stap ' + (idx + 1) + '</span>' +
        '<span class="et-points">' + escapeHtml(task.points || 0) + ' punt' + ((task.points || 0) === 1 ? '' : 'en') + '</span>' +
      '</div>' +
      '<label class="et-task-label" for="' + firstInputId(task) + '">' + escapeHtml(task.label || '') + '</label>' +
      '<p class="et-prompt">' + escapeHtml(task.prompt || '') + '</p>' +
      renderInput(task) +
      '<div class="et-feedback" id="et-feedback-' + escapeHtml(task.id) + '"></div>' +
    '</article>';
  }

  function firstInputId(task) {
    return task.type === 'calculation'
      ? 'et-' + escapeHtml(task.id) + '-calculation'
      : 'et-' + escapeHtml(task.id);
  }

  function renderInput(task) {
    if (task.type === 'calculation') {
      var formula = task.formula ? 'Bijv. ' + task.formula : 'Schrijf je berekening op';
      return '<div class="et-calculation-grid">' +
        '<label class="et-field-label" for="et-' + escapeHtml(task.id) + '-calculation">Berekening</label>' +
        '<textarea id="et-' + escapeHtml(task.id) + '-calculation" name="' + escapeHtml(task.id) + '__calculation" rows="2" required placeholder="' + escapeHtml(formula) + '"></textarea>' +
        '<div class="et-answer-unit-grid">' +
          '<label class="et-field-label" for="et-' + escapeHtml(task.id) + '-answer">Antwoord' +
            '<input id="et-' + escapeHtml(task.id) + '-answer" name="' + escapeHtml(task.id) + '__answer" type="text" inputmode="decimal" autocomplete="off" required placeholder="bedrag">' +
          '</label>' +
          '<label class="et-field-label et-unit-field" for="et-' + escapeHtml(task.id) + '-unit">Eenheid' +
            '<input id="et-' + escapeHtml(task.id) + '-unit" name="' + escapeHtml(task.id) + '__unit" type="text" autocomplete="off" required placeholder="€">' +
          '</label>' +
        '</div>' +
        '<p class="et-hint">Examenstijl: berekening, antwoord en eenheid worden apart gecontroleerd.</p>' +
      '</div>';
    }

    if (task.type === 'number') {
      return '<div class="et-input-row">' +
        (task.unit ? '<span class="et-unit">' + escapeHtml(task.unit) + '</span>' : '') +
        '<input id="et-' + escapeHtml(task.id) + '" name="' + escapeHtml(task.id) + '" type="text" inputmode="decimal" autocomplete="off" required placeholder="Jouw antwoord">' +
      '</div>';
    }

    if (task.type === 'choice') {
      var options = task.options || [];
      return '<fieldset class="et-choice" id="et-' + escapeHtml(task.id) + '">' +
        '<legend class="et-sr-only">' + escapeHtml(task.label || task.prompt || task.id) + '</legend>' +
        options.map(function (opt, idx) {
          var inputId = 'et-' + task.id + '-' + idx;
          return '<label class="et-choice-option" for="' + escapeHtml(inputId) + '">' +
            '<input id="' + escapeHtml(inputId) + '" type="radio" name="' + escapeHtml(task.id) + '" value="' + escapeHtml(opt.value) + '" required>' +
            '<span>' + escapeHtml(opt.label) + '</span>' +
          '</label>';
        }).join('') +
      '</fieldset>';
    }

    return '<textarea id="et-' + escapeHtml(task.id) + '" name="' + escapeHtml(task.id) + '" rows="4" required placeholder="Schrijf je redenering in volledige zinnen"></textarea>';
  }

  function bindEvents() {
    var form = document.getElementById('et-form');
    var resetBtn = document.getElementById('et-reset');
    var copyBtn = document.getElementById('et-copy');

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      collectResponses(currentPhase);

      if (!engine.isComplete({ phase: currentPhase })) {
        showIncompleteMessage();
        return;
      }

      var phaseResult = engine.gradePhase(currentPhase);
      phaseResults[String(currentPhase)] = phaseResult;

      if (currentPhase === 1) {
        if (phaseResult.passed) {
          currentPhase = 2;
          render();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
          renderResult(phaseResult, 'phase-fail');
          markTasks(phaseResult);
          lockCurrentForm();
        }
        return;
      }

      finalResult = engine.finalize(phaseResults);
      renderResult(finalResult, 'final');
      markTasks(phaseResult);
      lockCurrentForm();
      copyBtn.disabled = false;
    });

    resetBtn.addEventListener('click', function () {
      engine.startNewAttempt();
      currentPhase = 1;
      phaseResults = {};
      finalResult = null;
      render();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    copyBtn.addEventListener('click', function () {
      var evidence = engine.buildEvidence(finalResult);
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(evidence).then(function () {
          copyBtn.textContent = 'Gekopieerd';
          setTimeout(function () { copyBtn.textContent = 'Kopieer resultaat'; }, 1500);
        });
      } else {
        window.prompt('Kopieer dit resultaat:', evidence);
      }
    });
  }

  function showIncompleteMessage() {
    var resultEl = document.getElementById('et-result');
    resultEl.className = 'et-result et-retry';
    resultEl.innerHTML = '<div class="et-result-main"><p class="et-label">Nog niet compleet</p><h2>Vul alle verplichte velden in</h2><p>Elke berekening heeft een berekening, antwoord en eenheid nodig. Open vragen en meerkeuzevragen zijn ook verplicht.</p></div>';
    resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function lockCurrentForm() {
    var form = document.getElementById('et-form');
    if (!form) return;
    var controls = form.querySelectorAll('input, textarea, button[type="submit"]');
    Array.prototype.forEach.call(controls, function (control) {
      control.disabled = true;
    });
  }

  function collectResponses(phase) {
    var tasks = engine.getTasks({ phase: phase });
    engine.clearResponses({ phase: phase });
    tasks.forEach(function (task) {
      var value = '';
      if (task.type === 'choice') {
        var checked = document.querySelector('input[name="' + cssEscape(task.id) + '"]:checked');
        value = checked ? checked.value : '';
      } else if (task.type === 'calculation') {
        value = {
          calculation: getFieldValue('et-' + task.id + '-calculation'),
          answer: getFieldValue('et-' + task.id + '-answer'),
          unit: getFieldValue('et-' + task.id + '-unit')
        };
      } else {
        value = getFieldValue('et-' + task.id);
      }
      engine.setResponse(task.id, value);
    });
  }

  function getFieldValue(id) {
    var el = document.getElementById(id);
    return el ? el.value : '';
  }

  function cssEscape(value) {
    if (window.CSS && window.CSS.escape) return window.CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function renderResult(result, mode) {
    var resultEl = document.getElementById('et-result');
    var statusClass = result.passed ? 'et-pass' : 'et-retry';
    var heading;
    if (mode === 'phase-fail') {
      heading = 'Fase 1 niet gehaald';
    } else {
      heading = result.passed ? 'Beheersing aangetoond' : 'Nog niet voldoende';
    }

    resultEl.className = 'et-result ' + statusClass;
    resultEl.innerHTML = '' +
      '<div class="et-result-main">' +
        '<p class="et-label">Resultaat</p>' +
        '<h2>' + heading + '</h2>' +
        '<p class="et-result-score">' + result.score + '/' + result.maxScore + ' punten · ' + result.percentage + '%</p>' +
        '<p>' + escapeHtml(result.advice) + '</p>' +
      '</div>' +
      '<div class="et-meter" aria-hidden="true"><span style="width:' + result.percentage + '%"></span></div>' +
      '<details class="et-details" open><summary>Bekijk correctiemodel per stap</summary>' +
        '<ul>' + result.details.map(renderDetail).join('') + '</ul>' +
      '</details>' +
      renderSelfEvaluation(result);
    resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderDetail(detail) {
    var icon = detail.correct ? '✓' : '×';
    var extra = '';
    if (detail.type === 'calculation') {
      extra = renderCalculationDetail(detail);
    } else if (detail.type === 'number') {
      extra = detail.correct ? '' : ' Verwacht: ' + formatNumber(detail.expected) + '.';
    } else if (detail.type === 'choice') {
      extra = detail.correct ? '' : ' Correct: ' + escapeHtml(detail.expected) + '.';
    } else if (detail.type === 'text' && detail.missed && detail.missed.length) {
      extra = ' Mist nog: ' + detail.missed.map(function (m) { return escapeHtml(m.label); }).join(', ') + '.';
    }
    return '<li class="' + (detail.correct ? 'ok' : 'miss') + '"><strong>' + icon + ' ' + escapeHtml(detail.label) + '</strong> — ' + detail.pointsEarned + '/' + detail.points + ' p. ' + escapeHtml(detail.feedback) + extra + '</li>';
  }

  function renderCalculationDetail(detail) {
    var html = '';
    if (!detail.correct) {
      html += ' Verwacht antwoord: ' + escapeHtml(detail.expectedUnit || '') + formatNumber(detail.expected) + '. Verwachte berekening: ' + escapeHtml(detail.formula || '') + '.';
    }
    if (Array.isArray(detail.subchecks) && detail.subchecks.length) {
      html += '<ul class="et-subchecks">' + detail.subchecks.map(function (s) {
        var mark = s.correct ? '✓' : '×';
        var expected = '';
        if (!s.correct && s.expected !== '' && s.expected != null) {
          expected = ' Verwacht: ' + (typeof s.expected === 'number' ? formatNumber(s.expected) : escapeHtml(s.expected)) + '.';
        }
        return '<li class="' + (s.correct ? 'ok' : 'miss') + '">' + mark + ' ' + escapeHtml(s.label) + ': ' + s.pointsEarned + '/' + s.points + ' p.' + expected + '</li>';
      }).join('') + '</ul>';
    }
    if (Array.isArray(detail.selfCheck) && detail.selfCheck.length) {
      html += '<div class="et-task-selfcheck"><strong>Zelfcheck voor deze berekening:</strong><ul>' + detail.selfCheck.map(function (item) {
        return '<li>' + escapeHtml(item) + '</li>';
      }).join('') + '</ul></div>';
    }
    return html;
  }

  function renderSelfEvaluation(result) {
    if (!result || !result.passed) return '';
    var ticket = engine.ticket || {};
    var self = ticket.selfEvaluation || {};
    var checks = Array.isArray(self.checks) ? self.checks : [];
    if (!checks.length) return '';
    return '<section class="et-self-evaluation">' +
      '<p class="et-label">Zelfevaluatie</p>' +
      '<h3>' + escapeHtml(self.title || 'Controleer je eigen antwoord') + '</h3>' +
      '<p>' + escapeHtml(self.intro || 'Vink de punten af voor jezelf.') + '</p>' +
      '<div class="et-self-checks">' + checks.map(function (item, idx) {
        var id = 'et-self-' + idx;
        return '<label for="' + id + '"><input id="' + id + '" type="checkbox"> <span>' + escapeHtml(item) + '</span></label>';
      }).join('') + '</div>' +
      '<p class="et-hint">Deze zelfevaluatie verandert je score niet; de machinecheck is al gehaald.</p>' +
    '</section>';
  }

  function markTasks(result) {
    result.details.forEach(function (detail) {
      var article = document.querySelector('.et-task[data-task-id="' + cssEscape(detail.id) + '"]');
      var feedback = document.getElementById('et-feedback-' + detail.id);
      if (!article || !feedback) return;
      article.classList.toggle('et-task-correct', detail.correct);
      article.classList.toggle('et-task-wrong', !detail.correct);
      feedback.innerHTML = '<strong>' + detail.pointsEarned + '/' + detail.points + ' p.</strong> ' + escapeHtml(detail.feedback);
    });
  }

  render();
})();
