/**
 * ExitTicketEngine — pure logic for paragraph target-exercise mastery checks.
 *
 * v3 supports:
 * - phased exit tickets: phase 1 = calculations/MC, phase 2 = open regex questions;
 * - calculation tasks with separate calculation, answer, and unit fields;
 * - seeded random variants so retakes are not identical;
 * - self-evaluation after machine mastery, without a review gate.
 *
 * Paragraph-specific content belongs in shared/exit-ticket/X.Y.Z.js as
 * EXIT_TICKET_DATA. The engine stays generic and has no economics content baked in.
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = factory();
  } else {
    root.ExitTicketEngine = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function clone(value) {
    if (value == null) return value;
    return JSON.parse(JSON.stringify(value));
  }

  function hasLocalStorage() {
    try {
      return typeof localStorage !== 'undefined' && localStorage !== null;
    } catch (e) {
      return false;
    }
  }

  function normaliseText(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[’']/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function escapeRegex(str) {
    return String(str).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function parseNumber(value) {
    if (typeof value === 'number' && isFinite(value)) return value;
    if (value == null) return NaN;

    var raw = String(value)
      .trim()
      .replace(/€/g, '')
      .replace(/eur/ig, '')
      .replace(/euro/ig, '')
      .replace(/\s/g, '')
      .replace(/−/g, '-');

    if (!raw) return NaN;

    var hasComma = raw.indexOf(',') !== -1;
    var hasDot = raw.indexOf('.') !== -1;

    if (hasComma && hasDot) {
      // Dutch notation: 5.000,50 -> 5000.50
      raw = raw.replace(/\./g, '').replace(',', '.');
    } else if (hasComma) {
      raw = raw.replace(',', '.');
    } else if (hasDot && /^-?\d{1,3}(\.\d{3})+$/.test(raw)) {
      // Thousands separators only: 5.000 -> 5000
      raw = raw.replace(/\./g, '');
    }

    var num = Number(raw);
    return isFinite(num) ? num : NaN;
  }

  function formatNumber(value) {
    if (typeof value !== 'number' || !isFinite(value)) return String(value);
    return value.toLocaleString('nl-NL', { maximumFractionDigits: 2 });
  }

  function readJsonFromStorage(key) {
    if (!hasLocalStorage() || !key) return null;
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function writeJsonToStorage(key, value) {
    if (!hasLocalStorage() || !key) return;
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      // Ignore storage failures. The exit ticket remains playable.
    }
  }

  function buildAdaptiveKeys(parNr, explicitKey) {
    var keys = [];
    if (explicitKey) keys.push(explicitKey);
    if (parNr) {
      keys.push('4veco:adaptive:' + parNr);
      keys.push('4veco_adaptive_payload_' + parNr);
      keys.push('exit_ticket_adaptive_' + parNr);
    }
    return keys;
  }

  function readAdaptivePayload(parNr, explicitKey) {
    var keys = buildAdaptiveKeys(parNr, explicitKey);
    for (var i = 0; i < keys.length; i++) {
      var payload = readJsonFromStorage(keys[i]);
      if (payload && typeof payload === 'object') {
        payload._sourceKey = keys[i];
        return payload;
      }
    }
    return { mode: 'default', focusTaskIds: [], _sourceKey: null };
  }

  function matchesPattern(text, pattern) {
    if (!pattern) return false;
    if (pattern instanceof RegExp) return pattern.test(text);
    var source = String(pattern);
    if (source.indexOf('/') === 0 && source.lastIndexOf('/') > 0) {
      var last = source.lastIndexOf('/');
      try {
        var body = source.slice(1, last);
        var flags = source.slice(last + 1) || 'i';
        return new RegExp(body, flags).test(text);
      } catch (e) {
        return false;
      }
    }
    return new RegExp(escapeRegex(normaliseText(source)), 'i').test(text);
  }

  function randomSeed() {
    var timePart = Date.now() >>> 0;
    var randomPart = Math.floor(Math.random() * 0xFFFFFFFF) >>> 0;
    return (timePart ^ randomPart) >>> 0;
  }

  function makeRng(seed) {
    var t = seed >>> 0;
    return function () {
      t += 0x6D2B79F5;
      var r = Math.imul(t ^ (t >>> 15), 1 | t);
      r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
      return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
    };
  }

  function normaliseOptions(options) {
    if (typeof options === 'number' || typeof options === 'string') return { phase: Number(options) };
    return options || {};
  }

  function taskMatchesOptions(task, options) {
    options = normaliseOptions(options);
    if (options.phase != null && Number(task.phase || 1) !== Number(options.phase)) return false;
    if (Array.isArray(options.taskIds) && options.taskIds.indexOf(task.id) === -1) return false;
    return true;
  }

  function getValuePart(value, key) {
    if (value && typeof value === 'object' && !Array.isArray(value)) return value[key];
    if (key === 'answer') return value;
    return '';
  }

  function compactValue(value) {
    if (value && typeof value === 'object' && !Array.isArray(value)) return clone(value);
    return value == null ? '' : String(value);
  }

  function ExitTicketEngine(data) {
    if (!data) throw new Error('ExitTicketEngine: data is required');
    this.data = data;
    this.meta = data.meta || {};
    this.parNr = this.meta.parNr || data.parNr || '0.0.0';
    this.storageKey = 'exit_ticket_' + this.parNr + '_' + (this.meta.storageVersion || 'v3');
    this.responses = {};
    this.phaseResults = {};
    this.checked = false;
    this.lastResult = null;
    this.adaptivePayload = readAdaptivePayload(this.parNr, this.meta.adaptiveKey);
    this._loadProgress();
    this._ensureActiveAttempt();
    this._loadTicketFromActiveAttempt();
  }

  ExitTicketEngine.parseNumber = parseNumber;
  ExitTicketEngine.normaliseText = normaliseText;
  ExitTicketEngine.readAdaptivePayload = readAdaptivePayload;
  ExitTicketEngine.matchesPattern = matchesPattern;
  ExitTicketEngine.makeRng = makeRng;

  ExitTicketEngine.prototype._loadProgress = function () {
    var saved = readJsonFromStorage(this.storageKey);
    this.progress = saved && typeof saved === 'object' ? saved : { attempts: [], best: null, activeAttempt: null };
    if (!Array.isArray(this.progress.attempts)) this.progress.attempts = [];
  };

  ExitTicketEngine.prototype._saveProgress = function () {
    writeJsonToStorage(this.storageKey, this.progress);
  };

  ExitTicketEngine.prototype._ensureActiveAttempt = function () {
    if (this.progress.activeAttempt && typeof this.progress.activeAttempt.seed === 'number') return;
    this.progress.activeAttempt = {
      seed: randomSeed(),
      attemptIndex: this.progress.attempts.length + 1,
      startedAt: new Date().toISOString()
    };
    this._saveProgress();
  };

  ExitTicketEngine.prototype._buildTicketForSeed = function (seed, attemptIndex) {
    var ticket;
    if (typeof this.data.createTicketVariant === 'function') {
      ticket = this.data.createTicketVariant({
        seed: seed >>> 0,
        random: makeRng(seed),
        attemptIndex: attemptIndex || 1,
        parNr: this.parNr,
        formatNumber: formatNumber,
        parseNumber: parseNumber
      });
    } else if (typeof this.data.ticketFactory === 'function') {
      ticket = this.data.ticketFactory({
        seed: seed >>> 0,
        random: makeRng(seed),
        attemptIndex: attemptIndex || 1,
        parNr: this.parNr,
        formatNumber: formatNumber,
        parseNumber: parseNumber
      });
    } else {
      ticket = clone(this.data.ticket || {});
    }

    if (!ticket || !Array.isArray(ticket.tasks) || !ticket.tasks.length) {
      throw new Error('ExitTicketEngine: ticket.tasks is required');
    }

    ticket.variant = ticket.variant || {};
    ticket.variant.seed = seed >>> 0;
    if (!ticket.variant.signature) {
      ticket.variant.signature = String(seed >>> 0);
    }
    return ticket;
  };

  ExitTicketEngine.prototype._loadTicketFromActiveAttempt = function () {
    var active = this.progress.activeAttempt || { seed: 0, attemptIndex: 1 };
    this.ticket = this._buildTicketForSeed(active.seed, active.attemptIndex);
    this.tasks = this.ticket.tasks || [];
    this.variant = this.ticket.variant || {};
  };

  ExitTicketEngine.prototype.startNewAttempt = function () {
    var previousSignature = this.variant && this.variant.signature;
    var attemptIndex = this.progress.attempts.length + 1;
    var chosenSeed = randomSeed();
    var chosenTicket = null;

    for (var tries = 0; tries < 12; tries++) {
      var candidateSeed = (chosenSeed + tries + Math.floor(Math.random() * 9973)) >>> 0;
      var candidateTicket = this._buildTicketForSeed(candidateSeed, attemptIndex);
      if (!previousSignature || candidateTicket.variant.signature !== previousSignature || tries === 11) {
        chosenSeed = candidateSeed;
        chosenTicket = candidateTicket;
        break;
      }
    }

    this.responses = {};
    this.phaseResults = {};
    this.checked = false;
    this.lastResult = null;
    this.progress.activeAttempt = {
      seed: chosenSeed >>> 0,
      attemptIndex: attemptIndex,
      startedAt: new Date().toISOString()
    };
    this.ticket = chosenTicket || this._buildTicketForSeed(chosenSeed, attemptIndex);
    this.tasks = this.ticket.tasks || [];
    this.variant = this.ticket.variant || {};
    this._saveProgress();
    return this.variant;
  };

  ExitTicketEngine.prototype.resetAttempt = function () {
    // Backwards-compatible name: this now starts a fresh randomized attempt.
    return this.startNewAttempt();
  };

  ExitTicketEngine.prototype.clearResponses = function (options) {
    options = normaliseOptions(options);
    if (options.phase == null && !options.taskIds) {
      this.responses = {};
      this.phaseResults = {};
      this.checked = false;
      this.lastResult = null;
      return;
    }
    for (var i = 0; i < this.tasks.length; i++) {
      if (taskMatchesOptions(this.tasks[i], options)) delete this.responses[this.tasks[i].id];
    }
  };

  ExitTicketEngine.prototype.setResponse = function (taskId, value) {
    if (!this.getTask(taskId)) return false;
    this.responses[taskId] = value;
    return true;
  };

  ExitTicketEngine.prototype.getResponse = function (taskId) {
    return this.responses[taskId];
  };

  ExitTicketEngine.prototype.getTask = function (taskId) {
    for (var i = 0; i < this.tasks.length; i++) {
      if (this.tasks[i].id === taskId) return this.tasks[i];
    }
    return null;
  };

  ExitTicketEngine.prototype.getTasks = function (options) {
    options = normaliseOptions(options);
    var focus = (this.adaptivePayload && this.adaptivePayload.focusTaskIds) || [];
    var out = [];
    for (var i = 0; i < this.tasks.length; i++) {
      var task = this.tasks[i];
      if (!taskMatchesOptions(task, options)) continue;
      var copy = clone(task);
      copy.focusedByAdaptivePayload = focus.indexOf(task.id) !== -1;
      out.push(copy);
    }
    return out;
  };

  ExitTicketEngine.prototype.getMaxScore = function (options) {
    var tasks = this.getTasks(options);
    return tasks.reduce(function (sum, task) {
      return sum + (Number(task.points) || 0);
    }, 0);
  };

  ExitTicketEngine.prototype.getPassScore = function (options) {
    options = normaliseOptions(options);
    var mastery = this.ticket.mastery || {};
    if (options.phase != null && mastery.phasePassScores && typeof mastery.phasePassScores[options.phase] === 'number') {
      return mastery.phasePassScores[options.phase];
    }
    return typeof mastery.passScore === 'number'
      ? mastery.passScore
      : Math.ceil(this.getMaxScore(options) * 0.8);
  };

  ExitTicketEngine.prototype.isComplete = function (options) {
    var tasks = this.getTasks(options);
    for (var i = 0; i < tasks.length; i++) {
      var task = tasks[i];
      if (task.required === false) continue;
      var value = this.responses[task.id];
      if (task.type === 'calculation') {
        if (String(getValuePart(value, 'calculation') || '').trim() === '') return false;
        if (String(getValuePart(value, 'answer') || '').trim() === '') return false;
        if (String(getValuePart(value, 'unit') || '').trim() === '') return false;
      } else if (value == null || String(value).trim() === '') {
        return false;
      }
    }
    return true;
  };

  ExitTicketEngine.prototype.grade = function (options) {
    options = normaliseOptions(options);
    var tasks = this.getTasks(options);
    return this._gradeSelected(tasks, options, options.record !== false);
  };

  ExitTicketEngine.prototype.gradePhase = function (phase) {
    var options = { phase: Number(phase), record: false };
    var result = this._gradeSelected(this.getTasks(options), options, false);
    this.phaseResults[String(phase)] = result;
    return result;
  };

  ExitTicketEngine.prototype.finalize = function (phaseResults) {
    var supplied = phaseResults || this.phaseResults || {};
    var ordered = [];
    var seen = {};
    var allTasks = this.getTasks();
    var i;

    for (i = 1; i <= 9; i++) {
      var r = supplied[String(i)] || supplied[i];
      if (r) ordered.push(r);
    }
    if (!ordered.length) {
      return this.grade({ record: true });
    }

    var details = [];
    var score = 0;
    var maxScore = 0;
    var phasePassed = true;
    for (i = 0; i < ordered.length; i++) {
      var result = ordered[i];
      phasePassed = phasePassed && !!result.passed;
      score += result.score;
      maxScore += result.maxScore;
      for (var j = 0; j < result.details.length; j++) {
        details.push(result.details[j]);
        seen[result.details[j].id] = true;
      }
    }

    // If a caller finalizes after all phases, this branch is not used. It protects
    // against accidental partial finalization by counting ungraded required tasks as missing.
    for (i = 0; i < allTasks.length; i++) {
      if (!seen[allTasks[i].id]) {
        var missing = this._gradeTask(allTasks[i], this.responses[allTasks[i].id]);
        details.push(missing);
        score += missing.pointsEarned;
        maxScore += missing.points;
      }
    }

    var passScore = this.getPassScore();
    var criticalFailures = this._criticalFailures(details, allTasks);
    var percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
    var criticalPassed = criticalFailures.length === 0;
    var passed = score >= passScore && criticalPassed && phasePassed;
    var finalResult = {
      checkedAt: new Date().toISOString(),
      parNr: this.parNr,
      phase: 'final',
      variant: clone(this.variant),
      score: score,
      maxScore: maxScore,
      passScore: passScore,
      percentage: percentage,
      passed: passed,
      criticalPassed: criticalPassed,
      phasePassed: phasePassed,
      criticalFailures: criticalFailures,
      details: details,
      responses: clone(this.responses),
      advice: this._buildAdvice(details, passed, criticalFailures)
    };

    this.checked = true;
    this.lastResult = finalResult;
    this._recordAttempt(finalResult);
    return finalResult;
  };

  ExitTicketEngine.prototype._gradeSelected = function (tasks, options, record) {
    var details = [];
    var score = 0;
    var selectedTasks = tasks || [];

    for (var i = 0; i < selectedTasks.length; i++) {
      var task = selectedTasks[i];
      var value = this.responses[task.id];
      var graded = this._gradeTask(task, value);
      details.push(graded);
      score += graded.pointsEarned;
    }

    var maxScore = selectedTasks.reduce(function (sum, task) { return sum + (Number(task.points) || 0); }, 0);
    var passScore = this.getPassScore(options);
    var percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
    var criticalFailures = this._criticalFailures(details, selectedTasks);
    var criticalPassed = criticalFailures.length === 0;
    var passed = score >= passScore && criticalPassed;

    var result = {
      checkedAt: new Date().toISOString(),
      parNr: this.parNr,
      phase: options && options.phase != null ? Number(options.phase) : 'all',
      variant: clone(this.variant),
      score: score,
      maxScore: maxScore,
      passScore: passScore,
      percentage: percentage,
      passed: passed,
      criticalPassed: criticalPassed,
      criticalFailures: criticalFailures,
      details: details,
      responses: clone(this.responses),
      advice: this._buildAdvice(details, passed, criticalFailures)
    };

    if (record) {
      this.checked = true;
      this.lastResult = result;
      this._recordAttempt(result);
    }
    return result;
  };

  ExitTicketEngine.prototype._criticalFailures = function (details, tasks) {
    var byId = {};
    var failures = [];
    var i;
    for (i = 0; i < details.length; i++) byId[details[i].id] = details[i];
    for (i = 0; i < tasks.length; i++) {
      var task = tasks[i];
      if (!task.critical) continue;
      var detail = byId[task.id];
      var min = typeof task.minimumPoints === 'number'
        ? task.minimumPoints
        : (Number(task.points) || 0);
      if (!detail || detail.pointsEarned < min) {
        failures.push({ id: task.id, label: task.label || task.prompt || task.id });
      }
    }
    return failures;
  };

  ExitTicketEngine.prototype._recordAttempt = function (result) {
    var compact = {
      checkedAt: result.checkedAt,
      score: result.score,
      maxScore: result.maxScore,
      percentage: result.percentage,
      passed: result.passed,
      criticalPassed: result.criticalPassed,
      variantId: this.variant && this.variant.id,
      variantSignature: this.variant && this.variant.signature,
      contextLabel: this.variant && this.variant.contextLabel
    };
    this.progress.attempts.push(compact);
    if (this.progress.attempts.length > 20) this.progress.attempts.shift();

    var best = this.progress.best;
    if (!best || result.score > best.score || (result.score === best.score && result.criticalPassed && !best.criticalPassed)) {
      this.progress.best = compact;
    }
    this.progress.activeAttempt = null;
    this._saveProgress();
  };

  ExitTicketEngine.prototype._gradeTask = function (task, value) {
    if (task.type === 'calculation') return this._gradeCalculation(task, value);
    if (task.type === 'number') return this._gradeNumber(task, value);
    if (task.type === 'choice') return this._gradeChoice(task, value);
    if (task.type === 'text') return this._gradeText(task, value);
    return {
      id: task.id,
      type: task.type,
      label: task.label || task.id,
      points: task.points || 0,
      pointsEarned: 0,
      correct: false,
      feedback: 'Onbekend taaktype: ' + task.type
    };
  };

  ExitTicketEngine.prototype._gradeCalculation = function (task, value) {
    var assessment = task.assessment || {};
    var calcPart = assessment.calculation || {};
    var answerPart = assessment.answer || {};
    var unitPart = assessment.unit || task.unit || {};
    var calculationText = String(getValuePart(value, 'calculation') || '');
    var answerText = getValuePart(value, 'answer');
    var unitText = String(getValuePart(value, 'unit') || '');
    var subchecks = [];
    var pointsEarned = 0;

    var calcPoints = Number(calcPart.points);
    if (!isFinite(calcPoints)) calcPoints = 1;
    var patterns = calcPart.patterns || [];
    var calcMatches = [];
    var calcMissed = [];
    var normalisedCalculation = normaliseText(calculationText);
    for (var i = 0; i < patterns.length; i++) {
      if (matchesPattern(normalisedCalculation, patterns[i])) calcMatches.push(patterns[i]);
      else calcMissed.push(patterns[i]);
    }
    var minMatches = typeof calcPart.minimumMatches === 'number' ? calcPart.minimumMatches : patterns.length;
    var calcCorrect = patterns.length ? calcMatches.length >= minMatches : normalisedCalculation.length > 0;
    var calcEarned = calcCorrect ? calcPoints : 0;
    pointsEarned += calcEarned;
    subchecks.push({
      id: 'calculation',
      label: calcPart.label || 'Berekening',
      points: calcPoints,
      pointsEarned: calcEarned,
      correct: calcCorrect,
      matched: calcMatches.length,
      missed: calcMissed.length,
      expected: calcPart.expected || task.formula || ''
    });

    var expectedAnswer = parseNumber(answerPart.value != null ? answerPart.value : task.answer);
    var givenAnswer = parseNumber(answerText);
    var tolerance = typeof answerPart.tolerance === 'number'
      ? answerPart.tolerance
      : (typeof task.tolerance === 'number' ? task.tolerance : 0);
    var answerPoints = Number(answerPart.points);
    if (!isFinite(answerPoints)) answerPoints = 1;
    var answerCorrect = isFinite(givenAnswer) && Math.abs(givenAnswer - expectedAnswer) <= tolerance;
    var answerEarned = answerCorrect ? answerPoints : 0;
    pointsEarned += answerEarned;
    subchecks.push({
      id: 'answer',
      label: answerPart.label || 'Antwoord',
      points: answerPoints,
      pointsEarned: answerEarned,
      correct: answerCorrect,
      expected: expectedAnswer,
      given: isFinite(givenAnswer) ? givenAnswer : null
    });

    var unitPoints = Number(unitPart.points);
    if (!isFinite(unitPoints)) unitPoints = 1;
    var unitPatterns = unitPart.patterns || [];
    var normalisedUnit = normaliseText(unitText);
    var unitCorrect = unitPatterns.length
      ? unitPatterns.some(function (pattern) { return matchesPattern(normalisedUnit, pattern); })
      : normalisedUnit.length > 0;
    var unitEarned = unitCorrect ? unitPoints : 0;
    pointsEarned += unitEarned;
    subchecks.push({
      id: 'unit',
      label: unitPart.label || 'Eenheid',
      points: unitPoints,
      pointsEarned: unitEarned,
      correct: unitCorrect,
      expected: unitPart.expected || task.expectedUnit || '',
      given: unitText
    });

    var maxPoints = Number(task.points) || subchecks.reduce(function (sum, s) { return sum + (Number(s.points) || 0); }, 0);
    pointsEarned = Math.min(pointsEarned, maxPoints);
    var minimum = typeof task.minimumPoints === 'number' ? task.minimumPoints : maxPoints;
    var correct = pointsEarned >= minimum;

    return {
      id: task.id,
      type: task.type,
      label: task.label || task.id,
      prompt: task.prompt || '',
      points: maxPoints,
      pointsEarned: pointsEarned,
      correct: correct,
      expected: expectedAnswer,
      expectedUnit: unitPart.expected || task.expectedUnit || '',
      given: {
        calculation: calculationText,
        answer: isFinite(givenAnswer) ? givenAnswer : null,
        unit: unitText
      },
      subchecks: subchecks,
      formula: task.formula || '',
      selfCheck: task.selfCheck || [],
      feedback: correct
        ? (task.feedbackCorrect || 'Correct: berekening, antwoord en eenheid zijn voldoende.')
        : (task.feedbackWrong || 'Controleer of je berekening, numerieke antwoord en eenheid allemaal kloppen.')
    };
  };

  ExitTicketEngine.prototype._gradeNumber = function (task, value) {
    var answer = parseNumber(task.answer);
    var given = parseNumber(value);
    var tolerance = typeof task.tolerance === 'number' ? task.tolerance : 0;
    var correct = isFinite(given) && Math.abs(given - answer) <= tolerance;
    var pointsEarned = correct ? (Number(task.points) || 0) : 0;

    var feedback = correct ? task.feedbackCorrect : task.feedbackWrong;
    if (!feedback) {
      feedback = correct
        ? 'Correct.'
        : 'Controleer je berekening. Verwacht: ' + (task.unit || '') + formatNumber(answer) + (task.formula ? ' (' + task.formula + ')' : '') + '.';
    }

    return {
      id: task.id,
      type: task.type,
      label: task.label || task.id,
      prompt: task.prompt || '',
      points: Number(task.points) || 0,
      pointsEarned: pointsEarned,
      correct: correct,
      expected: answer,
      given: isFinite(given) ? given : null,
      feedback: feedback
    };
  };

  ExitTicketEngine.prototype._gradeChoice = function (task, value) {
    var correctValue = task.answer;
    var correct = String(value) === String(correctValue);
    var pointsEarned = correct ? (Number(task.points) || 0) : 0;
    var chosen = null;
    var expected = null;

    if (Array.isArray(task.options)) {
      for (var i = 0; i < task.options.length; i++) {
        if (String(task.options[i].value) === String(value)) chosen = task.options[i];
        if (String(task.options[i].value) === String(correctValue)) expected = task.options[i];
      }
    }

    return {
      id: task.id,
      type: task.type,
      label: task.label || task.id,
      prompt: task.prompt || '',
      points: Number(task.points) || 0,
      pointsEarned: pointsEarned,
      correct: correct,
      expected: expected ? expected.label : correctValue,
      given: chosen ? chosen.label : value,
      feedback: correct
        ? (task.feedbackCorrect || 'Correct.')
        : ((chosen && chosen.feedback) || task.feedbackWrong || 'Kies het antwoord dat past bij de berekening en de economische redenering.')
    };
  };

  ExitTicketEngine.prototype._gradeText = function (task, value) {
    var text = normaliseText(value);
    var rubric = Array.isArray(task.rubric) ? task.rubric : [];
    var matched = [];
    var missed = [];
    var pointsEarned = 0;

    for (var i = 0; i < rubric.length; i++) {
      var criterion = rubric[i];
      var patterns = criterion.patterns || [];
      var ok = false;
      for (var j = 0; j < patterns.length; j++) {
        if (matchesPattern(text, patterns[j])) {
          ok = true;
          break;
        }
      }
      if (ok) {
        pointsEarned += Number(criterion.points) || 0;
        matched.push({ id: criterion.id, label: criterion.label, points: Number(criterion.points) || 0 });
      } else {
        missed.push({ id: criterion.id, label: criterion.label, points: Number(criterion.points) || 0 });
      }
    }

    var maxPoints = Number(task.points) || rubric.reduce(function (sum, c) { return sum + (Number(c.points) || 0); }, 0);
    pointsEarned = Math.min(pointsEarned, maxPoints);
    var minimum = typeof task.minimumPoints === 'number' ? task.minimumPoints : maxPoints;
    var correct = pointsEarned >= minimum;

    return {
      id: task.id,
      type: task.type,
      label: task.label || task.id,
      prompt: task.prompt || '',
      points: maxPoints,
      pointsEarned: pointsEarned,
      correct: correct,
      matched: matched,
      missed: missed,
      given: value == null ? '' : String(value),
      selfCheck: task.selfCheck || [],
      feedback: correct
        ? (task.feedbackCorrect || 'Je redenering bevat de kernpunten.')
        : (task.feedbackWrong || 'Je redenering mist nog één of meer kernpunten uit het correctiemodel.')
    };
  };

  ExitTicketEngine.prototype._buildAdvice = function (details, passed, criticalFailures) {
    if (passed) {
      return 'Beheersing aangetoond: de machinecheck is gehaald. Vul nu de zelfevaluatie in voordat je dit afsluit.';
    }
    if (criticalFailures.length) {
      return 'Deze poging is niet gehaald. Oefen opnieuw met de kritieke stap(pen): ' + criticalFailures.map(function (f) { return f.label; }).join(', ') + '. De volgende poging krijgt een nieuwe variant.';
    }
    var weak = details.filter(function (d) { return d.pointsEarned < d.points; }).map(function (d) { return d.label; });
    return weak.length
      ? 'Verbeter deze onderdelen: ' + weak.join(', ') + '. De volgende poging krijgt een nieuwe variant.'
      : 'Controleer je antwoorden en probeer het nog een keer met een nieuwe variant.';
  };

  ExitTicketEngine.prototype.getProgress = function () {
    return clone(this.progress);
  };

  ExitTicketEngine.prototype.clearProgress = function () {
    this.progress = { attempts: [], best: null, activeAttempt: null };
    this.responses = {};
    this.phaseResults = {};
    this.checked = false;
    this.lastResult = null;
    if (hasLocalStorage()) {
      try { localStorage.removeItem(this.storageKey); } catch (e) { /* ignore */ }
    }
    this._ensureActiveAttempt();
    this._loadTicketFromActiveAttempt();
  };

  ExitTicketEngine.prototype.getVariantSummary = function () {
    return clone(this.variant || {});
  };

  ExitTicketEngine.prototype.buildEvidence = function (result) {
    var r = result || this.lastResult;
    if (!r) return '';
    var status = r.passed ? 'BEHAALD' : 'NOG NIET BEHAALD';
    return [
      'Exit ticket ' + this.parNr + ' — ' + (this.meta.parName || ''),
      'Status: ' + status,
      'Score: ' + r.score + '/' + r.maxScore + ' (' + r.percentage + '%)',
      'Kritieke stappen: ' + (r.criticalPassed ? 'voldoende' : 'onvoldoende'),
      'Variant: ' + ((r.variant && (r.variant.id || r.variant.signature)) || 'n.v.t.'),
      'Context: ' + ((r.variant && r.variant.contextLabel) || 'n.v.t.'),
      'Tijdstip: ' + r.checkedAt,
      'Advies: ' + r.advice
    ].join('\n');
  };


  return ExitTicketEngine;
});
