# Exit Ticket Game — target-exercise mastery check

Prototype package for a reusable **Exit Ticket** game plus the concrete §1.1.1 version.

The design goal is simple: every paragraph ends with a small game that asks students to complete the paragraph's **target exercise**. The game should answer one operational question: can the student now do what the paragraph was built to teach?

## What is included

```text
platform/
  engines/
    exit-ticket-engine.js          Pure scoring/state/randomization engine
    exit-ticket-ui.js              Browser UI renderer
    exit-ticket.css                Shared game styling
    tests/exit-ticket-engine.test.js
  build-scripts/platform/
    build-exit-ticket-shells.js    Platform-style shell generator

lessen/
  Boek 1 - Grondslagen, vraag en aanbod/
    shared/exit-ticket/1.1.1.js    Paragraph-specific target-exercise data + variant factory
    1.1 Hoofdstuk .../1.1.1 .../
      1.1.1 Schaarste en economisch denken – exit-ticket.html

demo/
  exit-ticket-1.1.1-demo.html      Standalone offline demo

docs/
  integration-notes.md             Handoff notes for platform integration
  quality-log.md                   Issues and closure proof
```

## v3 changes

This version implements three classroom constraints:

1. **No teacher-review gate.** Open answers are checked by regex/rubric. If the regex fails, the attempt fails. If it succeeds, the student sees a self-evaluation checklist.
2. **Exam-style calculation input.** Calculation tasks now have three separate fields: calculation, answer, and unit. The calculation field uses a light regex, the numerical answer is parsed, and the unit is checked with a unit regex.
3. **Randomized variants.** Each attempt is generated from a seed. Different students get different contexts/numbers, and a new attempt after failure generates a different variant signature when possible.

## Game flow

```text
Fase 1 — machine-audit
  - calculation tasks
  - multiple choice
  - strict check on calculation + answer + unit
  - no open answers yet

Fase 2 — open regex questions
  - exactly two open questions
  - regex/rubric machine check
  - no teacher review

After pass
  - self-evaluation checklist
  - result can be copied as machine evidence
```

## §1.1.1 content model

The original blueprint scenario is the farmer/10-hectare exercise: choose between two alternatives, calculate the chosen result, calculate opportunity cost, compare a split allocation, and justify the result using scarcity.

The v3 prototype keeps the same economic structure but randomizes the surface variant. Examples:

- akkerbouwer with crops and limited land;
- bakkerij with limited oven time;
- drukkerij with limited machine time;
- foodtruck with limited sales time.

All variants preserve the target exercise:

```text
scarce resource → choose between alternatives → calculate chosen result →
calculate best non-chosen alternative / opportunity cost → compare another allocation →
write an economic judgement using scarcity and amounts
```

## Mastery rule for §1.1.1 v3

Maximum score: **15 points**.
Final pass threshold: **15/15**.

Phase thresholds:

```text
Fase 1: 10/10
Fase 2: 5/5
```

Critical steps:

- every calculation must include a plausible calculation, correct answer, and correct unit;
- opportunity cost must use the best non-chosen alternative;
- the multiple-choice judgement must match the calculated totals;
- open question 1 must name the scarce resource and both alternatives;
- open question 2 must use scarcity, compare the relevant amounts, and explain why the higher-yield option is the best use in the simplified data.

Because this is the final exercise for the paragraph, the prototype is intentionally strict. A failed attempt leads to remediation feedback and a new randomized variant.

## Run the prototype test

From this package root:

```bash
node platform/engines/tests/exit-ticket-engine.test.js
```

Expected output:

```text
ExitTicketEngine v3 tests passed.
```

## Open the demo

Open this file in a browser after unzipping the package:

```text
demo/exit-ticket-1.1.1-demo.html
```

The demo is standalone: CSS, data, engine, and UI are inlined for quick review. The platform-ready files remain separate in the `platform/` and `lessen/` folders.

## Integration summary

To integrate this in `4veco-platform` and regenerate `4veco-lessen`:

1. Add `exit-ticket-engine.js`, `exit-ticket-ui.js`, and `exit-ticket.css` to `4veco-platform/engines/`.
2. Add `build-exit-ticket-shells.js` to `4veco-platform/build-scripts/platform/`.
3. Extend `scripts/deploy.js` so it copies the three engine files to the book target's `shared/` folder and runs the exit-ticket shell generator.
4. Add `shared/exit-ticket/1.1.1.js` to the Book 1 target data.
5. Add the generated `1.1.1 ... – exit-ticket.html` to the paragraph root through deploy, not by manual editing.
6. Update landing-page generation and `validate-paragraph.js` if the exit ticket becomes a required companion artifact for every paragraph.
7. Run platform tests, deploy, `check:book`, and complete paragraph validation.
