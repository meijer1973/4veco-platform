// Exit Ticket data for 1.1.1 Schaarste en economisch denken
// v3: phased machine audit, calculation/answer/unit fields, randomized variants.
var EXIT_TICKET_DATA = {
  meta: {
    parNr: '1.1.1',
    parName: 'Schaarste en economisch denken',
    title: 'Exit ticket: beheers je de target exercise?',
    subtitle: 'Laat zien dat je schaarste, alternatieve kosten en economisch denken zelfstandig kunt toepassen.',
    adaptiveKey: '4veco:adaptive:1.1.1',
    storageVersion: 'v3',
    domainColors: {
      primary: '#17A2B8',
      primaryDk: '#117A8B',
      primaryLt: '#E8F8FB',
      accent: '#F8C471',
      navy: '#1E2761'
    },
    source: {
      blueprint: 'course_blueprint_v4.md — Book 1 Chapter 1 §1 target exercise',
      paragraphPlan: '1.1.1/_paragraph-plan.md — B01/B02, schaarste en alternatieve kosten',
      paragraphMarkdown: '1.1.1 Schaarste en economisch denken – paragraaf.md'
    }
  },

  createTicketVariant: function (ctx) {
    'use strict';

    function pick(items) {
      return items[Math.floor(ctx.random() * items.length)];
    }

    function cap(str) {
      str = String(str || '');
      return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function cleanTerm(value) {
      return String(value == null ? '' : value)
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[’']/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    }

    function escapeRegex(str) {
      return String(str).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function formatEuro(value) {
      return '€' + ctx.formatNumber(value);
    }

    function quantity(n, singular, plural) {
      return n + ' ' + (n === 1 ? singular : plural);
    }

    function looseNumberSource(value) {
      var digits = String(Math.round(value));
      var grouped = digits.replace(/\B(?=(\d{3})+(?!\d))/g, '[\\s.]?');
      return '(?:€?\\s*' + grouped + ')';
    }

    function numberPattern(value) {
      return '/' + looseNumberSource(value) + '/i';
    }

    function anyTermPattern(terms) {
      var cleaned = terms.map(cleanTerm).filter(Boolean).map(escapeRegex);
      return '/\\b(?:' + cleaned.join('|') + ')\\b/i';
    }

    function bothAlternativesPattern(a, b) {
      a = escapeRegex(cleanTerm(a));
      b = escapeRegex(cleanTerm(b));
      return '/(?:' + a + '.*' + b + '|' + b + '.*' + a + ')/i';
    }

    function amountsComparePattern(a, b, diff) {
      return '/(?:' + looseNumberSource(a) + '.*' + looseNumberSource(b) + '|' + looseNumberSource(b) + '.*' + looseNumberSource(a) + '|' + looseNumberSource(diff) + ')/i';
    }

    function higherYieldPattern(optionA, profitA) {
      return '/(?:' + escapeRegex(cleanTerm(optionA)) + '.*(?:hoogste|hoger|meer|meeste|beste)|' + looseNumberSource(profitA) + '.*per)/i';
    }

    function calculationTask(id, label, prompt, formula, answer, calcPatterns, calcMin, feedbackCorrect, feedbackWrong, selfCheck) {
      return {
        id: id,
        phase: 1,
        type: 'calculation',
        label: label,
        prompt: prompt,
        points: 3,
        critical: true,
        minimumPoints: 3,
        formula: formula,
        answer: answer,
        assessment: {
          calculation: {
            label: 'Berekening',
            points: 1,
            patterns: calcPatterns,
            minimumMatches: calcMin,
            expected: formula
          },
          answer: {
            label: 'Antwoord',
            points: 1,
            value: answer,
            tolerance: 0
          },
          unit: {
            label: 'Eenheid',
            points: 1,
            expected: '€',
            patterns: ['/^(€|eur|euro|euros)$/i']
          }
        },
        feedbackCorrect: feedbackCorrect,
        feedbackWrong: feedbackWrong,
        selfCheck: selfCheck || [
          'Staat er een berekening, niet alleen een eindantwoord?',
          'Staat het bedrag in het antwoordvak?',
          'Staat de eenheid apart in het eenhedenvak?'
        ]
      };
    }

    var contexts = [
      {
        key: 'akker',
        label: 'akkerbouw',
        title: 'De akkerbouwer en de beperkte grond',
        actor: 'Een akkerbouwer',
        actorRef: 'de akkerbouwer',
        compareActor: 'de buurvrouw',
        resourceName: 'land',
        resourceLabel: 'grond',
        resourceUnitSingular: 'hectare',
        resourceUnitPlural: 'hectare',
        resourceTerms: ['land', 'grond', 'hectare'],
        optionPairs: [['tarwe', 'maïs'], ['aardappelen', 'suikerbieten'], ['uien', 'wortels']],
        resourceAmounts: [8, 10, 12],
        profitAValues: [450, 500, 550, 600],
        deltaValues: [100, 150, 200],
        splitBValues: [2, 3, 4]
      },
      {
        key: 'bakkerij',
        label: 'bakkerij',
        title: 'De bakkerij en de beperkte oventijd',
        actor: 'Een bakkerij',
        actorRef: 'de bakkerij',
        compareActor: 'een andere bakkerij',
        resourceName: 'oventijd',
        resourceLabel: 'oventijd',
        resourceUnitSingular: 'ovenuur',
        resourceUnitPlural: 'ovenuren',
        resourceTerms: ['oventijd', 'ovenuren', 'oven', 'tijd', 'uren'],
        optionPairs: [['croissants', 'muffins'], ['broodjes', 'koekjes'], ['appeltaarten', 'cakes']],
        resourceAmounts: [8, 10, 12],
        profitAValues: [70, 80, 90, 100],
        deltaValues: [15, 20, 25],
        splitBValues: [2, 3, 4]
      },
      {
        key: 'drukkerij',
        label: 'drukkerij',
        title: 'De drukkerij en de beperkte machinetijd',
        actor: 'Een drukkerij',
        actorRef: 'de drukkerij',
        compareActor: 'een concurrent',
        resourceName: 'machinetijd',
        resourceLabel: 'machinetijd',
        resourceUnitSingular: 'machine-uur',
        resourceUnitPlural: 'machine-uren',
        resourceTerms: ['machinetijd', 'machine-uren', 'machineuur', 'machine-uur', 'tijd', 'uren'],
        optionPairs: [['posters', 'flyers'], ['folders', 'visitekaartjes'], ['stickers', 'etiketten']],
        resourceAmounts: [8, 10, 12],
        profitAValues: [90, 110, 130, 150],
        deltaValues: [20, 30, 40],
        splitBValues: [2, 3, 4]
      },
      {
        key: 'foodtruck',
        label: 'foodtruck',
        title: 'De foodtruck en de beperkte verkooptijd',
        actor: 'Een foodtruck',
        actorRef: 'de foodtruck',
        compareActor: 'een tweede foodtruck',
        resourceName: 'verkooptijd',
        resourceLabel: 'verkooptijd',
        resourceUnitSingular: 'verkoopuur',
        resourceUnitPlural: 'verkoopuren',
        resourceTerms: ['verkooptijd', 'verkoopuren', 'verkoopuur', 'tijd', 'uren'],
        optionPairs: [['wraps', 'soep'], ['smoothies', 'broodjes'], ['tosti’s', 'salades']],
        resourceAmounts: [6, 8, 10],
        profitAValues: [60, 75, 90, 105],
        deltaValues: [15, 20, 30],
        splitBValues: [2, 3]
      }
    ];

    var context = pick(contexts);
    var pair = pick(context.optionPairs);
    var optionA = pair[0];
    var optionB = pair[1];
    var resourceAmount = pick(context.resourceAmounts);
    var profitA = pick(context.profitAValues);
    var profitB = profitA - pick(context.deltaValues);
    if (profitB <= 0) profitB = Math.max(10, Math.floor(profitA / 2));

    var possibleSplitB = context.splitBValues.filter(function (n) { return n > 0 && n < resourceAmount; });
    var splitB = pick(possibleSplitB.length ? possibleSplitB : [Math.max(1, Math.floor(resourceAmount / 3))]);
    var splitA = resourceAmount - splitB;

    var allAResult = resourceAmount * profitA;
    var opportunityCost = resourceAmount * profitB;
    var comparisonResult = splitA * profitA + splitB * profitB;
    var difference = allAResult - comparisonResult;

    var quantityAll = quantity(resourceAmount, context.resourceUnitSingular, context.resourceUnitPlural);
    var quantitySplitA = quantity(splitA, context.resourceUnitSingular, context.resourceUnitPlural);
    var quantitySplitB = quantity(splitB, context.resourceUnitSingular, context.resourceUnitPlural);
    var optionAClean = cleanTerm(optionA);
    var optionBClean = cleanTerm(optionB);

    var intro = context.key === 'akker'
      ? context.actor + ' heeft ' + quantityAll + ' ' + context.resourceName + '.'
      : context.actor + ' beschikt over ' + quantityAll + ' ' + context.resourceName + '.';

    var scenarioText = intro + ' ' +
      cap(context.actorRef) + ' kan kiezen tussen ' + optionA + ' en ' + optionB + '. ' +
      cap(optionA) + ' levert ' + formatEuro(profitA) + ' winst per ' + context.resourceUnitSingular + ' op. ' +
      cap(optionB) + ' levert ' + formatEuro(profitB) + ' winst per ' + context.resourceUnitSingular + ' op. ' +
      cap(context.actorRef) + ' gebruikt alle ' + quantityAll + ' voor ' + optionA + '. ' +
      cap(context.compareActor) + ' verdeelt dezelfde schaarse ' + context.resourceLabel + ': ' + quantitySplitA + ' ' + optionA + ' en ' + quantitySplitB + ' ' + optionB + '.';

    var variantId = [context.key, optionAClean, optionBClean, resourceAmount, profitA, profitB, splitA, splitB].join('-').replace(/[^a-z0-9-]/g, '');
    var variantSignature = [context.key, optionAClean, optionBClean, resourceAmount, profitA, profitB, splitA, splitB].join('|');

    var multiplicationPattern = '/(?:x|×|\\*|maal)/i';
    var plusPattern = '/(?:\\+|plus|en|samen)/i';
    var resourceTerms = context.resourceTerms.concat([String(resourceAmount), context.resourceUnitPlural, quantityAll]);

    return {
      title: 'Exit ticket — ' + context.title,
      subtitle: 'Fase 1 is volledig machine-audit: berekening, antwoord en eenheid. Daarna volgen twee open regex-vragen. Geen docentreview.',
      mastery: {
        passScore: 15,
        phasePassScores: { '1': 10, '2': 5 },
        requireCritical: true,
        note: 'Beheersing vereist dat alle kritieke onderdelen slagen: berekening, antwoord, eenheid, keuze en de twee open regex-antwoorden.'
      },
      variant: {
        id: variantId,
        signature: variantSignature,
        contextKey: context.key,
        contextLabel: context.label,
        resourceAmount: resourceAmount,
        resourceName: context.resourceName,
        resourceLabel: context.resourceLabel,
        resourceUnitSingular: context.resourceUnitSingular,
        resourceUnitPlural: context.resourceUnitPlural,
        optionA: optionA,
        optionB: optionB,
        profitA: profitA,
        profitB: profitB,
        splitA: splitA,
        splitB: splitB,
        allAResult: allAResult,
        opportunityCost: opportunityCost,
        comparisonResult: comparisonResult,
        difference: difference
      },
      scenario: {
        title: 'Situatie — gerandomiseerde variant',
        text: scenarioText,
        table: {
          headers: ['Alternatief', 'Winst per ' + context.resourceUnitSingular, 'Gebruik in deze variant'],
          rows: [
            [cap(optionA), formatEuro(profitA) + ' per ' + context.resourceUnitSingular, cap(context.actorRef) + ': ' + quantityAll + ' · ' + cap(context.compareActor) + ': ' + quantitySplitA],
            [cap(optionB), formatEuro(profitB) + ' per ' + context.resourceUnitSingular, cap(context.actorRef) + ': 0 ' + context.resourceUnitPlural + ' · ' + cap(context.compareActor) + ': ' + quantitySplitB]
          ]
        }
      },
      selfEvaluation: {
        title: 'Zelfevaluatie na machinecheck',
        intro: 'De regex en rekencheck zijn gehaald. Vink voor jezelf af of je antwoord ook examenwaardig is.',
        checks: [
          'Ik heb bij elke berekening een berekening, een antwoord en een eenheid ingevuld.',
          'Ik heb bij alternatieve kosten het beste niet-gekozen alternatief gebruikt, niet de gekozen optie.',
          'Ik heb in mijn eindoordeel de bedragen vergeleken en het begrip schaarste gebruikt.',
          'Ik zou dezelfde aanpak kunnen toepassen als de context of de getallen veranderen.'
        ]
      },
      tasks: [
        calculationTask(
          'chosen_profit',
          'Bereken de winst van de gekozen optie',
          'Bereken de totale winst als ' + context.actorRef + ' alle ' + quantityAll + ' inzet voor ' + optionA + '.',
          resourceAmount + ' × ' + formatEuro(profitA) + ' = ' + formatEuro(allAResult),
          allAResult,
          [numberPattern(resourceAmount), numberPattern(profitA), multiplicationPattern],
          3,
          'Correct: je berekening, bedrag en eenheid passen bij de gekozen optie.',
          'Gebruik het aantal ' + context.resourceUnitPlural + ' en de winst per ' + context.resourceUnitSingular + ': ' + resourceAmount + ' × ' + formatEuro(profitA) + ' = ' + formatEuro(allAResult) + '.',
          [
            'Heb je het volledige aantal ' + context.resourceUnitPlural + ' gebruikt?',
            'Heb je vermenigvuldigd met de winst per ' + context.resourceUnitSingular + '?',
            'Staat de eenheid € apart ingevuld?'
          ]
        ),
        calculationTask(
          'opportunity_cost',
          'Bereken de alternatieve kosten',
          'Wat zijn de alternatieve kosten van de keuze voor ' + optionA + '? Bereken de opbrengst van het beste niet-gekozen alternatief.',
          resourceAmount + ' × ' + formatEuro(profitB) + ' = ' + formatEuro(opportunityCost),
          opportunityCost,
          [numberPattern(resourceAmount), numberPattern(profitB), multiplicationPattern],
          3,
          'Correct: alternatieve kosten zijn hier de opbrengst van ' + optionB + ' op alle ' + quantityAll + '.',
          'Alternatieve kosten zijn het beste niet-gekozen alternatief: ' + resourceAmount + ' × ' + formatEuro(profitB) + ' = ' + formatEuro(opportunityCost) + '.',
          [
            'Heb je het niet-gekozen alternatief genomen?',
            'Heb je alle ' + quantityAll + ' aan dat alternatief toegerekend?',
            'Staat de eenheid € apart ingevuld?'
          ]
        ),
        calculationTask(
          'comparison_profit',
          'Bereken de winst van de vergelijkingspersoon',
          'Bereken de totale winst van ' + context.compareActor + ' bij ' + quantitySplitA + ' ' + optionA + ' en ' + quantitySplitB + ' ' + optionB + '.',
          '(' + splitA + ' × ' + formatEuro(profitA) + ') + (' + splitB + ' × ' + formatEuro(profitB) + ') = ' + formatEuro(comparisonResult),
          comparisonResult,
          [numberPattern(splitA), numberPattern(profitA), numberPattern(splitB), numberPattern(profitB), plusPattern],
          5,
          'Correct: je hebt beide delen berekend en bij elkaar opgeteld.',
          'Bereken beide alternatieven apart en tel ze op: (' + splitA + ' × ' + formatEuro(profitA) + ') + (' + splitB + ' × ' + formatEuro(profitB) + ') = ' + formatEuro(comparisonResult) + '.',
          [
            'Heb je beide delen van de verdeling meegenomen?',
            'Heb je de twee uitkomsten bij elkaar opgeteld?',
            'Staat de eenheid € apart ingevuld?'
          ]
        ),
        {
          id: 'better_choice',
          phase: 1,
          type: 'choice',
          label: 'Beoordeel de keuze met de cijfers',
          prompt: 'Heeft ' + context.compareActor + ' in deze vereenvoudigde situatie een betere keuze gemaakt dan ' + context.actorRef + '?',
          points: 1,
          critical: true,
          minimumPoints: 1,
          answer: 'no',
          options: [
            {
              value: 'yes',
              label: 'Ja, want spreiden over twee alternatieven is altijd beter.',
              feedback: 'Spreiden kan in werkelijkheid nuttig zijn, maar in deze opgave vergelijk je de gegeven winstbedragen. ' + formatEuro(comparisonResult) + ' is lager dan ' + formatEuro(allAResult) + '.'
            },
            {
              value: 'no',
              label: 'Nee, want de totale winst is lager dan bij volledig kiezen voor ' + optionA + '.',
              feedback: 'Correct: ' + context.compareActor + ' verdient ' + formatEuro(comparisonResult) + ', terwijl ' + context.actorRef + ' ' + formatEuro(allAResult) + ' verdient.'
            },
            {
              value: 'unknown',
              label: 'Dat kun je niet bepalen, want er staat niets over winst.',
              feedback: 'De opgave geeft winst per ' + context.resourceUnitSingular + '. Je kunt de totale winst dus wel vergelijken.'
            }
          ],
          feedbackCorrect: 'Correct: binnen de gegeven cijfers is volledig kiezen voor ' + optionA + ' winstgevender.'
        },
        {
          id: 'scarcity_context',
          phase: 2,
          type: 'text',
          label: 'Open vraag 1 — Herken de schaarste',
          prompt: 'Noem het schaarse middel en de twee alternatieven in deze variant.',
          points: 2,
          critical: true,
          minimumPoints: 2,
          rubric: [
            {
              id: 'scarce_resource',
              label: 'Noemt het beperkte middel',
              points: 1,
              patterns: [anyTermPattern(resourceTerms)]
            },
            {
              id: 'alternatives',
              label: 'Noemt beide alternatieven',
              points: 1,
              patterns: [bothAlternativesPattern(optionA, optionB)]
            }
          ],
          feedbackCorrect: 'Correct: je noemt het schaarse middel en de relevante alternatieven.',
          feedbackWrong: 'Noem expliciet het beperkte middel (' + quantityAll + ' ' + context.resourceLabel + ') én beide alternatieven (' + optionA + ' en ' + optionB + ').',
          selfCheck: [
            'Staat het beperkte middel letterlijk in mijn antwoord?',
            'Staan beide alternatieven letterlijk in mijn antwoord?'
          ]
        },
        {
          id: 'final_judgement',
          phase: 2,
          type: 'text',
          label: 'Open vraag 2 — Eindoordeel met schaarste en alternatieve kosten',
          prompt: 'Schrijf je eindoordeel in volledige zinnen. Gebruik schaarste, alternatieve kosten en de relevante bedragen.',
          points: 3,
          critical: true,
          minimumPoints: 3,
          rubric: [
            {
              id: 'scarcity_language',
              label: 'Gebruikt schaarste / beperkt middel correct',
              points: 1,
              patterns: ['schaarste', 'schaars', 'beperkt', 'beperkte middelen', anyTermPattern(resourceTerms)]
            },
            {
              id: 'amounts_compare',
              label: 'Vergelijkt de relevante bedragen of noemt het verschil',
              points: 1,
              patterns: [amountsComparePattern(allAResult, comparisonResult, difference)]
            },
            {
              id: 'reasoning_best_use',
              label: 'Legt uit dat de gekozen optie hier de hoogste winst per eenheid heeft',
              points: 1,
              patterns: [higherYieldPattern(optionA, profitA), 'hoogste winst', 'meer winst', 'beste inzet']
            }
          ],
          feedbackCorrect: 'Je oordeel is economisch onderbouwd: je gebruikt schaarste, vergelijkt de bedragen en legt uit waarom ' + optionA + ' hier de beste inzet van het schaarse middel is.',
          feedbackWrong: 'Maak je uitleg concreter: gebruik het begrip schaarste, vergelijk ' + formatEuro(allAResult) + ' en ' + formatEuro(comparisonResult) + ', en leg uit dat ' + optionA + ' hier de hoogste winst per ' + context.resourceUnitSingular + ' heeft.',
          selfCheck: [
            'Heb ik het woord schaarste of schaars juist gebruikt?',
            'Heb ik de bedragen ' + formatEuro(allAResult) + ' en ' + formatEuro(comparisonResult) + ' of het verschil ' + formatEuro(difference) + ' genoemd?',
            'Heb ik uitgelegd waarom ' + optionA + ' de beste inzet van het beperkte middel is?'
          ]
        }
      ]
    };
  }
};
